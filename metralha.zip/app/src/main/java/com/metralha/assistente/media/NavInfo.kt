package com.metralha.assistente.media

import android.app.Notification
import android.service.notification.StatusBarNotification
import com.metralha.assistente.brain.TextUtils
import com.metralha.assistente.core.AppState

/**
 * Lê as instruções de navegação que o Google Maps (ou Waze) mostra na notificação
 * ("Vire à direita na Rua Augusta", "12 min · 3,4 km") para o Metralha falar e mostrar na tela.
 * Só olha notificações desses dois apps; nada é guardado.
 */
object NavInfo {
    private val NAV_APPS = setOf("com.google.android.apps.maps", "com.waze")

    var active = false
        private set
    var instruction = ""
        private set
    var eta = ""
        private set
    private var lastKey = ""
    private var lastUpdate = 0L

    /** Chamado quando a instrução realmente muda (não só a distância). */
    var onNewInstruction: ((String) -> Unit)? = null

    fun onPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in NAV_APPS) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_ONGOING_EVENT == 0) return // só a notificação fixa de navegação
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        instruction = listOf(title, text).filter { it.isNotBlank() }.distinct().joinToString(" — ")
        eta = sub
        active = true
        lastUpdate = System.currentTimeMillis()
        AppState.navInstruction = instruction
        AppState.navEta = eta
        AppState.navActive = true
        AppState.changed()

        // Avisa só quando a manobra muda (ignora a contagem de metros diminuindo).
        val key = TextUtils.norm(instruction)
            .replace(Regex("\\b\\d+[\\d ]*(m|km|metros|quilometros|min|minutos|h)?\\b"), " ")
            .replace(Regex(" +"), " ").trim()
        if (key.isNotBlank() && key != lastKey) {
            lastKey = key
            onNewInstruction?.invoke(spoken(instruction))
        }
    }

    fun onRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName !in NAV_APPS) return
        if ((sbn.notification?.flags ?: 0) and Notification.FLAG_ONGOING_EVENT == 0) return
        active = false
        lastKey = ""
        AppState.navActive = false
        AppState.changed()
    }

    /** Texto para falar: troca abreviações comuns por palavras. */
    fun spoken(s: String): String = s
        .replace(" — ", ". ")
        .replace(Regex("\\bR\\.\\s"), "Rua ")
        .replace(Regex("\\bAv\\.\\s"), "Avenida ")
        .replace(Regex("\\bAl\\.\\s"), "Alameda ")
        .replace(Regex("(\\d+)\\s?km\\b"), "$1 quilômetros")
        .replace(Regex("(\\d+)\\s?m\\b"), "$1 metros")
        .replace(Regex("(\\d+)\\s?min\\b"), "$1 minutos")

    fun describe(): String {
        val fresh = active && System.currentTimeMillis() - lastUpdate < 10 * 60_000
        if (!fresh || instruction.isBlank()) {
            return "Não tem nenhuma rota ativa agora. Diga, por exemplo: me leva para a padaria mais próxima."
        }
        val tail = if (eta.isNotBlank()) " Previsão: ${spoken(eta.replace("·", ","))}." else ""
        return "Agora: ${spoken(instruction)}.$tail"
    }
}
