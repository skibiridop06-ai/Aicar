package com.metralha.assistente.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Mostrador circular com relevo (estilo painel de carro): trilho, arco luminoso, marcas e valor. */
class ArcGauge @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var min = 0f
    var max = 100f
    var unit = ""
    var label = ""
    var colorA = Color.parseColor("#00E5FF")
    var colorB = Color.parseColor("#7C4DFF")
    var dim = false
        set(v) { field = v; invalidate() }
    var overrideText: String? = null
        set(v) { field = v; invalidate() }

    private var shown = 0f
    private var anim: ValueAnimator? = null
    private val density = resources.displayMetrics.density
    private val rect = RectF()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val face = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.WHITE }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.parseColor("#7D8FAB") }

    fun setFont(tf: Typeface?) { if (tf != null) { big.typeface = tf; small.typeface = tf }; invalidate() }

    fun setValue(v: Float, animate: Boolean = true) {
        val target = v.coerceIn(min, max)
        anim?.cancel()
        if (!animate || !isLaidOut) { shown = target; invalidate(); return }
        anim = ValueAnimator.ofFloat(shown, target).apply {
            duration = 650
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 0.9f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w, h / 0.9f)
        val cx = w / 2f
        val cy = size * 0.52f
        val stroke = size * 0.07f
        val r = size / 2f - stroke * 1.4f
        rect.set(cx - r, cy - r, cx + r, cy + r)

        // "face" com relevo
        face.shader = RadialGradient(cx, cy - r * 0.3f, r * 1.2f,
            intArrayOf(Color.parseColor("#1A2538"), Color.parseColor("#0A101A"), Color.parseColor("#05080F")),
            floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r - stroke * 0.9f, face)

        // trilho
        track.strokeWidth = stroke
        track.color = Color.parseColor("#16233A")
        canvas.drawArc(rect, 135f, 270f, false, track)

        // marcas
        for (i in 0..27) {
            val a = Math.toRadians((135 + i * 10).toDouble())
            val major = i % 3 == 0
            val r1 = r - stroke * 1.25f
            val r2 = r1 - (if (major) stroke * 0.55f else stroke * 0.3f)
            tick.strokeWidth = (if (major) 1.6f else 1f) * density
            tick.color = Color.parseColor(if (major) "#3C5272" else "#22324A")
            canvas.drawLine(
                cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), tick
            )
        }

        val frac = if (max > min) (shown - min) / (max - min) else 0f
        val sweep = 270f * frac.coerceIn(0f, 1f)
        val ca = if (dim) Color.parseColor("#3A4A60") else colorA
        val cb = if (dim) Color.parseColor("#3A4A60") else colorB

        if (sweep > 0.5f) {
            val sg = SweepGradient(cx, cy, intArrayOf(ca, cb, cb), floatArrayOf(0f, 0.75f, 1f))
            val m = Matrix(); m.setRotate(135f, cx, cy); sg.setLocalMatrix(m)
            halo.shader = sg
            halo.strokeWidth = stroke * 2.2f
            halo.alpha = 45
            canvas.drawArc(rect, 135f, sweep, false, halo)
            arc.shader = sg
            arc.strokeWidth = stroke
            canvas.drawArc(rect, 135f, sweep, false, arc)

            // ponteiro luminoso
            val a = Math.toRadians((135 + sweep).toDouble())
            val kx = cx + (cos(a) * r).toFloat()
            val ky = cy + (sin(a) * r).toFloat()
            knob.shader = RadialGradient(kx, ky, stroke * 1.4f, intArrayOf(Color.WHITE, cb, Color.TRANSPARENT), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(kx, ky, stroke * 1.4f, knob)
        }

        // valor
        big.textSize = size * 0.2f
        big.color = if (dim) Color.parseColor("#7D8FAB") else Color.WHITE
        val txt = overrideText ?: (Math.round(shown).toString() + unit)
        canvas.drawText(txt, cx, cy + big.textSize * 0.35f, big)
        small.textSize = size * 0.075f
        small.letterSpacing = 0.15f
        canvas.drawText(label, cx, cy + r * 0.62f, small)
    }
}
