package com.metralha.assistente.vehicle

import com.metralha.assistente.brain.CommandValidator
import com.metralha.assistente.core.AppState
import java.util.Locale

/** Carro simulado: permite testar toda a assistente sem nenhum hardware. */
class VirtualCar : VehicleAdapter {
    override val displayName = "Carro Virtual"

    private var track = 0

    override fun setClimateTemperature(celsius: Int): ActionResult {
        AppState.temperature = celsius
        AppState.acOn = true
        AppState.changed()
        return ActionResult(true, "Ar-condicionado em $celsius graus.")
    }

    override fun adjustClimateTemperature(delta: Int): ActionResult {
        val target = (AppState.temperature + delta).coerceIn(CommandValidator.MIN_TEMP, CommandValidator.MAX_TEMP)
        if (target == AppState.temperature) {
            return ActionResult(false, "Já está no limite: ${AppState.temperature} graus.")
        }
        return setClimateTemperature(target)
    }

    override fun setClimatePower(on: Boolean): ActionResult {
        AppState.acOn = on
        AppState.changed()
        return ActionResult(true, if (on) "Ar-condicionado ligado em ${AppState.temperature} graus." else "Ar-condicionado desligado.")
    }

    override fun playMusic(query: String): ActionResult {
        AppState.musicTitle = titleCase(query)
        AppState.musicPlaying = true
        AppState.changed()
        return ActionResult(true, "Tocando ${AppState.musicTitle}.")
    }

    override fun pauseMusic(): ActionResult {
        AppState.musicPlaying = false
        AppState.changed()
        return ActionResult(true, "Música pausada.")
    }

    override fun resumeMusic(): ActionResult {
        if (AppState.musicTitle == "Nenhuma") AppState.musicTitle = "Rádio Metralha"
        AppState.musicPlaying = true
        AppState.changed()
        return ActionResult(true, "Continuando a música.")
    }

    override fun nextTrack(): ActionResult {
        track++
        AppState.musicTitle = "Faixa simulada ${track + 1}"
        AppState.musicPlaying = true
        AppState.changed()
        return ActionResult(true, "Próxima música.")
    }

    override fun previousTrack(): ActionResult {
        track = (track - 1).coerceAtLeast(0)
        AppState.musicTitle = "Faixa simulada ${track + 1}"
        AppState.musicPlaying = true
        AppState.changed()
        return ActionResult(true, "Música anterior.")
    }

    override fun volumeUp() = setVolume((AppState.volume + 10).coerceAtMost(100))
    override fun volumeDown() = setVolume((AppState.volume - 10).coerceAtLeast(0))

    override fun setVolume(level: Int): ActionResult {
        AppState.volume = level.coerceIn(0, 100)
        AppState.changed()
        return ActionResult(true, "Volume em ${AppState.volume} por cento.")
    }

    override fun describe(): String =
        "carro virtual; ar ${if (AppState.acOn) "ligado" else "desligado"} em ${AppState.temperature}°C; " +
            "volume ${AppState.volume}%; música ${AppState.musicTitle} (${if (AppState.musicPlaying) "tocando" else "pausada"})"

    private fun titleCase(s: String) = s.split(" ").joinToString(" ") { w ->
        w.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }
}
