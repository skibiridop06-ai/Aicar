package com.metralha.assistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.ListenStatus
import com.metralha.assistente.core.MetralhaCore
import com.metralha.assistente.media.NowPlaying
import com.metralha.assistente.service.ListeningService
import com.metralha.assistente.ui.ArcGauge
import com.metralha.assistente.ui.HoloView
import com.metralha.assistente.ui.Perms
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var holo: HoloView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var modeChip: TextView
    private lateinit var statusText: TextView
    private lateinit var partialText: TextView
    private lateinit var detailText: TextView
    private lateinit var setupCard: View
    private lateinit var gaugeTemp: ArcGauge
    private lateinit var gaugeVol: ArcGauge
    private lateinit var acValue: TextView
    private lateinit var btValue: TextView
    private lateinit var musicApp: TextView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnAc: ImageButton
    private lateinit var timerChip: TextView
    private lateinit var chatList: LinearLayout

    private val ui = Handler(Looper.getMainLooper())
    private val render: () -> Unit = { renderState() }
    private var lastStatus: ListenStatus? = null
    private var lastHistorySize = -1
    private var lastHistoryTop: Any? = null

    private val ticker = object : Runnable {
        override fun run() {
            renderClock()
            renderTimer()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        MetralhaCore.init(this)
        bind()
        setupControls()
        ensurePermissionsAndStart()
    }

    private fun bind() {
        holo = findViewById(R.id.holo)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        modeChip = findViewById(R.id.modeChip)
        statusText = findViewById(R.id.statusText)
        partialText = findViewById(R.id.partialText)
        detailText = findViewById(R.id.detailText)
        setupCard = findViewById(R.id.setupCard)
        gaugeTemp = findViewById(R.id.gaugeTemp)
        gaugeVol = findViewById(R.id.gaugeVol)
        acValue = findViewById(R.id.acValue)
        btValue = findViewById(R.id.btValue)
        musicApp = findViewById(R.id.musicApp)
        musicTitle = findViewById(R.id.musicTitle)
        musicArtist = findViewById(R.id.musicArtist)
        btnPlay = findViewById(R.id.btnPlay)
        btnAc = findViewById(R.id.btnAc)
        timerChip = findViewById(R.id.timerChip)
        chatList = findViewById(R.id.chatList)

        val bold = resources.getFont(R.font.orbitron_bold)
        gaugeTemp.apply { min = 16f; max = 30f; unit = "°"; label = "CLIMA"; setFont(bold); setValue(AppState.temperature.toFloat(), false) }
        gaugeVol.apply {
            min = 0f; max = 100f; unit = "%"; label = "VOLUME"
            colorA = Color.parseColor("#7C4DFF"); colorB = Color.parseColor("#FF3D9A")
            setFont(bold); setValue(AppState.volume.toFloat(), false)
        }
        musicTitle.isSelected = true // letreiro rolando
    }

    private fun setupControls() {
        holo.setOnClickListener { MetralhaCore.tapOrb() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        // Clima
        findViewById<ImageButton>(R.id.btnTempDown).setOnClickListener { MetralhaCore.manual(mapOf("action" to "adjust_climate_temperature", "delta" to -1)) }
        findViewById<ImageButton>(R.id.btnTempUp).setOnClickListener { MetralhaCore.manual(mapOf("action" to "adjust_climate_temperature", "delta" to 1)) }
        btnAc.setOnClickListener { MetralhaCore.manual(mapOf("action" to "set_climate_power", "on" to !AppState.acOn)) }

        // Volume
        findViewById<ImageButton>(R.id.btnVolDown).setOnClickListener { MetralhaCore.manual(mapOf("action" to "volume_down")) }
        findViewById<ImageButton>(R.id.btnVolUp).setOnClickListener { MetralhaCore.manual(mapOf("action" to "volume_up")) }

        // Música
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { MetralhaCore.manual(mapOf("action" to "previous_track")) }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { MetralhaCore.manual(mapOf("action" to "next_track")) }
        btnPlay.setOnClickListener {
            MetralhaCore.manual(mapOf("action" to if (AppState.musicPlaying) "pause_music" else "resume_music"))
        }

        // Permissões especiais
        findViewById<Button>(R.id.btnPermMedia).setOnClickListener { Perms.openMedia(this) }
        findViewById<Button>(R.id.btnPermOverlay).setOnClickListener { Perms.openOverlay(this) }
        findViewById<Button>(R.id.btnPermBattery).setOnClickListener { Perms.openBattery(this) }

        // Texto
        val input = findViewById<EditText>(R.id.input)
        val send = {
            val t = input.text.toString()
            if (t.isNotBlank()) {
                MetralhaCore.submitTyped(t)
                input.setText("")
                getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(input.windowToken, 0)
            }
        }
        findViewById<ImageButton>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
    }

    // ---------------- Permissões e início ----------------
    private fun ensurePermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isEmpty()) startListeningService() else requestPermissions(needed.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListeningService()
        else {
            AppState.detail = "Sem o microfone o Metralha não ouve. Libere em Configurações > Apps > Metralha > Permissões."
            AppState.changed()
        }
    }

    fun startListeningService() {
        try { startForegroundService(Intent(this, ListeningService::class.java)) }
        catch (e: Exception) { MetralhaCore.startListening() }
    }

    // ---------------- Ciclo de vida ----------------
    override fun onResume() {
        super.onResume()
        AppState.activityVisible = true
        if (MetralhaCore.settings.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        NowPlaying.start(this)
        MetralhaCore.executor.music.refreshVolume()
        setupCard.visibility = if (Perms.allOk(this)) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.btnPermMedia).visibility = if (Perms.media(this)) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.btnPermOverlay).visibility = if (Perms.overlay(this)) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.btnPermBattery).visibility = if (Perms.battery(this)) View.GONE else View.VISIBLE
        AppState.addListener(render)
        lastStatus = null
        lastHistorySize = -1
        renderState()
        ui.post(ticker)
    }

    override fun onPause() {
        AppState.activityVisible = false
        AppState.removeListener(render)
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------------- Desenho ----------------
    private fun renderClock() {
        val now = LocalDateTime.now()
        clock.text = now.format(DateTimeFormatter.ofPattern("HH:mm"))
        date.text = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", Locale("pt", "BR")))
            .replaceFirstChar { it.uppercase() }
    }

    private fun renderTimer() {
        val end = AppState.timerEndAt
        if (end == 0L) { timerChip.visibility = View.GONE; return }
        val left = ((end - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        timerChip.visibility = View.VISIBLE
        timerChip.text = "⏱ ${AppState.timerLabel}  ${"%02d:%02d".format(left / 60, left % 60)}"
    }

    private fun renderState() {
        val st = AppState.status
        val virtual = MetralhaCore.settings.virtualCar

        if (st != lastStatus) {
            lastStatus = st
            holo.setMode(
                when (st) {
                    ListenStatus.OUVINDO -> HoloView.Mode.IDLE
                    ListenStatus.ATIVADA -> HoloView.Mode.ACTIVE
                    ListenStatus.PROCESSANDO -> HoloView.Mode.THINK
                    ListenStatus.FALANDO -> HoloView.Mode.SPEAK
                    ListenStatus.CONFIRMANDO -> HoloView.Mode.CONFIRM
                    ListenStatus.ERRO -> HoloView.Mode.ERROR
                    ListenStatus.INICIANDO, ListenStatus.PARADA -> HoloView.Mode.OFF
                }
            )
            fadeIn(statusText)
        }
        statusText.text = st.label
        partialText.text = if (AppState.partial.isNotBlank()) "“${AppState.partial}”" else ""
        detailText.text = when {
            AppState.detail.isNotBlank() && (st == ListenStatus.ERRO || st == ListenStatus.PARADA) -> AppState.detail
            st == ListenStatus.OUVINDO -> "Toque no holograma para falar sem dizer o nome"
            else -> ""
        }

        modeChip.text = if (virtual) "CARRO VIRTUAL" else "CARRO REAL"

        // Clima
        if (virtual) {
            gaugeTemp.dim = !AppState.acOn
            gaugeTemp.overrideText = null
            gaugeTemp.setValue(AppState.temperature.toFloat())
            acValue.text = if (AppState.acOn) "A/C ligado" else "A/C desligado"
            acValue.setTextColor(getColor(if (AppState.acOn) R.color.accent else R.color.muted))
        } else {
            gaugeTemp.dim = true
            gaugeTemp.overrideText = "—"
            acValue.text = "Indisponível neste carro"
            acValue.setTextColor(getColor(R.color.warn))
        }
        btnAc.imageTintList = android.content.res.ColorStateList.valueOf(getColor(if (AppState.acOn && virtual) R.color.accent else R.color.text))

        // Volume e Bluetooth
        gaugeVol.setValue(AppState.volume.toFloat())
        btValue.text = if (AppState.bluetoothConnected) "🔵 ${AppState.bluetooth}" else "Bluetooth desconectado"
        btValue.setTextColor(getColor(if (AppState.bluetoothConnected) R.color.ok else R.color.muted))

        // Música
        musicApp.text = (AppState.musicApp.ifBlank { appLabelFromSettings() }).uppercase()
        if (musicTitle.text.toString() != AppState.musicTitle) musicTitle.text = AppState.musicTitle
        musicArtist.text = AppState.musicArtist
        btnPlay.setImageResource(if (AppState.musicPlaying) R.drawable.ic_pause else R.drawable.ic_play)

        renderTimer()
        renderChat()
    }

    private fun appLabelFromSettings() = when (MetralhaCore.settings.musicApp) {
        "spotify" -> "Spotify"; "ytmusic" -> "YouTube Music"; else -> "Música"
    }

    private fun renderChat() {
        val top = AppState.history.firstOrNull()
        if (AppState.history.size == lastHistorySize && top === lastHistoryTop) return
        lastHistorySize = AppState.history.size
        lastHistoryTop = top
        chatList.removeAllViews()
        if (AppState.history.isEmpty()) {
            chatList.addView(bubble("Oi! Diga “Metralha” e fale comigo. Ex.: “Metralha, toca Blinding Lights” ou “que horas são?”", user = false))
            return
        }
        for (h in AppState.history.take(8)) {
            chatList.addView(bubble(h.heard.replaceFirstChar { it.uppercase() }, user = true))
            chatList.addView(bubble(h.reply, user = false, tag = h.json))
        }
    }

    private fun bubble(text: String, user: Boolean, tag: String? = null): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (user) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(getColor(R.color.text))
            setBackgroundResource(if (user) R.drawable.bg_bubble_user else R.drawable.bg_bubble_bot)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt()
        }
        wrap.addView(tv)
        if (tag != null && !tag.contains("\"answer\"")) {
            wrap.addView(TextView(this).apply {
                this.text = tag
                textSize = 10f
                typeface = android.graphics.Typeface.MONOSPACE
                setTextColor(getColor(R.color.accent_dim))
                setPadding(dp(6), dp(3), dp(6), 0)
            })
        }
        return wrap
    }

    private fun fadeIn(v: View) {
        v.startAnimation(AlphaAnimation(0.2f, 1f).apply { duration = 350 })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
