package com.metralha.assistente

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.ListenStatus
import com.metralha.assistente.core.MetralhaCore
import com.metralha.assistente.service.ListeningService

class MainActivity : Activity() {

    private lateinit var orb: View
    private lateinit var orbCore: View
    private lateinit var statusText: TextView
    private lateinit var partialText: TextView
    private lateinit var detailText: TextView
    private lateinit var modeChip: TextView
    private lateinit var tempValue: TextView
    private lateinit var acValue: TextView
    private lateinit var volValue: TextView
    private lateinit var volBar: ProgressBar
    private lateinit var musicValue: TextView
    private lateinit var musicState: TextView
    private lateinit var btValue: TextView
    private lateinit var aiValue: TextView
    private lateinit var historyList: LinearLayout
    private lateinit var btnListen: Button

    private var pulse: ObjectAnimator? = null
    private var lastStatus: ListenStatus? = null
    private val render: () -> Unit = { renderState() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Tela sempre acesa: o celular vira a "central" do carro no suporte.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        MetralhaCore.init(this)
        bindViews()
        setupControls()
        ensurePermissionsAndStart()
    }

    private fun bindViews() {
        orb = findViewById(R.id.orb)
        orbCore = findViewById(R.id.orbCore)
        statusText = findViewById(R.id.statusText)
        partialText = findViewById(R.id.partialText)
        detailText = findViewById(R.id.detailText)
        modeChip = findViewById(R.id.modeChip)
        tempValue = findViewById(R.id.tempValue)
        acValue = findViewById(R.id.acValue)
        volValue = findViewById(R.id.volValue)
        volBar = findViewById(R.id.volBar)
        musicValue = findViewById(R.id.musicValue)
        musicState = findViewById(R.id.musicState)
        btValue = findViewById(R.id.btValue)
        aiValue = findViewById(R.id.aiValue)
        historyList = findViewById(R.id.historyList)
        btnListen = findViewById(R.id.btnListen)
    }

    private fun setupControls() {
        val s = MetralhaCore.settings

        // Teste por texto
        val input = findViewById<EditText>(R.id.testInput)
        val send = {
            val t = input.text.toString()
            if (t.isNotBlank()) { MetralhaCore.submitTyped(t); input.setText("") }
        }
        findViewById<Button>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }

        // Interruptores
        val swVirtual = findViewById<Switch>(R.id.swVirtual)
        swVirtual.isChecked = s.virtualCar
        swVirtual.setOnCheckedChangeListener { _, on -> s.virtualCar = on; MetralhaCore.applySettings() }

        val swEconomy = findViewById<Switch>(R.id.swEconomy)
        swEconomy.isChecked = s.economyMode
        swEconomy.setOnCheckedChangeListener { _, on -> s.economyMode = on; MetralhaCore.applySettings() }

        btnListen.setOnClickListener {
            if (MetralhaCore.listening) {
                startService(Intent(this, ListeningService::class.java).setAction(ListeningService.ACTION_STOP))
            } else {
                ensurePermissionsAndStart()
            }
        }

        findViewById<Button>(R.id.btnBt).setOnClickListener {
            try { startActivity(Intent(AndroidSettings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) {}
        }

        // IA online
        val inKey = findViewById<EditText>(R.id.inKey)
        val inUrl = findViewById<EditText>(R.id.inUrl)
        val inModel = findViewById<EditText>(R.id.inModel)
        val result = findViewById<TextView>(R.id.aiTestResult)
        inKey.setText(s.apiKey)
        inUrl.setText(s.baseUrl)
        inModel.setText(s.model)
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            s.apiKey = inKey.text.toString()
            s.baseUrl = inUrl.text.toString()
            s.model = inModel.text.toString()
            inUrl.setText(s.baseUrl); inModel.setText(s.model)
            MetralhaCore.applySettings()
            result.text = "Salvo."
        }
        findViewById<Button>(R.id.btnTestAi).setOnClickListener {
            result.text = "Testando…"
            MetralhaCore.testAi { result.text = it }
        }
    }

    // ---------------- Permissões e início ----------------
    private fun ensurePermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isEmpty()) startListeningService() else requestPermissions(needed.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListeningService()
        } else {
            AppState.detail = "Sem permissão de microfone o Metralha não consegue ouvir. Libere em Configurações > Apps > Metralha > Permissões."
            AppState.changed()
        }
    }

    private fun startListeningService() {
        try {
            startForegroundService(Intent(this, ListeningService::class.java))
        } catch (e: Exception) {
            // Alternativa: ouvir só com o app aberto.
            MetralhaCore.startListening()
        }
    }

    // ---------------- Ciclo de vida ----------------
    override fun onResume() {
        super.onResume()
        AppState.activityVisible = true
        AppState.addListener(render)
        if (!MetralhaCore.settings.virtualCar) MetralhaCore.executor.phone.refreshVolume()
        renderState()
    }

    override fun onPause() {
        AppState.activityVisible = false
        AppState.removeListener(render)
        super.onPause()
    }

    // ---------------- Desenho da tela ----------------
    private fun renderState() {
        val virtual = MetralhaCore.settings.virtualCar
        val st = AppState.status

        statusText.text = st.label
        partialText.text = if (AppState.partial.isNotBlank()) "“${AppState.partial}”" else ""
        detailText.text = when {
            AppState.detail.isNotBlank() && (st == ListenStatus.ERRO || st == ListenStatus.PARADA) -> AppState.detail
            st == ListenStatus.OUVINDO -> if (MetralhaCore.settings.economyMode) "Modo econômico · diga “Metralha”" else "Diga “Metralha” e o comando"
            st == ListenStatus.ATIVADA -> "Pode falar…"
            else -> ""
        }
        btnListen.text = if (MetralhaCore.listening) "Pausar escuta" else "Ligar escuta"

        modeChip.text = if (virtual) "Carro Virtual" else "Celular + Bluetooth"

        if (virtual) {
            tempValue.text = "${AppState.temperature}°C"
            acValue.text = if (AppState.acOn) "A/C ligado" else "A/C desligado"
            acValue.setTextColor(getColor(if (AppState.acOn) R.color.accent else R.color.muted))
        } else {
            tempValue.text = "—"
            acValue.text = "Indisponível neste carro"
            acValue.setTextColor(getColor(R.color.warn))
        }

        volValue.text = "${AppState.volume}%"
        volBar.progress = AppState.volume
        musicValue.text = AppState.musicTitle
        musicState.text = when {
            !virtual -> if (AppState.musicPlaying) "▶ Controlando o app de música" else "App de música do celular"
            AppState.musicPlaying -> "▶ Tocando (simulado)"
            else -> "⏸ Pausada"
        }
        btValue.text = AppState.bluetooth
        btValue.setTextColor(getColor(if (AppState.bluetooth.startsWith("Conectado")) R.color.ok else R.color.text))
        aiValue.text = AppState.aiStatus
        aiValue.setTextColor(getColor(if (AppState.aiStatus.startsWith("Erro")) R.color.err else R.color.text))

        renderHistory()
        if (st != lastStatus) { renderOrb(st); lastStatus = st }
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        if (AppState.history.isEmpty()) {
            historyList.addView(line("Nenhum comando ainda. Diga: “Metralha, coloca o ar em 19”.", R.color.muted, 13f))
            return
        }
        for (h in AppState.history) {
            historyList.addView(line("${h.time}  “${h.heard}”", R.color.text, 14f).apply { setPadding(0, dp(10), 0, 0) })
            historyList.addView(line(h.json, R.color.accent, 12f).apply { typeface = android.graphics.Typeface.MONOSPACE })
            historyList.addView(line("→ ${h.reply}", R.color.muted, 13f))
        }
    }

    private fun line(text: String, color: Int, size: Float) = TextView(this).apply {
        this.text = text
        setTextColor(getColor(color))
        textSize = size
    }

    private fun renderOrb(st: ListenStatus) {
        val color = when (st) {
            ListenStatus.OUVINDO -> getColor(R.color.accent_dim)
            ListenStatus.ATIVADA -> getColor(R.color.accent)
            ListenStatus.PROCESSANDO -> getColor(R.color.warn)
            ListenStatus.FALANDO -> getColor(R.color.ok)
            ListenStatus.CONFIRMANDO -> getColor(R.color.warn)
            ListenStatus.ERRO -> getColor(R.color.err)
            ListenStatus.INICIANDO, ListenStatus.PARADA -> getColor(R.color.muted)
        }
        val glow = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(65).toFloat()
            colors = intArrayOf(withAlpha(color, 150), withAlpha(color, 40), Color.TRANSPARENT)
        }
        orb.background = glow
        orbCore.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }

        pulse?.cancel()
        orb.scaleX = 1f; orb.scaleY = 1f
        val (amount, ms) = when (st) {
            ListenStatus.OUVINDO -> 1.08f to 2200L
            ListenStatus.ATIVADA, ListenStatus.CONFIRMANDO -> 1.25f to 600L
            ListenStatus.PROCESSANDO, ListenStatus.FALANDO -> 1.18f to 400L
            else -> 1f to 0L
        }
        if (ms > 0) {
            pulse = ObjectAnimator.ofPropertyValuesHolder(
                orb,
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, amount),
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, amount)
            ).apply {
                duration = ms
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                start()
            }
        }
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_PERMS = 1
    }
}
