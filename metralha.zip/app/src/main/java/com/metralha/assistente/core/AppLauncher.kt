package com.metralha.assistente.core

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.metralha.assistente.brain.TextUtils

/**
 * Abre aplicativos pelo nome, pesquisa no YouTube / Netflix / Google e abre sites.
 * Funciona no celular e também na multimídia do carro, se ela for Android.
 */
class AppLauncher(private val ctx: Context) {

    private val pm = ctx.packageManager

    private val aliases = mapOf(
        "zap" to "whatsapp", "zapzap" to "whatsapp", "whats" to "whatsapp", "insta" to "instagram",
        "face" to "facebook", "yt" to "youtube", "you tube" to "youtube", "navegador" to "chrome",
        "internet" to "chrome", "google maps" to "maps", "mapas" to "maps", "musica" to "spotify",
        "netflix" to "netflix", "prime" to "prime video", "globo play" to "globoplay", "tik tok" to "tiktok"
    )

    private data class AppEntry(val label: String, val norm: String, val pkg: String)

    private fun installedApps(): List<AppEntry> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).mapNotNull { ri ->
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == ctx.packageName) return@mapNotNull null
            val label = ri.loadLabel(pm)?.toString() ?: return@mapNotNull null
            AppEntry(label, TextUtils.norm(label), pkg)
        }.distinctBy { it.pkg }
    }

    private fun findApp(spoken: String): AppEntry? {
        var q = TextUtils.norm(spoken)
        aliases[q]?.let { q = it }
        if (q.isBlank()) return null
        val apps = installedApps()
        apps.firstOrNull { it.norm == q }?.let { return it }
        apps.firstOrNull { it.norm.replace(" ", "") == q.replace(" ", "") }?.let { return it }
        apps.firstOrNull { it.norm.startsWith(q) || q.startsWith(it.norm) }?.let { return it }
        apps.filter { it.norm.contains(q) }.minByOrNull { it.norm.length }?.let { return it }
        apps.firstOrNull { it.pkg.contains(q.replace(" ", "")) }?.let { return it }
        // parecido (erros do reconhecimento)
        return apps.map { it to similarity(it.norm, q) }.filter { it.second >= 0.7 }.maxByOrNull { it.second }?.first
    }

    fun open(spoken: String): String {
        val app = findApp(spoken) ?: return "Não encontrei o aplicativo $spoken instalado."
        val i = pm.getLaunchIntentForPackage(app.pkg) ?: return "Não consigo abrir o ${app.label}."
        return result(Launcher.launch(ctx, i, "Abrir ${app.label}"), "Abrindo ${app.label}.")
    }

    fun search(service: String, query: String?): String {
        val q = query?.takeIf { it.isNotBlank() }
        return when (service) {
            "youtube" -> {
                val pkg = packageFor("com.google.android.youtube", "youtube")
                if (q == null) return if (pkg != null) open("youtube") else website("https://www.youtube.com")
                val i = Intent(Intent.ACTION_SEARCH).putExtra(SearchManager.QUERY, q)
                if (pkg != null) i.setPackage(pkg)
                if (pkg != null && i.resolveActivity(pm) != null) result(Launcher.launch(ctx, i, "YouTube: $q"), "Procurando $q no YouTube.")
                else view("https://www.youtube.com/results?search_query=" + Uri.encode(q), pkg, "Procurando $q no YouTube.")
            }
            "netflix" -> {
                val pkg = packageFor("com.netflix.mediaclient", "netflix")
                if (q == null) return if (pkg != null) open("netflix") else website("https://www.netflix.com")
                view("https://www.netflix.com/search?q=" + Uri.encode(q), pkg, "Procurando $q na Netflix.")
            }
            else -> {
                if (q == null) return open("chrome")
                val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
                if (i.resolveActivity(pm) != null) result(Launcher.launch(ctx, i, "Pesquisar $q"), "Pesquisando $q.")
                else view("https://www.google.com/search?q=" + Uri.encode(q), null, "Pesquisando $q.")
            }
        }
    }

    fun website(url: String): String {
        val host = Uri.parse(url).host ?: url
        return view(url, null, "Abrindo $host.")
    }

    fun home(): String {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return result(Launcher.launch(ctx, i, "Tela inicial"), "Voltando para a tela inicial.")
    }

    private fun view(url: String, pkg: String?, ok: String): String {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (pkg != null) {
            i.setPackage(pkg)
            if (i.resolveActivity(pm) == null) i.setPackage(null)
        }
        return result(Launcher.launch(ctx, i, ok), ok)
    }

    private fun packageFor(preferred: String, label: String): String? {
        if (pm.getLaunchIntentForPackage(preferred) != null) return preferred
        return findApp(label)?.pkg
    }

    private fun result(r: Launcher.Result, ok: String) = when (r) {
        Launcher.Result.STARTED -> ok
        Launcher.Result.NOTIFIED -> "Toque na notificação para abrir."
        Launcher.Result.NO_APP -> "Não encontrei um app para isso."
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return 1.0 - dp[b.length].toDouble() / maxOf(a.length, b.length)
    }
}
