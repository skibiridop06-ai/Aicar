package com.metralha.assistente.core

import android.os.Handler
import android.os.Looper

/** Lembretes/timers locais. Funcionam com a tela apagada enquanto o Metralha estiver ouvindo. */
class TimerManager(private val onFire: (label: String?) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var label: String? = null
    private val fire = Runnable {
        AppState.timerEndAt = 0
        AppState.timerLabel = ""
        AppState.changed()
        onFire(label)
    }

    fun set(seconds: Int, label: String?): String {
        main.removeCallbacks(fire)
        this.label = label
        AppState.timerEndAt = System.currentTimeMillis() + seconds * 1000L
        AppState.timerLabel = label ?: "Timer"
        AppState.changed()
        main.postDelayed(fire, seconds * 1000L)
        val what = if (label != null) "Vou te lembrar de $label" else "Timer criado"
        return "$what em ${describe(seconds)}."
    }

    fun cancel(): String {
        if (AppState.timerEndAt == 0L) return "Não tem nenhum timer ativo."
        main.removeCallbacks(fire)
        AppState.timerEndAt = 0
        AppState.timerLabel = ""
        AppState.changed()
        return "Timer cancelado."
    }

    companion object {
        fun describe(seconds: Int): String {
            val h = seconds / 3600
            val m = (seconds % 3600) / 60
            val s = seconds % 60
            val parts = mutableListOf<String>()
            if (h > 0) parts += if (h == 1) "1 hora" else "$h horas"
            if (m > 0) parts += if (m == 1) "1 minuto" else "$m minutos"
            if (s > 0) parts += if (s == 1) "1 segundo" else "$s segundos"
            return parts.joinToString(" e ")
        }
    }
}
