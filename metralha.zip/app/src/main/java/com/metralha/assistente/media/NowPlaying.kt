package com.metralha.assistente.media

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import com.metralha.assistente.core.AppState

/**
 * Serviço vazio exigido pelo Android para que o Metralha possa ENXERGAR e CONTROLAR
 * o player que está tocando (Spotify, YouTube Music...). Você libera em
 * "Acesso a notificações". O Metralha não lê nem guarda suas notificações.
 */
class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() {
        NowPlaying.start(applicationContext)
        // Se o Maps já estiver navegando quando o Metralha conectar
        try { activeNotifications?.forEach { NavInfo.onPosted(it) } } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: android.service.notification.StatusBarNotification?) {
        if (sbn != null) NavInfo.onPosted(sbn)
    }

    override fun onNotificationRemoved(sbn: android.service.notification.StatusBarNotification?) {
        if (sbn != null) NavInfo.onRemoved(sbn)
    }
}

/** Acompanha o que está tocando no celular e expõe os controles do player ativo. */
object NowPlaying {
    private val main = Handler(Looper.getMainLooper())
    private var manager: MediaSessionManager? = null
    private var current: MediaController? = null
    private var comp: ComponentName? = null
    private var started = false

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pick(list ?: emptyList())
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() { current = null; refresh() }
    }

    fun isAllowed(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(ctx.packageName)
    }

    fun start(ctx: Context) {
        if (!isAllowed(ctx)) return
        try {
            val m = ctx.getSystemService(MediaSessionManager::class.java)
            val c = ComponentName(ctx, MediaListener::class.java)
            comp = c
            if (!started) {
                m.addOnActiveSessionsChangedListener(sessionsListener, c, main)
                started = true
            }
            manager = m
            pick(m.getActiveSessions(c))
        } catch (e: SecurityException) {
            started = false
        }
    }

    private fun refresh() {
        val m = manager ?: return
        try { pick(m.getActiveSessions(comp)) } catch (_: Exception) {}
    }

    private fun pick(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        if (best?.sessionToken != current?.sessionToken) {
            current?.unregisterCallback(callback)
            current = best
            best?.registerCallback(callback, main)
        }
        publish()
    }

    private fun publish() {
        val c = current
        if (c == null) {
            AppState.musicPlaying = false
            AppState.changed()
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (!title.isNullOrBlank()) {
            AppState.musicTitle = title
            AppState.musicArtist = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        }
        AppState.musicApp = appName(c.packageName)
        AppState.musicPlaying = c.playbackState?.state == PlaybackState.STATE_PLAYING
        AppState.changed()
    }

    /** Controlador do app pedido (ou do player ativo, se package == null). */
    fun controller(pkg: String?): MediaController? {
        val m = manager ?: return null
        return try {
            val list = m.getActiveSessions(comp)
            if (pkg == null) list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
            else list.firstOrNull { it.packageName == pkg }
        } catch (e: Exception) { current?.takeIf { pkg == null || it.packageName == pkg } }
    }

    private fun appName(pkg: String) = when (pkg) {
        "com.spotify.music" -> "Spotify"
        "com.google.android.apps.youtube.music" -> "YouTube Music"
        "com.google.android.youtube" -> "YouTube"
        "deezer.android.app" -> "Deezer"
        else -> pkg.substringAfterLast('.')
    }
}
