package com.metralha.assistente.voice

import android.content.Context
import com.metralha.assistente.brain.WakeWord
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * Reconhecimento de voz 100% LOCAL com Vosk (open source, offline).
 * O áudio nunca sai do celular: aqui ele vira texto, e só o texto do comando
 * (depois de "Metralha") pode ser enviado para a IA online, se você configurar uma.
 */
class VoiceEngine(private val ctx: Context, private val listener: Listener) : RecognitionListener {

    interface Listener {
        fun onEngineReady()
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onEngineError(msg: String)
    }

    private var model: Model? = null
    private var service: SpeechService? = null
    private var recognizer: Recognizer? = null
    private var loading = false
    private var paused = false

    var grammarMode = false
        private set

    val isRunning: Boolean get() = service != null

    /** Copia o modelo de voz em português (embutido no app) e carrega. Só demora na 1ª vez. */
    fun load() {
        if (model != null) { listener.onEngineReady(); return }
        if (loading) return
        loading = true
        StorageService.unpack(ctx, "model-pt", "model",
            { m ->
                loading = false
                model = m
                listener.onEngineReady()
            },
            { e ->
                loading = false
                listener.onEngineError("Modelo de voz não encontrado/corrompido: ${e.message}")
            })
    }

    /** grammar=true: só procura "Metralha" (modo econômico). false: entende frases completas. */
    fun start(grammar: Boolean) {
        val m = model ?: return
        stopService(cancel = true)
        grammarMode = grammar
        try {
            val rec = if (grammar) Recognizer(m, SAMPLE_RATE, WakeWord.GRAMMAR_JSON) else Recognizer(m, SAMPLE_RATE)
            recognizer = rec
            val s = SpeechService(rec, SAMPLE_RATE)
            service = s
            s.startListening(this)
            s.setPause(paused)
        } catch (e: Exception) {
            stopService()
            listener.onEngineError("Não consegui abrir o microfone: ${e.message}")
        }
    }

    /** Pausa o microfone enquanto o Metralha fala (para não ouvir a si mesmo). */
    fun setPaused(p: Boolean) {
        paused = p
        service?.setPause(p)
    }

    /** Para o microfone SEM disparar resultado final (usado ao passar a vez para o reconhecedor do Android). */
    fun cancelService() = stopService(cancel = true)

    fun stopService(cancel: Boolean = false) {
        service?.let {
            try { if (cancel) it.cancel() else it.stop() } catch (_: Exception) {}
            try { it.shutdown() } catch (_: Exception) {}
        }
        service = null
        recognizer?.let { try { it.close() } catch (_: Exception) {} }
        recognizer = null
    }

    fun release() {
        stopService()
        model?.let { try { it.close() } catch (_: Exception) {} }
        model = null
    }

    // ----- callbacks do Vosk (chegam na thread principal) -----
    override fun onPartialResult(hypothesis: String?) = listener.onPartial(read(hypothesis, "partial"))

    override fun onResult(hypothesis: String?) {
        val t = read(hypothesis, "text")
        if (t.isNotBlank()) listener.onFinal(t)
    }

    override fun onFinalResult(hypothesis: String?) = onResult(hypothesis)

    override fun onError(exception: Exception?) {
        listener.onEngineError("Erro no reconhecimento: ${exception?.message}")
    }

    override fun onTimeout() {}

    private fun read(json: String?, key: String): String = try {
        JSONObject(json ?: "{}").optString(key, "").replace("[unk]", "").trim()
    } catch (e: Exception) { "" }

    companion object {
        const val SAMPLE_RATE = 16000f
    }
}
