package com.metralha.assistente.brain

import java.text.Normalizer
import java.util.Locale

/** Utilidades de texto em português (sem dependência de Android, para poder testar). */
object TextUtils {

    /** Minúsculas, sem acentos, sem pontuação: "Coloca o ar-condicionado em 19°!" -> "coloca o ar condicionado em 19" */
    fun norm(s: String): String {
        val lower = s.lowercase(Locale.ROOT)
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return noAccents.replace(Regex("[^a-z0-9%]+"), " ").trim().replace(Regex(" +"), " ")
    }

    /** true se alguma das expressões aparece como palavra(s) inteira(s). */
    fun has(norm: String, vararg phrases: String): Boolean {
        val padded = " $norm "
        return phrases.any { padded.contains(" $it ") }
    }

    /**
     * Encontra o primeiro gatilho (o mais longo naquela posição) e devolve o texto depois dele.
     * Ex.: after("me leva para a praia", ["me leva para"]) -> "a praia"
     */
    fun after(norm: String, triggers: List<String>): String? {
        val padded = " $norm "
        var bestIdx = Int.MAX_VALUE
        var bestTrig: String? = null
        for (t in triggers) {
            val idx = padded.indexOf(" $t ")
            if (idx < 0) continue
            if (idx < bestIdx || (idx == bestIdx && t.length > (bestTrig?.length ?: 0))) {
                bestIdx = idx
                bestTrig = t
            }
        }
        val trig = bestTrig ?: return null
        val start = bestIdx + trig.length + 2
        return if (start >= padded.length) "" else padded.substring(start).trim()
    }

    /**
     * Devolve o trecho original (com acentos) que corresponde a uma frase normalizada.
     * restore("Me leva à padaria mais próxima", "padaria mais proxima") -> "padaria mais próxima"
     */
    fun restore(raw: String, normPhrase: String): String {
        val rawTokens = raw.split(Regex("[^\\p{L}\\p{N}%]+")).filter { it.isNotEmpty() }
        val normTokens = rawTokens.map { norm(it) }
        val target = normPhrase.split(" ").filter { it.isNotEmpty() }
        if (target.isEmpty() || normTokens.size != rawTokens.size) return normPhrase
        for (i in 0..normTokens.size - target.size) {
            if ((target.indices).all { normTokens[i + it] == target[it] }) {
                return rawTokens.subList(i, i + target.size).joinToString(" ").lowercase(Locale.ROOT)
            }
        }
        return normPhrase
    }

    private val units = mapOf(
        "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4,
        "cinco" to 5, "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9
    )
    private val teens = mapOf(
        "dez" to 10, "onze" to 11, "doze" to 12, "treze" to 13, "quatorze" to 14, "catorze" to 14,
        "quinze" to 15, "dezesseis" to 16, "dezasseis" to 16, "dezessete" to 17, "dezassete" to 17,
        "dezoito" to 18, "dezenove" to 19, "dezanove" to 19
    )
    private val tens = mapOf(
        "vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50, "sessenta" to 60,
        "setenta" to 70, "oitenta" to 80, "noventa" to 90
    )
    private val hundreds = mapOf(
        "cem" to 100, "cento" to 100, "duzentos" to 200, "duzentas" to 200, "trezentos" to 300,
        "trezentas" to 300, "quatrocentos" to 400, "quatrocentas" to 400, "quinhentos" to 500,
        "quinhentas" to 500, "seiscentos" to 600, "seiscentas" to 600, "setecentos" to 700,
        "setecentas" to 700, "oitocentos" to 800, "oitocentas" to 800, "novecentos" to 900, "novecentas" to 900
    )
    private val digits = Regex("^\\d{1,9}%?$")

    fun wordValue(w: String): Int? = units[w] ?: teens[w] ?: tens[w] ?: hundreds[w]

    fun isNumberToken(w: String) = digits.matches(w) || wordValue(w) != null || w == "mil"

    /**
     * Lê um número que começa em tokens[i] ("vinte e dois", "mil e quinhentos", "350").
     * Devolve (valor, próximo índice) ou null.
     */
    fun numberAt(t: List<String>, start: Int): Pair<Long, Int>? {
        if (start >= t.size) return null
        val first = t[start]
        if (digits.matches(first)) return first.trimEnd('%').toLong() to start + 1
        if (wordValue(first) == null && first != "mil") return null

        var total = 0L
        var current = 0L
        var i = start
        var expectNumber = true
        while (i < t.size) {
            val w = t[i]
            if (w == "e" && !expectNumber && i + 1 < t.size && (wordValue(t[i + 1]) != null)) {
                expectNumber = true; i++; continue
            }
            if (!expectNumber && w != "mil") break
            when {
                w == "mil" -> { current = (if (current == 0L) 1 else current) * 1000; total += current; current = 0; expectNumber = false }
                wordValue(w) != null -> { current += wordValue(w)!!; expectNumber = false }
                else -> break
            }
            i++
        }
        return (total + current) to i
    }

    /** Todos os números do texto, por extenso ou em algarismos. */
    fun numbers(norm: String): List<Int> {
        val t = norm.split(" ").filter { it.isNotEmpty() }
        val out = mutableListOf<Int>()
        var i = 0
        while (i < t.size) {
            val r = numberAt(t, i)
            if (r != null) {
                out += r.first.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                i = r.second
            } else i++
        }
        return out
    }
}
