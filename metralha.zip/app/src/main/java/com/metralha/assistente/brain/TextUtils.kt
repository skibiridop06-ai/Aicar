package com.metralha.assistente.brain

import java.text.Normalizer
import java.util.Locale

/** Utilidades de texto em português (sem dependência de Android, para poder testar). */
object TextUtils {

    /** Minúsculas, sem acentos, sem pontuação: "Coloca o ar-condicionado em 19°!" -> "coloca o ar condicionado em 19" */
    fun norm(s: String): String {
        val lower = s.lowercase(Locale.ROOT)
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return noAccents.replace(Regex("[^a-z0-9%]+"), " ").trim().replace(Regex(" +"), " ")
    }

    /** true se alguma das expressões aparece como palavra(s) inteira(s). */
    fun has(norm: String, vararg phrases: String): Boolean {
        val padded = " $norm "
        return phrases.any { padded.contains(" $it ") }
    }

    /**
     * Encontra o primeiro gatilho (o mais longo naquela posição) e devolve o texto depois dele.
     * Ex.: after("me leva para a praia", ["me leva para"]) -> "a praia"
     */
    fun after(norm: String, triggers: List<String>): String? {
        val padded = " $norm "
        var bestIdx = Int.MAX_VALUE
        var bestTrig: String? = null
        for (t in triggers) {
            val idx = padded.indexOf(" $t ")
            if (idx < 0) continue
            if (idx < bestIdx || (idx == bestIdx && t.length > (bestTrig?.length ?: 0))) {
                bestIdx = idx
                bestTrig = t
            }
        }
        val trig = bestTrig ?: return null
        val start = bestIdx + trig.length + 2
        return if (start >= padded.length) "" else padded.substring(start).trim()
    }

    private val units = mapOf(
        "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4,
        "cinco" to 5, "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9
    )
    private val teens = mapOf(
        "dez" to 10, "onze" to 11, "doze" to 12, "treze" to 13, "quatorze" to 14, "catorze" to 14,
        "quinze" to 15, "dezesseis" to 16, "dezasseis" to 16, "dezessete" to 17, "dezassete" to 17,
        "dezoito" to 18, "dezenove" to 19, "dezanove" to 19
    )
    private val tens = mapOf(
        "vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50, "sessenta" to 60,
        "setenta" to 70, "oitenta" to 80, "noventa" to 90
    )
    private val digits = Regex("^\\d{1,3}%?$")

    /**
     * Extrai números escritos com algarismos ou por extenso (o reconhecedor de voz
     * costuma devolver "dezenove", "vinte e dois"...).
     */
    fun numbers(norm: String): List<Int> {
        val t = norm.split(" ").filter { it.isNotEmpty() }
        val out = mutableListOf<Int>()
        var i = 0
        while (i < t.size) {
            val w = t[i]
            when {
                digits.matches(w) -> { out += w.trimEnd('%').toInt(); i++ }
                w == "cem" -> { out += 100; i++ }
                tens.containsKey(w) -> {
                    var v = tens.getValue(w)
                    if (i + 2 < t.size && t[i + 1] == "e" && units.containsKey(t[i + 2])) {
                        v += units.getValue(t[i + 2]); i += 3
                    } else i++
                    out += v
                }
                teens.containsKey(w) -> { out += teens.getValue(w); i++ }
                units.containsKey(w) -> { out += units.getValue(w); i++ }
                else -> i++
            }
        }
        return out
    }
}
