package com.metralha.assistente.brain

import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Calculadora por voz, 100% offline.
 * "quanto é vinte e cinco vezes quatro", "raiz quadrada de 81", "15 por cento de 200",
 * "dois elevado a dez", "sete ao quadrado", "100 dividido por 8".
 */
object Calculator {

    private val TRIGGERS = listOf(
        "quanto e", "quanto da", "quanto que e", "quanto que da", "calcula", "calcule", "calcular",
        "qual o resultado de", "qual e o resultado de", "faz a conta", "faca a conta", "conta"
    )

    /** Retorna a resposta falada, ou null se não for uma conta. */
    fun answer(raw: String): String? {
        val t = prepare(raw)
        val tokens = t.split(" ").filter { it.isNotEmpty() }
        val norm = tokens.joinToString(" ")
        val hasTrigger = TRIGGERS.any { " $norm ".contains(" $it ") }
        val hasMath = tokens.any { it in OPS || it in setOf("raiz", "quadrado", "cubo", "elevado", "porcento", "+", "-", "*", "/", "x") }
        if (!hasMath) return null
        if (!hasTrigger && TextUtils.numbers(norm.replace(".", " ")).size < 2 && !norm.contains("raiz")) return null

        val value = try { evaluate(tokens) } catch (e: Exception) { null } ?: return null
        if (value.isNaN() || value.isInfinite()) return "Essa conta não tem resultado. Divisão por zero, talvez?"
        return "Dá ${format(value)}."
    }

    private val OPS = mapOf(
        "mais" to '+', "+" to '+', "menos" to '-', "-" to '-',
        "vezes" to '*', "x" to '*', "*" to '*', "multiplicado" to '*',
        "dividido" to '/', "/" to '/', "sobre" to '/'
    )

    private fun prepare(raw: String): String {
        var s = raw.lowercase(Locale.ROOT)
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        s = s.replace(Regex("(\\d),(\\d)"), "$1.$2")          // 2,5 -> 2.5
        s = s.replace(Regex("(\\d)\\.(\\d{3})(?!\\d)"), "$1$2") // 1.000 -> 1000
        s = s.replace("×", " x ").replace("÷", " / ")
        s = s.replace(Regex("([+\\-*/])"), " $1 ")
        s = s.replace("%", " porcento ").replace("por cento", "porcento")
        s = s.replace(Regex("[^a-z0-9.+\\-*/ ]+"), " ")
        return s.trim().replace(Regex(" +"), " ")
    }

    // ---------- avaliação com precedência ----------
    private fun evaluate(tokens: List<String>): Double? {
        val vals = mutableListOf<Double>()
        val ops = mutableListOf<Char>()
        var i = 0
        var expectValue = true
        while (i < tokens.size) {
            val w = tokens[i]
            if (expectValue) {
                if (w == "raiz") { // raiz quadrada de N
                    var j = i + 1
                    while (j < tokens.size && tokens[j] in setOf("quadrada", "de", "do", "da")) j++
                    val (n, next) = readNumber(tokens, j) ?: return null
                    vals += sqrt(n); i = next; expectValue = false; continue
                }
                val r = readNumber(tokens, i)
                if (r == null) { i++; continue } // ignora palavras ("quanto", "e"...)
                var (n, next) = r
                // pós-fixos: ao quadrado, ao cubo, elevado a N, por cento de N
                while (next < tokens.size) {
                    val p = tokens[next]
                    if (p == "ao" && next + 1 < tokens.size && tokens[next + 1] == "quadrado") { n = n * n; next += 2; continue }
                    if (p == "ao" && next + 1 < tokens.size && tokens[next + 1] == "cubo") { n = n * n * n; next += 2; continue }
                    if (p == "elevado") {
                        var j = next + 1
                        if (j < tokens.size && tokens[j] in setOf("a", "ao", "na")) j++
                        val (e, nx) = readNumber(tokens, j) ?: return null
                        n = n.pow(e); next = nx; continue
                    }
                    if (p == "porcento") {
                        var j = next + 1
                        if (j < tokens.size && tokens[j] in setOf("de", "do", "da")) j++
                        val base = readNumber(tokens, j)
                        if (base != null) { n = n / 100.0 * base.first; next = base.second } else { n /= 100.0; next = j }
                        continue
                    }
                    break
                }
                vals += n; i = next; expectValue = false
            } else {
                val op = OPS[w]
                if (op != null) {
                    var j = i + 1
                    if (j < tokens.size && tokens[j] == "por") j++ // multiplicado por / dividido por
                    while (ops.isNotEmpty() && prec(ops.last()) >= prec(op)) apply(vals, ops.removeAt(ops.size - 1))
                    ops += op; i = j; expectValue = true
                } else i++
            }
        }
        if (vals.isEmpty()) return null
        if (expectValue && ops.isNotEmpty()) return null
        while (ops.isNotEmpty()) apply(vals, ops.removeAt(ops.size - 1))
        return if (vals.size == 1) vals[0] else null
    }

    private fun readNumber(t: List<String>, i: Int): Pair<Double, Int>? {
        if (i >= t.size) return null
        t[i].toDoubleOrNull()?.let { return it to i + 1 }
        val r = TextUtils.numberAt(t, i) ?: return null
        var v = r.first.toDouble()
        var next = r.second
        // "dois e meio"
        if (next + 1 < t.size && t[next] == "e" && t[next + 1] == "meio") { v += 0.5; next += 2 }
        return v to next
    }

    private fun prec(op: Char) = if (op == '+' || op == '-') 1 else 2

    private fun apply(vals: MutableList<Double>, op: Char) {
        val b = vals.removeAt(vals.size - 1)
        val a = vals.removeAt(vals.size - 1)
        vals += when (op) { '+' -> a + b; '-' -> a - b; '*' -> a * b; else -> a / b }
    }

    fun format(v: Double): String {
        if (abs(v - Math.round(v)) < 1e-9 && abs(v) < 1e15) return Math.round(v).toString()
        val s = String.format(Locale.ROOT, "%.2f", v).trimEnd('0').trimEnd('.')
        return s.replace('.', ',')
    }
}
