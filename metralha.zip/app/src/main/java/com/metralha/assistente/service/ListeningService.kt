package com.metralha.assistente.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.metralha.assistente.MainActivity
import com.metralha.assistente.R
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.MetralhaCore

/**
 * Mantém o microfone ouvindo "Metralha" mesmo com outro app na frente (Spotify, Maps).
 * O Android exige uma notificação fixa enquanto isso acontece — é transparência para você.
 */
class ListeningService : Service() {

    /** Mantém o processador acordado com a TELA APAGADA, para continuar ouvindo "Metralha". */
    private var wakeLock: PowerManager.WakeLock? = null

    private fun holdWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Metralha::Escuta")
            .apply { setReferenceCounted(false); acquire() }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            MetralhaCore.stopListening()
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Metralha ouvindo", NotificationManager.IMPORTANCE_LOW)
        )

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListeningService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("Metralha está ouvindo")
            .setContentText("Funciona com a tela apagada. Tudo processado no celular, sem internet.")
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_mic), "Parar", stop).build())
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
        } catch (e: Exception) {
            AppState.detail = "O Android não deixou iniciar a escuta em segundo plano: ${e.message}"
            AppState.changed()
            stopSelf()
            return START_NOT_STICKY
        }

        holdWakeLock()
        MetralhaCore.init(this)
        MetralhaCore.startListening()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseWakeLock()
        MetralhaCore.stopListening()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "metralha_escuta"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.metralha.assistente.STOP"
    }
}
