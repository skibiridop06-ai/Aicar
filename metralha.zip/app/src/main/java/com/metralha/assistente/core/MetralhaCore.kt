package com.metralha.assistente.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.metralha.assistente.brain.Command
import com.metralha.assistente.brain.CommandValidator
import com.metralha.assistente.brain.Json
import com.metralha.assistente.brain.LocalBrain
import com.metralha.assistente.brain.LocalParser
import com.metralha.assistente.brain.TextUtils
import com.metralha.assistente.brain.Validation
import com.metralha.assistente.brain.WakeWord
import com.metralha.assistente.media.NowPlaying
import com.metralha.assistente.voice.Speaker
import com.metralha.assistente.voice.VoiceEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Liga tudo, 100% dentro do celular:
 *   microfone (Vosk) -> "Metralha" -> cérebro local -> VALIDADOR -> executor -> voz.
 * Nenhuma IA externa, nenhuma API, nenhuma conta.
 */
object MetralhaCore : VoiceEngine.Listener {

    private enum class Awaiting { NONE, COMMAND, CONFIRM }

    private lateinit var app: Context
    lateinit var settings: Settings
        private set
    lateinit var executor: ActionExecutor
        private set
    private lateinit var timers: TimerManager
    var speaker: Speaker? = null
        private set
    private var engine: VoiceEngine? = null

    private val main = Handler(Looper.getMainLooper())
    private var initialized = false

    var listening = false
        private set
    private var awaiting = Awaiting.NONE
    private var pending: Command? = null
    private val windowTimeout = Runnable { onWindowTimeout() }

    fun init(ctx: Context) {
        if (initialized) return
        app = ctx.applicationContext
        settings = Settings(app)
        timers = TimerManager { label -> onTimerFired(label) }
        executor = ActionExecutor(app, settings, timers)
        speaker = Speaker(app) { speaking ->
            engine?.setPaused(speaking)
            if (speaking) setStatus(ListenStatus.FALANDO) else restoreStatus()
        }
        applyVoice()
        BluetoothMonitor.start(app)
        NowPlaying.start(app)
        executor.music.refreshVolume()
        initialized = true
    }

    fun applyVoice() {
        speaker?.configure(settings.voiceName, settings.speechRate, settings.pitch)
    }

    // ---------------- Escuta ----------------
    fun startListening() {
        if (listening) return
        listening = true
        AppState.detail = ""
        setStatus(ListenStatus.INICIANDO)
        val e = engine ?: VoiceEngine(app, this).also { engine = it }
        e.load()
    }

    fun stopListening() {
        listening = false
        engine?.stopService()
        clearWindow()
        setStatus(ListenStatus.PARADA)
    }

    fun applySettings() {
        executor.music.refreshVolume()
        if (listening && awaiting == Awaiting.NONE && engine?.isRunning == true) {
            engine?.start(grammar = settings.economyMode)
        }
        AppState.changed()
    }

    override fun onEngineReady() {
        if (!listening) return
        engine?.start(grammar = settings.economyMode)
        if (engine?.isRunning == true) setStatus(ListenStatus.OUVINDO)
    }

    override fun onEngineError(msg: String) {
        AppState.detail = msg
        setStatus(ListenStatus.ERRO)
    }

    override fun onPartial(text: String) {
        if (awaiting != Awaiting.NONE && text != AppState.partial) {
            AppState.partial = text
            AppState.changed()
        }
    }

    override fun onFinal(text: String) {
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        when (awaiting) {
            Awaiting.CONFIRM -> handleConfirmation(norm)
            Awaiting.COMMAND -> {
                val m = WakeWord.find(norm)
                val cmd = if (m.found) m.rest else norm
                if (cmd.isBlank()) { askYes(); return }
                if (isNoise(cmd)) return
                clearWindow()
                processCommand(cmd, typed = false)
            }
            Awaiting.NONE -> {
                val m = WakeWord.find(norm)
                if (!m.found) return // conversa comum: descartada aqui mesmo
                if (m.rest.isBlank() || isNoise(m.rest)) askYes() else processCommand(m.rest, typed = false)
            }
        }
    }

    private fun isNoise(s: String): Boolean {
        val w = s.split(" ")
        return w.size == 1 && w[0].length <= 2 && w[0] != "oi"
    }

    // ---------------- Entradas manuais ----------------
    /** Texto digitado na tela. */
    fun submitTyped(text: String) {
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        if (awaiting == Awaiting.CONFIRM) { handleConfirmation(norm); return }
        clearWindow()
        val m = WakeWord.find(norm)
        processCommand(if (m.found && m.rest.isNotBlank()) m.rest else text, typed = true)
    }

    /** Toque nos botões da tela (clima, volume, música). Passa pelo mesmo validador, sem falar. */
    fun manual(raw: Map<String, Any>) {
        when (val v = CommandValidator.validate(raw)) {
            is Validation.Ok -> executor.execute(v.command)
            is Validation.Rejected -> { AppState.detail = v.reason; AppState.changed() }
        }
    }

    /** Toque na esfera: interrompe a fala ou ativa o Metralha sem precisar dizer o nome. */
    fun tapOrb() {
        val s = speaker
        if (s != null && s.isSpeaking) { s.stop(); return }
        if (!listening) return
        if (awaiting == Awaiting.NONE) askYes() else { clearWindow(); backToIdle() }
    }

    // ---------------- Fluxo de conversa ----------------
    private fun askYes() {
        ensureFullRecognizer()
        setStatus(ListenStatus.ATIVADA)
        speak("Sim?") { openWindow(Awaiting.COMMAND, 8000) }
    }

    private fun processCommand(text: String, typed: Boolean) {
        AppState.partial = ""
        setStatus(ListenStatus.PROCESSANDO)
        val raw = LocalBrain.think(text, LocalBrain.Context(custom = settings.customAnswers))
        finish(text, raw, typed)
    }

    private fun finish(heard: String, raw: Map<String, Any?>, typed: Boolean) {
        when (val v = CommandValidator.validate(raw)) {
            is Validation.Rejected -> {
                record(heard, Json.write(raw), v.reason)
                speakThenIdle(v.reason, followUp = false)
            }
            is Validation.Ok -> {
                val cmd = v.command
                if (cmd.action.needsConfirmation) {
                    pending = cmd
                    record(heard, cmd.toJson(), "Aguardando confirmação…")
                    if (!typed) ensureFullRecognizer()
                    speak(executor.confirmQuestion(cmd)) { openWindow(Awaiting.CONFIRM, 10000) }
                    return
                }
                val reply = executor.execute(cmd)
                record(heard, cmd.toJson(), reply)
                val conversational = cmd.action == com.metralha.assistente.brain.Action.ANSWER
                speakThenIdle(reply, followUp = conversational && !typed)
            }
        }
    }

    private fun handleConfirmation(norm: String) {
        val cmd = pending
        clearWindow()
        if (cmd == null) { backToIdle(); return }
        when {
            LocalParser.isNo(norm) -> { record("Não", cmd.toJson(), "Cancelado."); speakThenIdle("Cancelado.", false) }
            LocalParser.isYes(norm) -> {
                val reply = executor.execute(cmd)
                record("Sim", cmd.toJson(), reply)
                speakThenIdle(reply, false)
            }
            else -> {
                pending = cmd
                speak("Não entendi. Diga sim ou não.") { openWindow(Awaiting.CONFIRM, 8000) }
            }
        }
    }

    private fun onTimerFired(label: String?) {
        val text = if (label != null) "Atenção! Lembrete: $label." else "Atenção! Seu timer terminou."
        Launcher.alert(app, text)
        record("⏰ Lembrete", "{\"action\": \"timer_done\"}", text)
        speakThenIdle(text, false)
    }

    private fun openWindow(kind: Awaiting, ms: Long) {
        awaiting = kind
        main.removeCallbacks(windowTimeout)
        main.postDelayed(windowTimeout, ms)
        setStatus(if (kind == Awaiting.CONFIRM) ListenStatus.CONFIRMANDO else ListenStatus.ATIVADA)
    }

    private fun clearWindow() {
        main.removeCallbacks(windowTimeout)
        awaiting = Awaiting.NONE
        pending = null
        AppState.partial = ""
    }

    private fun onWindowTimeout() {
        clearWindow()
        backToIdle()
    }

    private fun backToIdle() {
        if (awaiting != Awaiting.NONE) return
        if (listening && settings.economyMode && engine?.grammarMode == false && engine?.isRunning == true) {
            engine?.start(grammar = true)
        }
        restoreStatus()
    }

    private fun ensureFullRecognizer() {
        if (listening && engine?.grammarMode == true) engine?.start(grammar = false)
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        val s = speaker
        if (s == null) onDone?.invoke() else s.speak(text, onDone)
    }

    /** Fala e, se for conversa, continua ouvindo alguns segundos sem precisar dizer "Metralha". */
    private fun speakThenIdle(text: String, followUp: Boolean) = speak(text) {
        if (followUp && settings.followUp && listening) {
            ensureFullRecognizer()
            openWindow(Awaiting.COMMAND, 6000)
        } else backToIdle()
    }

    fun testVoice() = speak("Olá! Eu sou o Metralha, seu copiloto. Pronto para a estrada.")

    // ---------------- Estado / tela ----------------
    private fun restoreStatus() {
        val s = when {
            awaiting == Awaiting.CONFIRM -> ListenStatus.CONFIRMANDO
            awaiting == Awaiting.COMMAND -> ListenStatus.ATIVADA
            listening && engine?.isRunning == true -> ListenStatus.OUVINDO
            AppState.status == ListenStatus.ERRO -> ListenStatus.ERRO
            listening -> ListenStatus.INICIANDO
            else -> ListenStatus.PARADA
        }
        setStatus(s)
    }

    private fun setStatus(s: ListenStatus) {
        AppState.status = s
        AppState.changed()
    }

    private fun record(heard: String, json: String, reply: String) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        AppState.addHistory(HistoryItem(time, heard, json, reply))
    }
}
