package com.metralha.assistente.core

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import com.metralha.assistente.brain.Action
import com.metralha.assistente.brain.Command
import com.metralha.assistente.brain.CommandValidator
import com.metralha.assistente.brain.Json
import com.metralha.assistente.brain.LocalBrain
import com.metralha.assistente.brain.LocalParser
import com.metralha.assistente.brain.TextUtils
import com.metralha.assistente.brain.Validation
import com.metralha.assistente.brain.WakeWord
import com.metralha.assistente.media.NowPlaying
import com.metralha.assistente.voice.CommandRecognizer
import com.metralha.assistente.voice.Speaker
import com.metralha.assistente.voice.VoiceEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Liga tudo, dentro do celular:
 *   Vosk (só espera "Metralha") -> reconhecedor do Android (entende o comando com precisão)
 *   -> cérebro local -> VALIDADOR -> executor -> voz.
 * Nenhuma IA externa, nenhuma API, nenhuma conta.
 */
object MetralhaCore : VoiceEngine.Listener, CommandRecognizer.Listener {

    private enum class Awaiting { NONE, COMMAND, CONFIRM }

    private lateinit var app: Context
    lateinit var settings: Settings
        private set
    lateinit var executor: ActionExecutor
        private set
    private lateinit var timers: TimerManager
    var speaker: Speaker? = null
        private set
    private var engine: VoiceEngine? = null
    private var recognizer: CommandRecognizer? = null
    private var androidFailed = false
    private var followUpListen = false

    private val main = Handler(Looper.getMainLooper())
    private var initialized = false
    private var tone: ToneGenerator? = null

    var listening = false
        private set
    private var awaiting = Awaiting.NONE
    private var pending: Command? = null
    private val windowTimeout = Runnable { onWindowTimeout() }

    fun init(ctx: Context) {
        if (initialized) return
        app = ctx.applicationContext
        settings = Settings(app)
        timers = TimerManager { label -> onTimerFired(label) }
        executor = ActionExecutor(app, settings, timers)
        speaker = Speaker(app) { speaking ->
            engine?.setPaused(speaking)
            if (speaking) setStatus(ListenStatus.FALANDO) else restoreStatus()
        }
        recognizer = CommandRecognizer(app, this)
        com.metralha.assistente.media.NavInfo.onNewInstruction = { text -> announceNav(text) }
        applyVoice()
        BluetoothMonitor.start(app)
        NowPlaying.start(app)
        executor.music.refreshVolume()
        initialized = true
    }

    fun applyVoice() {
        speaker?.configure(settings.voiceName, settings.speechRate, settings.pitch)
    }

    private fun useAndroid(): Boolean =
        settings.betterRecognition && !androidFailed && recognizer?.isAvailable() == true

    // ---------------- Escuta ----------------
    fun startListening() {
        if (listening) return
        listening = true
        AppState.detail = ""
        setStatus(ListenStatus.INICIANDO)
        val e = engine ?: VoiceEngine(app, this).also { engine = it }
        e.load()
    }

    fun stopListening() {
        listening = false
        recognizer?.cancel()
        engine?.cancelService()
        clearWindow()
        setStatus(ListenStatus.PARADA)
    }

    fun applySettings() {
        androidFailed = false
        executor.music.refreshVolume()
        if (listening && awaiting == Awaiting.NONE && engine?.isRunning == true) startVosk()
        AppState.changed()
    }

    private fun startVosk() {
        if (!listening) return
        if (recognizer?.active == true) return
        engine?.start(grammar = settings.economyMode && awaiting == Awaiting.NONE)
    }

    override fun onEngineReady() {
        if (!listening) return
        startVosk()
        if (engine?.isRunning == true) setStatus(ListenStatus.OUVINDO)
    }

    override fun onEngineError(msg: String) {
        AppState.detail = msg
        setStatus(ListenStatus.ERRO)
    }

    override fun onPartial(text: String) {
        if (awaiting == Awaiting.NONE) {
            // Ouviu "Metralha" e quase nada depois: passa a vez AGORA para o reconhecedor preciso.
            val m = WakeWord.find(TextUtils.norm(text))
            if (m.found && m.rest.split(" ").filter { it.isNotBlank() }.size <= 1 && useAndroid()) {
                beep()
                startAndroid(Awaiting.COMMAND)
            }
            return
        }
        if (text != AppState.partial) {
            AppState.partial = text
            AppState.changed()
        }
    }

    override fun onFinal(text: String) {
        if (recognizer?.active == true) return
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        when (awaiting) {
            Awaiting.CONFIRM -> handleConfirmation(norm)
            Awaiting.COMMAND -> {
                val m = WakeWord.find(norm)
                val cmd = if (m.found) m.rest else norm
                if (cmd.isBlank()) { askYes(); return }
                if (isNoise(cmd)) return
                clearWindow()
                processCommand(cmd, typed = false)
            }
            Awaiting.NONE -> {
                val m = WakeWord.find(norm)
                if (!m.found) return // conversa comum: descartada aqui mesmo
                if (m.rest.isBlank() || isNoise(m.rest)) askYes() else processCommand(m.rest, typed = false)
            }
        }
    }

    private fun isNoise(s: String): Boolean {
        val w = s.split(" ")
        return w.size == 1 && w[0].length <= 2 && w[0] != "oi"
    }

    // ---------------- Reconhecedor do Android (alta precisão) ----------------
    private fun startAndroid(kind: Awaiting, followUp: Boolean = false) {
        followUpListen = followUp
        engine?.cancelService() // libera o microfone
        awaiting = kind
        main.removeCallbacks(windowTimeout)
        main.postDelayed(windowTimeout, 15000) // segurança
        AppState.partial = ""
        setStatus(if (kind == Awaiting.CONFIRM) ListenStatus.CONFIRMANDO else ListenStatus.ATIVADA)
        recognizer?.start()
    }

    override fun onCommandPartial(text: String) {
        AppState.partial = text
        AppState.changed()
    }

    override fun onCommandResult(alternatives: List<String>) {
        val kind = awaiting
        val wasFollowUp = followUpListen
        main.removeCallbacks(windowTimeout)
        awaiting = Awaiting.NONE
        AppState.partial = ""
        startVosk()

        if (alternatives.isEmpty()) {
            pending = null
            if (kind == Awaiting.COMMAND && !wasFollowUp) speakThenIdle("Não ouvi. Pode chamar de novo.", false)
            else restoreStatus()
            return
        }
        // Tira o "Metralha" do começo e escolhe a alternativa que o cérebro entende.
        val cleaned = alternatives.map { a ->
            val m = WakeWord.find(TextUtils.norm(a))
            if (m.found && m.rest.isNotBlank()) m.rest else if (m.found) "" else a
        }.filter { it.isNotBlank() }
        if (cleaned.isEmpty()) { askYes(); return }

        if (kind == Awaiting.CONFIRM) {
            awaiting = Awaiting.CONFIRM // handleConfirmation espera este estado
            val best = cleaned.firstOrNull { LocalParser.isYes(TextUtils.norm(it)) || LocalParser.isNo(TextUtils.norm(it)) } ?: cleaned[0]
            handleConfirmation(TextUtils.norm(best))
            return
        }
        val best = cleaned.firstOrNull { LocalBrain.understands(it, settings.customAnswers) } ?: cleaned[0]
        processCommand(best, typed = false)
    }

    override fun onCommandUnavailable(reason: String) {
        // Sem o reconhecedor do Android: continua com o Vosk.
        androidFailed = true
        val kind = awaiting
        AppState.detail = "Usando reconhecimento interno ($reason)."
        awaiting = Awaiting.NONE
        if (!listening) return
        engine?.start(grammar = false)
        if (kind != Awaiting.NONE) openWindow(kind, 8000) else restoreStatus()
    }

    private fun beep() {
        try {
            val t = tone ?: ToneGenerator(AudioManager.STREAM_MUSIC, 55).also { tone = it }
            t.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        } catch (_: Exception) {}
    }

    // ---------------- Entradas manuais ----------------
    fun submitTyped(text: String) {
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        if (awaiting == Awaiting.CONFIRM) { handleConfirmation(norm); return }
        recognizer?.cancel()
        clearWindow()
        startVosk()
        val m = WakeWord.find(norm)
        processCommand(if (m.found && m.rest.isNotBlank()) m.rest else text, typed = true)
    }

    fun manual(raw: Map<String, Any>) {
        when (val v = CommandValidator.validate(raw)) {
            is Validation.Ok -> executor.execute(v.command)
            is Validation.Rejected -> { AppState.detail = v.reason; AppState.changed() }
        }
    }

    /** Toque no holograma: interrompe a fala, cancela, ou ativa sem precisar dizer "Metralha". */
    fun tapOrb() {
        val s = speaker
        if (s != null && s.isSpeaking) { s.stop(); return }
        if (!listening) return
        if (recognizer?.active == true) {
            recognizer?.cancel(); clearWindow(); startVosk(); restoreStatus(); return
        }
        if (awaiting != Awaiting.NONE) { clearWindow(); backToIdle(); return }
        if (useAndroid()) { beep(); startAndroid(Awaiting.COMMAND) } else askYes()
    }

    // ---------------- Fluxo de conversa ----------------
    private fun askYes() {
        setStatus(ListenStatus.ATIVADA)
        if (useAndroid()) {
            engine?.cancelService()
            speak("Sim?") { startAndroid(Awaiting.COMMAND) }
        } else {
            ensureFullRecognizer()
            speak("Sim?") { openWindow(Awaiting.COMMAND, 8000) }
        }
    }

    private fun processCommand(text: String, typed: Boolean) {
        AppState.partial = ""
        setStatus(ListenStatus.PROCESSANDO)
        val raw = LocalBrain.think(text, LocalBrain.Context(custom = settings.customAnswers))
        finish(text, raw, typed)
    }

    private fun finish(heard: String, raw: Map<String, Any?>, typed: Boolean) {
        when (val v = CommandValidator.validate(raw)) {
            is Validation.Rejected -> {
                record(heard, Json.write(raw), v.reason)
                speakThenIdle(v.reason, followUp = false)
            }
            is Validation.Ok -> {
                val cmd = v.command
                if (cmd.needsConfirmation()) {
                    pending = cmd
                    record(heard, cmd.toJson(), "Aguardando confirmação…")
                    if (useAndroid() && !typed) {
                        engine?.cancelService()
                        speak(executor.confirmQuestion(cmd)) { val p = pending; startAndroid(Awaiting.CONFIRM); pending = p }
                    } else {
                        if (!typed) ensureFullRecognizer()
                        speak(executor.confirmQuestion(cmd)) { openWindow(Awaiting.CONFIRM, 10000) }
                    }
                    return
                }
                val reply = executor.execute(cmd)
                record(heard, cmd.toJson(), reply)
                speakThenIdle(reply, followUp = cmd.action == Action.ANSWER && !typed)
            }
        }
    }

    private fun handleConfirmation(norm: String) {
        val cmd = pending
        clearWindow()
        if (cmd == null) { backToIdle(); return }
        when {
            LocalParser.isNo(norm) -> { record("Não", cmd.toJson(), "Cancelado."); speakThenIdle("Cancelado.", false) }
            LocalParser.isYes(norm) -> {
                val reply = executor.execute(cmd)
                record("Sim", cmd.toJson(), reply)
                speakThenIdle(reply, false)
            }
            else -> {
                pending = cmd
                if (useAndroid()) {
                    engine?.cancelService()
                    speak("Não entendi. Diga sim ou não.") { startAndroid(Awaiting.CONFIRM); pending = cmd }
                } else speak("Não entendi. Diga sim ou não.") { openWindow(Awaiting.CONFIRM, 8000) }
            }
        }
    }

    private fun onTimerFired(label: String?) {
        val text = if (label != null) "Atenção! Lembrete: $label." else "Atenção! Seu timer terminou."
        Launcher.alert(app, text)
        record("⏰ Lembrete", "{\"action\": \"timer_done\"}", text)
        speakThenIdle(text, false)
    }

    private fun openWindow(kind: Awaiting, ms: Long) {
        awaiting = kind
        main.removeCallbacks(windowTimeout)
        main.postDelayed(windowTimeout, ms)
        setStatus(if (kind == Awaiting.CONFIRM) ListenStatus.CONFIRMANDO else ListenStatus.ATIVADA)
    }

    private fun clearWindow() {
        main.removeCallbacks(windowTimeout)
        awaiting = Awaiting.NONE
        pending = null
        AppState.partial = ""
    }

    private fun onWindowTimeout() {
        recognizer?.cancel()
        clearWindow()
        startVosk()
        backToIdle()
    }

    private fun backToIdle() {
        if (awaiting != Awaiting.NONE) return
        if (listening && engine?.isRunning != true && recognizer?.active != true) startVosk()
        if (listening && settings.economyMode && engine?.grammarMode == false && engine?.isRunning == true) {
            engine?.start(grammar = true)
        }
        restoreStatus()
    }

    private fun ensureFullRecognizer() {
        if (listening && engine?.grammarMode == true) engine?.start(grammar = false)
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        val s = speaker
        if (s == null) onDone?.invoke() else s.speak(text, onDone)
    }

    /** Fala e, se for conversa, continua ouvindo alguns segundos sem precisar dizer "Metralha". */
    private fun speakThenIdle(text: String, followUp: Boolean) = speak(text) {
        if (followUp && settings.followUp && listening) {
            if (useAndroid()) startAndroid(Awaiting.COMMAND, followUp = true)
            else { ensureFullRecognizer(); openWindow(Awaiting.COMMAND, 6000) }
        } else backToIdle()
    }

    /** Instrução nova do GPS: fala, a não ser que você esteja conversando com o Metralha agora. */
    private fun announceNav(text: String, tries: Int = 0) {
        if (!settings.navVoice) return
        if (awaiting != Awaiting.NONE || recognizer?.active == true) return
        if (speaker?.isSpeaking == true && tries < 4) { main.postDelayed({ announceNav(text, tries + 1) }, 1500); return }
        speakThenIdle(text, false)
    }

    fun testVoice() = speak("Olá! Eu sou o Metralha, seu copiloto. Pronto para a estrada.")

    // ---------------- Estado / tela ----------------
    private fun restoreStatus() {
        val s = when {
            awaiting == Awaiting.CONFIRM -> ListenStatus.CONFIRMANDO
            awaiting == Awaiting.COMMAND -> ListenStatus.ATIVADA
            listening && (engine?.isRunning == true || recognizer?.active == true) -> ListenStatus.OUVINDO
            AppState.status == ListenStatus.ERRO -> ListenStatus.ERRO
            listening -> ListenStatus.INICIANDO
            else -> ListenStatus.PARADA
        }
        setStatus(s)
    }

    private fun setStatus(s: ListenStatus) {
        AppState.status = s
        AppState.changed()
    }

    private fun record(heard: String, json: String, reply: String) {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        AppState.addHistory(HistoryItem(time, heard, json, reply))
    }
}
