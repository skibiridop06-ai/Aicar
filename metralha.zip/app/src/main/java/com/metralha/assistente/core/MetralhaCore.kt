package com.metralha.assistente.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.metralha.assistente.brain.Command
import com.metralha.assistente.brain.CommandValidator
import com.metralha.assistente.brain.Json
import com.metralha.assistente.brain.LlmClient
import com.metralha.assistente.brain.LocalParser
import com.metralha.assistente.brain.TextUtils
import com.metralha.assistente.brain.Validation
import com.metralha.assistente.brain.WakeWord
import com.metralha.assistente.voice.Speaker
import com.metralha.assistente.voice.VoiceEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * O "cérebro" que liga tudo:
 *   microfone (Vosk local) -> palavra "Metralha" -> comando -> intérprete local
 *   -> (opcional) IA online -> VALIDADOR -> executor -> resposta falada.
 */
object MetralhaCore : VoiceEngine.Listener {

    private enum class Awaiting { NONE, COMMAND, CONFIRM }

    private lateinit var app: Context
    lateinit var settings: Settings
        private set
    lateinit var executor: ActionExecutor
        private set
    private lateinit var llm: LlmClient
    private var speaker: Speaker? = null
    private var engine: VoiceEngine? = null

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var initialized = false

    var listening = false
        private set
    private var awaiting = Awaiting.NONE
    private var pending: Command? = null
    private val windowTimeout = Runnable { onWindowTimeout() }

    fun init(ctx: Context) {
        if (initialized) return
        app = ctx.applicationContext
        settings = Settings(app)
        llm = LlmClient(settings)
        executor = ActionExecutor(app, settings)
        speaker = Speaker(app) { speaking ->
            engine?.setPaused(speaking)
            if (speaking) setStatus(ListenStatus.FALANDO) else restoreStatus()
        }
        AppState.aiStatus = aiLabel()
        BluetoothMonitor.start(app)
        if (!settings.virtualCar) executor.phone.refreshVolume()
        initialized = true
    }

    // ---------------- Escuta ----------------
    fun startListening() {
        if (listening) return
        listening = true
        AppState.detail = ""
        setStatus(ListenStatus.INICIANDO)
        val e = engine ?: VoiceEngine(app, this).also { engine = it }
        e.load()
    }

    fun stopListening() {
        listening = false
        engine?.stopService()
        clearWindow()
        setStatus(ListenStatus.PARADA)
    }

    /** Chamado quando você muda o modo econômico ou o tipo de carro. */
    fun applySettings() {
        AppState.aiStatus = aiLabel()
        if (!settings.virtualCar) executor.phone.refreshVolume()
        if (listening && awaiting == Awaiting.NONE && engine?.isRunning == true) {
            engine?.start(grammar = settings.economyMode)
        }
        AppState.changed()
    }

    override fun onEngineReady() {
        if (!listening) return
        engine?.start(grammar = settings.economyMode)
        if (engine?.isRunning == true) setStatus(ListenStatus.OUVINDO)
    }

    override fun onEngineError(msg: String) {
        AppState.detail = msg
        setStatus(ListenStatus.ERRO)
    }

    override fun onPartial(text: String) {
        // Só mostra o que está sendo ouvido quando o Metralha está ativado.
        if (awaiting != Awaiting.NONE && text != AppState.partial) {
            AppState.partial = text
            AppState.changed()
        }
    }

    override fun onFinal(text: String) {
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        when (awaiting) {
            Awaiting.CONFIRM -> handleConfirmation(norm)
            Awaiting.COMMAND -> {
                val m = WakeWord.find(norm)
                val cmd = if (m.found) m.rest else norm
                if (cmd.isBlank()) { askYes(); return }
                if (isNoise(cmd)) return
                clearWindow()
                processCommand(cmd, typed = false)
            }
            Awaiting.NONE -> {
                val m = WakeWord.find(norm)
                if (!m.found) return // Conversa normal: descartada aqui mesmo, nada sai do celular.
                if (m.rest.isBlank() || isNoise(m.rest)) askYes() else processCommand(m.rest, typed = false)
            }
        }
    }

    private fun isNoise(s: String): Boolean {
        val w = s.split(" ")
        return w.size == 1 && w[0].length <= 2
    }

    /** Comando digitado na área de teste (para testar sem falar). */
    fun submitTyped(text: String) {
        val norm = TextUtils.norm(text)
        if (norm.isBlank()) return
        if (awaiting == Awaiting.CONFIRM) { handleConfirmation(norm); return }
        clearWindow()
        val m = WakeWord.find(norm)
        processCommand(if (m.found && m.rest.isNotBlank()) m.rest else norm, typed = true)
    }

    // ---------------- Fluxo de conversa ----------------
    private fun askYes() {
        ensureFullRecognizer()
        setStatus(ListenStatus.ATIVADA)
        speak("Sim?") { openWindow(Awaiting.COMMAND, 8000) }
    }

    private fun processCommand(text: String, typed: Boolean) {
        AppState.partial = ""
        setStatus(ListenStatus.PROCESSANDO)
        val local = LocalParser.parse(text)
        if (local != null) {
            finish(text, local, typed)
            return
        }
        if (!llm.isConfigured()) {
            val reply = "Não entendi esse comando. Para perguntas livres, configure a IA gratuita nas configurações."
            record(text, "{\"action\": \"desconhecido\"}", reply)
            speakThenIdle(reply)
            return
        }
        AppState.aiStatus = "Consultando IA…"
        AppState.changed()
        val carState = executor.contextSummary()
        io.execute {
            val result = runCatching { llm.interpret(text, carState) }
            main.post {
                result.onSuccess {
                    AppState.aiStatus = "Online · ${settings.model}"
                    finish(text, it, typed)
                }.onFailure {
                    AppState.aiStatus = "Erro: ${it.message?.take(70)}"
                    val reply = "Não consegui falar com a IA agora."
                    record(text, "{\"erro\": \"IA indisponível\"}", reply)
                    speakThenIdle(reply)
                }
            }
        }
    }

    private fun finish(heard: String, raw: Map<String, Any?>, typed: Boolean) {
        when (val v = CommandValidator.validate(raw)) {
            is Validation.Rejected -> {
                record(heard, Json.write(raw), "Bloqueado: ${v.reason}")
                speakThenIdle(v.reason)
            }
            is Validation.Ok -> {
                val cmd = v.command
                if (cmd.action.needsConfirmation) {
                    pending = cmd
                    record(heard, cmd.toJson(), "Aguardando confirmação")
                    if (!typed) ensureFullRecognizer()
                    speak(executor.confirmQuestion(cmd)) { openWindow(Awaiting.CONFIRM, 10000) }
                    return
                }
                val reply = executor.execute(cmd)
                record(heard, cmd.toJson(), reply)
                speakThenIdle(reply)
            }
        }
    }

    private fun handleConfirmation(norm: String) {
        val cmd = pending
        clearWindow()
        if (cmd == null) { backToIdle(); return }
        when {
            LocalParser.isNo(norm) -> { record("(confirmação) $norm", cmd.toJson(), "Cancelado"); speakThenIdle("Cancelado.") }
            LocalParser.isYes(norm) -> {
                val reply = executor.execute(cmd)
                record("(confirmação) $norm", cmd.toJson(), reply)
                speakThenIdle(reply)
            }
            else -> {
                pending = cmd
                speak("Não entendi. Diga sim ou não.") { openWindow(Awaiting.CONFIRM, 8000) }
            }
        }
    }

    private fun openWindow(kind: Awaiting, ms: Long) {
        awaiting = kind
        main.removeCallbacks(windowTimeout)
        main.postDelayed(windowTimeout, ms)
        setStatus(if (kind == Awaiting.CONFIRM) ListenStatus.CONFIRMANDO else ListenStatus.ATIVADA)
    }

    private fun clearWindow() {
        main.removeCallbacks(windowTimeout)
        awaiting = Awaiting.NONE
        pending = null
        AppState.partial = ""
    }

    private fun onWindowTimeout() {
        clearWindow()
        backToIdle()
    }

    private fun backToIdle() {
        if (awaiting != Awaiting.NONE) return
        if (listening && settings.economyMode && engine?.grammarMode == false && engine?.isRunning == true) {
            engine?.start(grammar = true)
        }
        restoreStatus()
    }

    private fun ensureFullRecognizer() {
        if (listening && engine?.grammarMode == true) engine?.start(grammar = false)
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        val s = speaker
        if (s == null) onDone?.invoke() else s.speak(text, onDone)
    }

    private fun speakThenIdle(text: String) = speak(text) { backToIdle() }

    // ---------------- Estado / tela ----------------
    private fun restoreStatus() {
        val s = when {
            awaiting == Awaiting.CONFIRM -> ListenStatus.CONFIRMANDO
            awaiting == Awaiting.COMMAND -> ListenStatus.ATIVADA
            listening && engine?.isRunning == true -> ListenStatus.OUVINDO
            AppState.status == ListenStatus.ERRO -> ListenStatus.ERRO
            listening -> ListenStatus.INICIANDO
            else -> ListenStatus.PARADA
        }
        setStatus(s)
    }

    private fun setStatus(s: ListenStatus) {
        AppState.status = s
        AppState.changed()
    }

    private fun record(heard: String, json: String, reply: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        AppState.addHistory(HistoryItem(time, heard, json, reply))
    }

    private fun aiLabel() = if (settings.apiKey.isBlank()) "Local (offline) · sem chave"
    else "Online configurada · ${settings.model}"

    /** Botão "Testar IA" das configurações. */
    fun testAi(onResult: (String) -> Unit) {
        if (!llm.isConfigured()) { onResult("Cole uma chave de API primeiro."); return }
        AppState.aiStatus = "Testando…"; AppState.changed()
        io.execute {
            val r = runCatching { llm.interpret("Diga só: teste concluído.", executor.contextSummary()) }
            main.post {
                r.onSuccess {
                    AppState.aiStatus = "Online · ${settings.model}"
                    onResult("IA respondeu: " + Json.write(it))
                }.onFailure {
                    AppState.aiStatus = "Erro: ${it.message?.take(70)}"
                    onResult("Falhou: ${it.message}")
                }
                AppState.changed()
            }
        }
    }
}
