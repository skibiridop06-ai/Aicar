package com.metralha.assistente.core

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * Mostra se o áudio do celular está saindo por Bluetooth (ex.: rádio do carro).
 * Usa o AudioManager, então não precisa de permissão extra de Bluetooth.
 * O PAREAMENTO em si é feito nas configurações do Android (botão no app abre a tela).
 */
object BluetoothMonitor {
    private var started = false

    fun start(ctx: Context) {
        if (started) return
        started = true
        val am = ctx.getSystemService(AudioManager::class.java)
        am.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refresh(am)
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refresh(am)
        }, Handler(Looper.getMainLooper()))
        refresh(am)
    }

    private fun refresh(am: AudioManager) {
        val bt = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { d ->
            d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        AppState.bluetoothConnected = bt != null
        AppState.bluetooth = if (bt != null) bt.productName.toString() else "Desconectado"
        AppState.changed()
    }
}
