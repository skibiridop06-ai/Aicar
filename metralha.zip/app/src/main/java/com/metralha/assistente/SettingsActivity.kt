package com.metralha.assistente

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.metralha.assistente.core.MetralhaCore
import com.metralha.assistente.service.ListeningService
import com.metralha.assistente.ui.Perms
import java.util.Locale

class SettingsActivity : Activity() {

    private val s get() = MetralhaCore.settings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        MetralhaCore.init(this)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        // Escuta
        switch(R.id.swBetter, s.betterRecognition) { s.betterRecognition = it; MetralhaCore.applySettings() }
        switch(R.id.swFollow, s.followUp) { s.followUp = it }
        switch(R.id.swEconomy, s.economyMode) { s.economyMode = it; MetralhaCore.applySettings() }
        switch(R.id.swScreen, s.keepScreenOn) { s.keepScreenOn = it }
        val btnListen = findViewById<Button>(R.id.btnListen)
        fun refreshListen() { btnListen.text = if (MetralhaCore.listening) "Pausar escuta" else "Ligar escuta" }
        refreshListen()
        btnListen.setOnClickListener {
            if (MetralhaCore.listening) startService(Intent(this, ListeningService::class.java).setAction(ListeningService.ACTION_STOP))
            else startForegroundService(Intent(this, ListeningService::class.java))
            btnListen.postDelayed({ refreshListen() }, 400)
        }

        // Tela apagada / Spotify
        findViewById<Button>(R.id.btnPermMedia).setOnClickListener { Perms.openMedia(this) }
        findViewById<Button>(R.id.btnPermOverlay).setOnClickListener { Perms.openOverlay(this) }
        findViewById<Button>(R.id.btnPermBattery).setOnClickListener { Perms.openBattery(this) }

        // Música
        val rg = findViewById<RadioGroup>(R.id.rgMusic)
        rg.check(when (s.musicApp) { "ytmusic" -> R.id.rbYt; "any" -> R.id.rbAny; else -> R.id.rbSpotify })
        rg.setOnCheckedChangeListener { _, id ->
            s.musicApp = when (id) { R.id.rbYt -> "ytmusic"; R.id.rbAny -> "any"; else -> "spotify" }
        }

        // Carro
        switch(R.id.swVirtual, s.virtualCar) { s.virtualCar = it; MetralhaCore.applySettings() }
        findViewById<Button>(R.id.btnBt).setOnClickListener { safeStart(Intent(AndroidSettings.ACTION_BLUETOOTH_SETTINGS)) }

        setupVoice()
        setupAnswers()
    }

    override fun onResume() {
        super.onResume()
        val ok = "✅"; val no = "⬜"
        findViewById<TextView>(R.id.permStatus).text =
            "${if (Perms.media(this)) ok else no} Controle do Spotify\n" +
                "${if (Perms.overlay(this)) ok else no} Abrir apps com a tela apagada\n" +
                "${if (Perms.battery(this)) ok else no} Bateria sem restrições"
    }

    private fun switch(id: Int, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
    }

    // ---------------- Voz ----------------
    private fun setupVoice() {
        val sp = findViewById<Spinner>(R.id.spVoice)
        val speaker = MetralhaCore.speaker
        val options = speaker?.voiceOptions().orEmpty()
        val labels = listOf("Automática (melhor disponível)") + options.map { it.label }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = options.indexOfFirst { it.name == s.voiceName }
        sp.setSelection(if (idx >= 0) idx + 1 else 0)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                s.voiceName = if (position == 0) "" else options[position - 1].name
                MetralhaCore.applyVoice()
                if (!first) MetralhaCore.testVoice()
                first = false
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val rateLabel = findViewById<TextView>(R.id.rateLabel)
        val pitchLabel = findViewById<TextView>(R.id.pitchLabel)
        seek(R.id.sbRate, s.speechRate, rateLabel, "Velocidade") { s.speechRate = it }
        seek(R.id.sbPitch, s.pitch, pitchLabel, "Tom") { s.pitch = it }

        findViewById<Button>(R.id.btnTestVoice).setOnClickListener { MetralhaCore.testVoice() }
        findViewById<Button>(R.id.btnMoreVoices).setOnClickListener {
            if (!safeStart(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)))
                safeStart(Intent("com.android.settings.TTS_SETTINGS"))
        }
    }

    /** SeekBar 0..100 representando 0.5x..1.5x */
    private fun seek(id: Int, value: Float, label: TextView, name: String, onChange: (Float) -> Unit) {
        val sb = findViewById<SeekBar>(id)
        fun show(v: Float) { label.text = "$name: ${String.format(Locale.ROOT, "%.2f", v).replace('.', ',')}x" }
        sb.progress = ((value - 0.5f) * 100).toInt().coerceIn(0, 100)
        show(value)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { show(0.5f + progress / 100f) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                onChange(0.5f + sb.progress / 100f)
                MetralhaCore.applyVoice()
                MetralhaCore.testVoice()
            }
        })
    }

    // ---------------- Respostas ensinadas ----------------
    private fun setupAnswers() {
        val q = findViewById<EditText>(R.id.inQ)
        val a = findViewById<EditText>(R.id.inA)
        findViewById<Button>(R.id.btnAddAnswer).setOnClickListener {
            val qq = q.text.toString().trim()
            val aa = a.text.toString().trim()
            if (qq.isEmpty() || aa.isEmpty()) {
                Toast.makeText(this, "Preencha os dois campos.", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            s.customAnswers = s.customAnswers.filter { it.first != qq } + (qq to aa.take(500))
            q.setText(""); a.setText("")
            Toast.makeText(this, "Aprendido!", Toast.LENGTH_SHORT).show()
            renderAnswers()
        }
        renderAnswers()
    }

    private fun renderAnswers() {
        val list = findViewById<LinearLayout>(R.id.answersList)
        list.removeAllViews()
        for ((qq, aa) in s.customAnswers) {
            list.addView(TextView(this).apply {
                text = "“$qq”\n→ $aa"
                setTextColor(getColor(R.color.text))
                textSize = 14f
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    AlertDialog.Builder(this@SettingsActivity)
                        .setMessage("Apagar esta resposta?")
                        .setPositiveButton("Apagar") { _, _ ->
                            s.customAnswers = s.customAnswers.filter { it.first != qq }
                            renderAnswers()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            })
        }
        if (s.customAnswers.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nenhuma resposta ensinada ainda."
                setTextColor(getColor(R.color.muted)); textSize = 13f
            })
        }
    }

    private fun safeStart(i: Intent): Boolean = try { startActivity(i); true } catch (e: Exception) { false }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
