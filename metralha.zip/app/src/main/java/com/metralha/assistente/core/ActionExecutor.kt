package com.metralha.assistente.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import com.metralha.assistente.brain.Action
import com.metralha.assistente.brain.Command
import com.metralha.assistente.media.MusicControl
import com.metralha.assistente.vehicle.RealCar
import com.metralha.assistente.vehicle.VehicleAdapter
import com.metralha.assistente.vehicle.VirtualCar

/**
 * Executa SOMENTE comandos já validados (tipo Command), com um "when" fechado.
 * Não existe caminho para executar texto ou código arbitrário.
 */
class ActionExecutor(private val ctx: Context, private val settings: Settings, private val timers: TimerManager) {
    private val virtual = VirtualCar()
    private val real = RealCar()
    val music = MusicControl(ctx, settings)

    val vehicle: VehicleAdapter get() = if (settings.virtualCar) virtual else real

    fun execute(c: Command): String {
        val v = vehicle
        return when (c.action) {
            Action.SET_CLIMATE_TEMPERATURE -> v.setClimateTemperature(c.temperature!!).message
            Action.ADJUST_CLIMATE_TEMPERATURE -> v.adjustClimateTemperature(c.delta!!).message
            Action.SET_CLIMATE_POWER -> v.setClimatePower(c.on!!).message
            Action.PLAY_MUSIC -> music.play(c.query!!).message
            Action.PAUSE_MUSIC -> music.pause().message
            Action.RESUME_MUSIC -> music.resume().message
            Action.NEXT_TRACK -> music.next().message
            Action.PREVIOUS_TRACK -> music.previous().message
            Action.VOLUME_UP -> music.volumeUp().message
            Action.VOLUME_DOWN -> music.volumeDown().message
            Action.SET_VOLUME -> music.setVolume(c.level!!).message
            Action.OPEN_MUSIC_APP -> music.openApp().message
            Action.OPEN_NAVIGATION -> openMaps(null)
            Action.START_ROUTE -> openMaps(c.destination!!)
            Action.GET_BATTERY -> batteryText()
            Action.SET_TIMER -> timers.set(c.seconds!!, c.label)
            Action.CANCEL_TIMER -> timers.cancel()
            Action.ANSWER -> c.text!!
            Action.UNSUPPORTED -> c.text ?: "Não posso fazer isso."
        }
    }

    private fun batteryText(): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "A bateria do celular está em $pct por cento" + if (charging) ", carregando." else "."
    }

    private fun openMaps(dest: String?): String {
        var intent = if (dest == null) Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
        else Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
        if (intent.resolveActivity(ctx.packageManager) == null && dest != null) {
            intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))
        }
        return when (Launcher.launch(ctx, intent, if (dest == null) "Abrir mapa" else "Rota para $dest")) {
            Launcher.Result.STARTED -> if (dest == null) "Abrindo a navegação." else "Iniciando rota para $dest."
            Launcher.Result.NOTIFIED -> "Toque na notificação para abrir a navegação."
            Launcher.Result.NO_APP -> "Não encontrei um app de mapas instalado."
        }
    }

    fun confirmQuestion(c: Command): String = when (c.action) {
        Action.START_ROUTE -> "Iniciar rota para ${c.destination}? Diga sim ou não."
        else -> "Confirma? Diga sim ou não."
    }
}
