package com.metralha.assistente.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.metralha.assistente.brain.Action
import com.metralha.assistente.brain.Command
import com.metralha.assistente.vehicle.PhoneVehicle
import com.metralha.assistente.vehicle.VehicleAdapter
import com.metralha.assistente.vehicle.VirtualCar

/**
 * Executa SOMENTE comandos já validados (tipo Command), com um "when" fechado.
 * Não existe caminho para executar texto/código vindo da IA.
 */
class ActionExecutor(private val ctx: Context, private val settings: Settings) {
    private val virtual = VirtualCar()
    val phone = PhoneVehicle(ctx)

    val vehicle: VehicleAdapter get() = if (settings.virtualCar) virtual else phone

    fun contextSummary(): String = vehicle.describe()

    fun execute(c: Command): String {
        val v = vehicle
        return when (c.action) {
            Action.SET_CLIMATE_TEMPERATURE -> v.setClimateTemperature(c.temperature!!).message
            Action.ADJUST_CLIMATE_TEMPERATURE -> v.adjustClimateTemperature(c.delta!!).message
            Action.SET_CLIMATE_POWER -> v.setClimatePower(c.on!!).message
            Action.PLAY_MUSIC -> v.playMusic(c.query!!).message
            Action.PAUSE_MUSIC -> v.pauseMusic().message
            Action.RESUME_MUSIC -> v.resumeMusic().message
            Action.NEXT_TRACK -> v.nextTrack().message
            Action.PREVIOUS_TRACK -> v.previousTrack().message
            Action.VOLUME_UP -> v.volumeUp().message
            Action.VOLUME_DOWN -> v.volumeDown().message
            Action.SET_VOLUME -> v.setVolume(c.level!!).message
            Action.OPEN_NAVIGATION -> openMaps(null)
            Action.START_ROUTE -> openMaps(c.destination!!)
            Action.ANSWER -> c.text!!
            Action.UNSUPPORTED -> c.text ?: "Não posso fazer isso."
        }
    }

    private fun openMaps(dest: String?): String {
        var intent = if (dest == null) Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
        else Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
        if (intent.resolveActivity(ctx.packageManager) == null && dest != null) {
            intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))
        }
        return when (Launcher.launch(ctx, intent, if (dest == null) "Abrir mapa" else "Rota para $dest")) {
            Launcher.Result.STARTED -> if (dest == null) "Abrindo a navegação." else "Iniciando rota para $dest."
            Launcher.Result.NOTIFIED -> "Toque na notificação para abrir a navegação."
            Launcher.Result.NO_APP -> "Não encontrei um app de mapas instalado."
        }
    }

    fun confirmQuestion(c: Command): String = when (c.action) {
        Action.START_ROUTE -> "Iniciar rota para ${c.destination}? Diga sim ou não."
        else -> "Confirma? Diga sim ou não."
    }
}
