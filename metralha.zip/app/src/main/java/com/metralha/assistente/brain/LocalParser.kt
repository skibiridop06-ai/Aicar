package com.metralha.assistente.brain

/**
 * "IA local" gratuita e offline: entende os comandos do carro por regras em português.
 * Devolve o MESMO formato JSON que a IA online devolveria; depois tudo passa pelo validador.
 * Retorna null quando não reconhece (aí, se configurado, a pergunta vai para a IA online).
 */
object LocalParser {

    private val DANGER = arrayOf(
        "acelera", "acelerar", "acelere", "acelerador", "freia", "frear", "freie", "freio", "freios",
        "freio de mao", "volante", "vira a direita", "vire a direita", "vira a esquerda", "vire a esquerda",
        "liga o motor", "ligar o motor", "desliga o motor", "desligar o motor", "piloto automatico",
        "destrava", "destravar", "abre a porta", "abrir a porta", "abre as portas", "abrir as portas",
        "abre o porta malas", "abrir o porta malas", "marcha", "cambio", "airbag", "controle de tracao",
        "dirige", "dirigir sozinho", "modo autonomo", "assume a direcao", "controla a direcao"
    )

    private val ROUTE = listOf(
        "me leva para", "me leva pra", "me leva ate", "me leva ao", "me leva a", "me leva na", "me leva no",
        "leva me para", "me leve para", "me leve ate", "navega para", "navega pra", "navega ate",
        "navegar para", "navegar ate", "navegue para", "navegue ate", "rota para", "rota pra", "rota ate",
        "traca rota para", "traca uma rota para", "inicia rota para", "iniciar rota para", "inicia a rota para",
        "ir para", "ir pra", "ir ate", "como chego em", "como chego no", "como chego na", "como chegar em",
        "como chegar no", "como chegar na", "vamos para", "vamos pra"
    )

    private val OPEN_NAV = arrayOf(
        "abre o mapa", "abrir o mapa", "abre mapa", "abre a navegacao", "abrir a navegacao", "abrir navegacao",
        "abre navegacao", "abre o gps", "abrir o gps", "abre o maps", "abre o waze", "abrir o waze", "abre o navegador"
    )

    private val PAUSE = arrayOf(
        "pausa", "pausar", "pause", "para a musica", "parar a musica", "pare a musica", "para de tocar",
        "parar de tocar", "para o som", "para essa musica", "silencia a musica"
    )
    private val RESUME = arrayOf(
        "continua", "continuar", "continue", "retoma", "retomar", "despausa", "despausar", "volta a tocar",
        "solta o som", "play", "volta o som"
    )
    private val NEXT = arrayOf(
        "proxima", "proximo", "pula", "pular", "pule", "avanca", "avancar", "passa a musica", "passa essa",
        "passa pra proxima", "muda a musica", "troca a musica", "outra musica"
    )
    private val PREVIOUS = arrayOf(
        "anterior", "volta a musica", "voltar a musica", "voltar musica", "volta musica", "musica de antes",
        "volta uma", "repete a musica", "toca de novo"
    )
    private val PLAY = listOf(
        "toca", "tocar", "toque", "toca ai", "bota pra tocar", "coloca pra tocar", "poe pra tocar",
        "quero ouvir", "coloca a musica", "coloca musica", "bota a musica", "bota musica", "poe a musica",
        "poe musica", "reproduz", "reproduzir", "toca a musica", "tocar a musica", "toca musica"
    )

    private val UP = arrayOf(
        "aumenta", "aumentar", "aumente", "sobe", "subir", "suba", "mais alto", "levanta"
    )
    private val DOWN = arrayOf(
        "diminui", "diminuir", "diminua", "abaixa", "abaixar", "abaixe", "baixa", "baixar", "reduz",
        "reduzir", "desce", "descer", "mais baixo"
    )

    fun parse(raw: String): Map<String, Any>? {
        val t = TextUtils.norm(raw)
        if (t.isBlank()) return null
        fun has(vararg k: String) = TextUtils.has(t, *k)
        val nums = TextUtils.numbers(t)

        // 1) Segurança: funções críticas do veículo NUNCA são executadas.
        if (has(*DANGER)) return mapOf(
            "action" to "unsupported",
            "reason" to "Por segurança, eu não controlo direção, aceleração, freios, motor, marchas ou portas."
        )

        // 2) Navegação
        TextUtils.after(t, ROUTE)?.let { dest ->
            val d = stripArticles(dest)
            if (d.isNotBlank()) return mapOf("action" to "start_route", "destination" to d)
        }
        if (has(*OPEN_NAV)) return mapOf("action" to "open_navigation")

        // 3) Música
        if (has(*PAUSE)) return mapOf("action" to "pause_music")
        if (has(*NEXT)) return mapOf("action" to "next_track")
        if (has(*PREVIOUS)) return mapOf("action" to "previous_track")
        if (has(*RESUME)) return mapOf("action" to "resume_music")
        TextUtils.after(t, PLAY)?.let { q ->
            val query = cleanQuery(q)
            return if (query.isBlank()) mapOf("action" to "resume_music")
            else mapOf("action" to "play_music", "query" to query)
        }

        // 4) Volume
        if (has("volume", "som")) {
            if (has("mudo", "muta", "silencio", "zera")) return mapOf("action" to "set_volume", "level" to 0)
            val n = nums.firstOrNull { it in 0..100 }
            val explicit = n != null && (has("em", "para", "pra", "no") || t.contains("%") || has("por cento"))
            if (explicit) return mapOf("action" to "set_volume", "level" to n!!)
            if (has(*UP)) return mapOf("action" to "volume_up")
            if (has(*DOWN)) return mapOf("action" to "volume_down")
            if (n != null) return mapOf("action" to "set_volume", "level" to n)
        }

        // 5) Clima / ar-condicionado
        if (has("to com frio", "estou com frio", "ta frio", "esta frio", "que frio", "ta gelado"))
            return mapOf("action" to "adjust_climate_temperature", "delta" to 1)
        if (has("to com calor", "estou com calor", "ta calor", "ta quente", "esta quente", "que calor", "esta calor"))
            return mapOf("action" to "adjust_climate_temperature", "delta" to -1)

        val climate = has(
            "ar", "ar condicionado", "temperatura", "clima", "climatizacao", "climatizador", "graus", "grau"
        )
        if (climate) {
            val n = nums.firstOrNull()
            if (has("desliga", "desligar", "desligue", "desativa", "desativar"))
                return mapOf("action" to "set_climate_power", "on" to false)
            if (n != null && n >= 10) return mapOf("action" to "set_climate_temperature", "temperature" to n)
            val up = has(*UP) || has("esquenta", "esquentar", "mais quente")
            val down = has(*DOWN) || has("esfria", "esfriar", "mais frio", "gela", "gelar")
            val step = if (n != null && n in 1..5) n else 1
            if (up) return mapOf("action" to "adjust_climate_temperature", "delta" to step)
            if (down) return mapOf("action" to "adjust_climate_temperature", "delta" to -step)
            if (has("liga", "ligar", "ligue", "ativa", "ativar"))
                return mapOf("action" to "set_climate_power", "on" to true)
            if (n != null) return mapOf("action" to "set_climate_temperature", "temperature" to n)
        }

        return null
    }

    // ---------- confirmação ----------
    fun isNo(norm: String) = TextUtils.has(norm, "nao", "cancela", "cancelar", "negativo", "esquece", "deixa pra la")
    fun isYes(norm: String) = TextUtils.has(
        norm, "sim", "confirma", "confirmo", "pode", "pode ir", "isso", "claro", "ok", "vai", "manda", "positivo", "beleza"
    )

    private val LEADING = setOf("a", "o", "as", "os", "um", "uma", "musica", "cancao", "som", "de", "do", "da", "ai", "pra", "mim")
    private val TRAILING = listOf("por favor", "pra mim", "pfv", "ai", "agora")

    private fun cleanQuery(q: String): String {
        var words = q.split(" ").filter { it.isNotEmpty() }
        while (words.isNotEmpty() && words.first() in LEADING) words = words.drop(1)
        var s = words.joinToString(" ")
        var changed = true
        while (changed) {
            changed = false
            for (tr in TRAILING) if (s.endsWith(" $tr")) { s = s.removeSuffix(" $tr"); changed = true }
        }
        return s.trim()
    }

    private fun stripArticles(d: String): String {
        var words = d.split(" ").filter { it.isNotEmpty() }
        while (words.isNotEmpty() && words.first() in setOf("a", "o", "as", "os")) words = words.drop(1)
        var s = words.joinToString(" ")
        for (tr in TRAILING) s = s.removeSuffix(" $tr")
        return s.trim()
    }
}
