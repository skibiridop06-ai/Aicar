package com.metralha.assistente.brain

/**
 * "IA local" gratuita e offline: entende os comandos do carro por regras em português.
 * Devolve o MESMO formato JSON que a IA online devolveria; depois tudo passa pelo validador.
 * Retorna null quando não reconhece (aí, se configurado, a pergunta vai para a IA online).
 */
object LocalParser {

    private val DANGER = arrayOf(
        "acelera", "acelerar", "acelere", "acelerador", "freia", "frear", "freie", "freio", "freios",
        "freio de mao", "volante", "vira a direita", "vire a direita", "vira a esquerda", "vire a esquerda",
        "liga o motor", "ligar o motor", "desliga o motor", "desligar o motor", "piloto automatico",
        "destrava", "destravar", "abre a porta", "abrir a porta", "abre as portas", "abrir as portas",
        "abre o porta malas", "abrir o porta malas", "marcha", "cambio", "airbag", "controle de tracao",
        "dirige", "dirigir sozinho", "modo autonomo", "assume a direcao", "controla a direcao"
    )

    private val ROUTE = listOf(
        "me leva para", "me leva pra", "me leva ate", "me leva ao", "me leva a", "me leva na", "me leva no",
        "leva me para", "me leve para", "me leve ate", "navega para", "navega pra", "navega ate",
        "navegar para", "navegar ate", "navegue para", "navegue ate", "rota para", "rota pra", "rota ate",
        "traca rota para", "traca uma rota para", "inicia rota para", "iniciar rota para", "inicia a rota para",
        "ir para", "ir pra", "ir ate", "como chego em", "como chego no", "como chego na", "como chegar em",
        "como chegar no", "como chegar na", "vamos para", "vamos pra",
        "para mim chegar na", "para mim chegar no", "para mim chegar em", "pra mim chegar na", "pra mim chegar no",
        "para eu chegar na", "para eu chegar no", "para eu chegar em", "pra eu chegar na", "pra eu chegar no",
        "como chego ao", "como chegar ao", "como faco para chegar na", "como faco para chegar no", "como faco pra chegar na",
        "como faco pra chegar no", "quero ir na", "quero ir no", "quero ir ao", "me leva pro", "me leva pra uma",
        "me leva para uma", "me leva para um", "me leva num", "me leva numa", "leva eu na", "leva eu no",
        "rota ate a", "navega ate a", "me guia ate", "me guia para", "me guia pra", "guia ate"
    )

    /** "procura/onde fica" só vira rota quando a pessoa pede algo perto ("posto mais próximo"). */
    private val NEARBY_TRIGGERS = listOf(
        "onde fica a", "onde fica o", "onde tem um", "onde tem uma", "procura um", "procura uma", "procure um",
        "procure uma", "encontra um", "encontra uma", "acha um", "acha uma", "quero um", "quero uma", "preciso de um",
        "preciso de uma", "tem algum", "tem alguma"
    )
    private val NEARBY = arrayOf("mais proxima", "mais proximo", "aqui perto", "perto daqui", "perto de mim", "mais perto", "proximo daqui", "proxima daqui")

    private val HOME = arrayOf(
        "tela inicial", "volta pra tela inicial", "volta para a tela inicial", "vai pra home", "vai para o inicio",
        "fecha o app", "sair do app", "minimiza", "volta pro inicio", "volta para o inicio"
    )
    private val ACT_TRIG = listOf(
        "pesquisa", "pesquise", "pesquisar", "procura", "procure", "procurar", "busca", "busque", "toca", "toque",
        "coloca", "bota", "poe", "abre", "abrir", "assistir", "quero ver", "quero assistir", "ver", "mostra", "passa", "assiste"
    )
    private val WEB_TRIG = arrayOf(
        "pesquisa no google", "pesquise no google", "procura no google", "busca no google", "joga no google",
        "pesquisa na internet", "procura na internet", "busca na internet", "pesquisa", "pesquise", "pesquisar", "google"
    )
    private val OPEN_TRIG = listOf(
        "abre o aplicativo", "abre o app", "abrir o aplicativo", "abre o", "abre a", "abrir o", "abrir a", "abre", "abrir",
        "inicia o", "iniciar o", "entra no", "entra na", "abra o", "abra a"
    )
    private val SEARCH_JUNK = setOf(
        "no", "na", "o", "a", "os", "as", "um", "uma", "e", "de", "do", "da", "youtube", "netflix", "google", "internet",
        "video", "videos", "filme", "serie", "app", "aplicativo", "pra", "mim", "por", "favor", "ai", "sobre", "chrome"
    )

    private fun cleanSearch(rest: String): String {
        var r = rest
        // "abre o youtube e procura X" -> "X"
        TextUtils.after(r, ACT_TRIG)?.let { if (it.isNotBlank()) r = it }
        val w = r.split(" ").filter { it.isNotEmpty() }.toMutableList()
        while (w.isNotEmpty() && w.first() in SEARCH_JUNK) w.removeAt(0)
        while (w.isNotEmpty() && w.last() in SEARCH_JUNK) w.removeAt(w.size - 1)
        // tira "no youtube"/"na netflix" do meio
        return w.joinToString(" ").replace(Regex(" (no|na) (youtube|netflix|google|internet)\\b"), "").trim()
    }

    /** "abre o site globo ponto com" -> "globo.com" */
    private fun siteUrl(t: String): String? {
        if (!TextUtils.has(t, "site", "ponto com", "com br", "ponto br")) return null
        val rest = TextUtils.after(t, listOf("abre o site", "abrir o site", "entra no site", "acessa o site", "vai no site", "site", "abre o", "entra no", "acessa"))
            ?: return null
        var tokens = rest.split(" ").filter { it.isNotEmpty() && it !in setOf("do", "da", "o", "a", "www") }
        if (tokens.isEmpty()) return null
        val joined = if (tokens.contains("ponto")) tokens.joinToString(" ").split(" ponto ").joinToString(".") { it.replace(" ", "") }
        else {
            val tlds = setOf("com", "br", "org", "net", "gov", "io", "app")
            val tail = tokens.takeLastWhile { it in tlds }
            if (tail.isEmpty()) return null
            tokens = tokens.dropLast(tail.size)
            (listOf(tokens.joinToString("")) + tail).joinToString(".")
        }
        return if (joined.contains(".") && !joined.startsWith(".")) joined else null
    }

    private val NAV_STATUS = arrayOf(
        "onde devo seguir", "onde eu sigo", "por onde eu sigo", "por onde sigo", "onde devo virar", "onde eu viro",
        "onde viro", "qual a proxima instrucao", "proxima instrucao", "proxima curva", "proxima manobra",
        "quanto falta", "quanto tempo falta", "falta muito", "que horas eu chego", "que horas chego",
        "estou no caminho certo", "to no caminho certo", "qual o caminho", "pra onde eu vou", "para onde eu vou",
        "repete a instrucao", "repete a rota", "e agora metralha", "onde eu vou agora", "qual a rota", "pra onde vou",
        "devo virar", "viro onde", "sigo reto"
    )

    private val OPEN_NAV = arrayOf(
        "abre o mapa", "abrir o mapa", "abre mapa", "abre a navegacao", "abrir a navegacao", "abrir navegacao",
        "abre navegacao", "abre o gps", "abrir o gps", "abre o maps", "abre o google maps"
    )

    private val PAUSE = arrayOf(
        "pausa", "pausar", "pause", "para a musica", "parar a musica", "pare a musica", "para de tocar",
        "parar de tocar", "para o som", "para essa musica", "silencia a musica"
    )
    private val RESUME = arrayOf(
        "continua", "continuar", "continue", "retoma", "retomar", "despausa", "despausar", "volta a tocar",
        "solta o som", "play", "volta o som"
    )
    private val NEXT = arrayOf(
        "proxima musica", "proxima faixa", "pula a musica", "pula essa", "pular a musica", "pula musica",
        "avanca a musica", "passa a musica", "passa essa", "passa pra proxima", "muda a musica",
        "troca a musica", "outra musica", "toca a proxima", "toca a proxima musica"
    )
    private val NEXT_SHORT = arrayOf("proxima", "proximo", "pula", "pular", "pule", "avanca", "avancar")
    private val PREVIOUS = arrayOf(
        "musica anterior", "faixa anterior", "volta a musica", "voltar a musica", "voltar musica", "volta musica", "musica de antes",
        "volta uma", "repete a musica", "toca de novo"
    )
    private val PLAY = listOf(
        "toca", "tocar", "toque", "toca ai", "bota pra tocar", "coloca pra tocar", "poe pra tocar",
        "quero ouvir", "coloca a musica", "coloca musica", "bota a musica", "bota musica", "poe a musica",
        "poe musica", "reproduz", "reproduzir", "toca a musica", "tocar a musica", "toca musica"
    )

    private val UP = arrayOf(
        "aumenta", "aumentar", "aumente", "sobe", "subir", "suba", "mais alto", "levanta"
    )
    private val DOWN = arrayOf(
        "diminui", "diminuir", "diminua", "abaixa", "abaixar", "abaixe", "baixa", "baixar", "reduz",
        "reduzir", "desce", "descer", "mais baixo"
    )

    fun parse(raw: String): Map<String, Any>? {
        val t = TextUtils.norm(raw)
        if (t.isBlank()) return null
        fun has(vararg k: String) = TextUtils.has(t, *k)
        val nums = TextUtils.numbers(t)

        // 1) Segurança: funções críticas do veículo NUNCA são executadas.
        if (has(*DANGER)) return mapOf(
            "action" to "unsupported",
            "reason" to "Por segurança, eu não controlo direção, aceleração, freios, motor, marchas ou portas."
        )

        // 2) Navegação
        TextUtils.after(t, ROUTE)?.let { dest ->
            val d = cleanDestination(dest)
            if (d.isNotBlank()) return mapOf("action" to "start_route", "destination" to TextUtils.restore(raw, d))
        }
        if (has(*NEARBY)) {
            TextUtils.after(t, NEARBY_TRIGGERS)?.let { dest ->
                val d = cleanDestination(dest)
                if (d.isNotBlank()) return mapOf("action" to "start_route", "destination" to TextUtils.restore(raw, d))
            }
        }
        if (has(*NAV_STATUS)) return mapOf("action" to "get_navigation")

        // 3) Apps, vídeo e internet (celular ou multimídia Android do carro)
        if (has(*HOME)) return mapOf("action" to "go_home")
        for (svc in listOf("youtube", "netflix")) {
            if (has(svc)) {
                val rest = TextUtils.after(t, ACT_TRIG) ?: ""
                val q = cleanSearch(rest)
                return if (q.isBlank()) mapOf("action" to "media_search", "service" to svc)
                else mapOf("action" to "media_search", "service" to svc, "query" to TextUtils.restore(raw, q))
            }
        }
        siteUrl(t)?.let { return mapOf("action" to "open_website", "url" to it) }
        if (has(*WEB_TRIG)) {
            val q = cleanSearch(TextUtils.after(t, WEB_TRIG.toList()) ?: "")
            if (q.isNotBlank()) return mapOf("action" to "media_search", "service" to "google", "query" to TextUtils.restore(raw, q))
        }
        if (has(*OPEN_NAV)) return mapOf("action" to "open_navigation")
        if (has("abre o spotify", "abrir o spotify", "abre spotify", "abre a musica", "abre o app de musica", "abre o youtube music"))
            return mapOf("action" to "open_music_app")

        // 3) Música
        if (has(*PAUSE)) return mapOf("action" to "pause_music")
        val short = t.split(" ").size <= 2
        if (has(*NEXT) || (short && has(*NEXT_SHORT))) return mapOf("action" to "next_track")
        if (has(*PREVIOUS) || (short && has("anterior", "volta"))) return mapOf("action" to "previous_track")
        if (has(*RESUME)) return mapOf("action" to "resume_music")
        TextUtils.after(t, PLAY)?.let { q ->
            val query = cleanQuery(q)
            return if (query.isBlank()) mapOf("action" to "resume_music")
            else mapOf("action" to "play_music", "query" to query)
        }

        // Abrir qualquer aplicativo pelo nome
        TextUtils.after(t, OPEN_TRIG)?.let { rest ->
            var name = " $rest "
            for (cut in listOf(" e ", " por favor ", " pra mim ", " ai ")) { val i = name.indexOf(cut); if (i >= 0) name = name.substring(0, i) + " " }
            val words = name.trim().split(" ").filter { it.isNotEmpty() && it !in setOf("o", "a", "app", "aplicativo", "do", "da") }
            if (words.isNotEmpty()) return mapOf("action" to "open_app", "app" to TextUtils.restore(raw, words.joinToString(" ")))
        }

        // 4) Volume
        if (has("volume", "som")) {
            if (has("mudo", "muta", "silencio", "zera")) return mapOf("action" to "set_volume", "level" to 0)
            val n = nums.firstOrNull { it in 0..100 }
            val explicit = n != null && (has("em", "para", "pra", "no") || t.contains("%") || has("por cento"))
            if (explicit) return mapOf("action" to "set_volume", "level" to n!!)
            if (has(*UP)) return mapOf("action" to "volume_up")
            if (has(*DOWN)) return mapOf("action" to "volume_down")
            if (n != null) return mapOf("action" to "set_volume", "level" to n)
        }

        // 5) Clima / ar-condicionado
        if (has("to com frio", "estou com frio", "ta frio", "esta frio", "que frio", "ta gelado"))
            return mapOf("action" to "adjust_climate_temperature", "delta" to 1)
        if (has("to com calor", "estou com calor", "ta calor", "ta quente", "esta quente", "que calor", "esta calor"))
            return mapOf("action" to "adjust_climate_temperature", "delta" to -1)

        val climate = has(
            "ar", "ar condicionado", "temperatura", "clima", "climatizacao", "climatizador", "graus", "grau"
        )
        if (climate) {
            val n = nums.firstOrNull()
            if (has("desliga", "desligar", "desligue", "desativa", "desativar"))
                return mapOf("action" to "set_climate_power", "on" to false)
            if (n != null && n >= 10) return mapOf("action" to "set_climate_temperature", "temperature" to n)
            val up = has(*UP) || has("esquenta", "esquentar", "mais quente")
            val down = has(*DOWN) || has("esfria", "esfriar", "mais frio", "gela", "gelar")
            val step = if (n != null && n in 1..5) n else 1
            if (up) return mapOf("action" to "adjust_climate_temperature", "delta" to step)
            if (down) return mapOf("action" to "adjust_climate_temperature", "delta" to -step)
            if (has("liga", "ligar", "ligue", "ativa", "ativar"))
                return mapOf("action" to "set_climate_power", "on" to true)
            if (n != null) return mapOf("action" to "set_climate_temperature", "temperature" to n)
        }

        return null
    }

    // ---------- confirmação ----------
    fun isNo(norm: String) = TextUtils.has(norm, "nao", "cancela", "cancelar", "negativo", "esquece", "deixa pra la")
    fun isYes(norm: String) = TextUtils.has(
        norm, "sim", "confirma", "confirmo", "pode", "pode ir", "isso", "claro", "ok", "vai", "manda", "positivo", "beleza"
    )

    private val LEADING = setOf("a", "o", "as", "os", "um", "uma", "musica", "cancao", "som", "de", "do", "da", "ai", "pra", "mim")
    private val TRAILING = listOf(
        "por favor", "pra mim", "pfv", "ai", "agora", "no spotify", "do spotify", "la no spotify",
        "no youtube", "no youtube music", "no deezer"
    )

    private fun cleanQuery(q: String): String {
        var words = q.split(" ").filter { it.isNotEmpty() }
        while (words.isNotEmpty() && words.first() in LEADING) words = words.drop(1)
        var s = words.joinToString(" ")
        var changed = true
        while (changed) {
            changed = false
            for (tr in TRAILING) if (s.endsWith(" $tr")) { s = s.removeSuffix(" $tr"); changed = true }
        }
        return s.trim()
    }

    /** "a padaria mais proxima onde devo seguir por favor" -> "padaria mais proxima" */
    private fun cleanDestination(d: String): String {
        var s = " $d "
        for (cut in listOf(" onde ", " por onde ", " como ", " qual ", " e me ", " pra eu ", " para eu ", " me fala ", " me diz ")) {
            val i = s.indexOf(cut)
            if (i > 0) s = s.substring(0, i) + " "
        }
        return stripArticles(s.trim())
    }

    private fun stripArticles(d: String): String {
        var words = d.split(" ").filter { it.isNotEmpty() }
        while (words.isNotEmpty() && words.first() in setOf("a", "o", "as", "os", "um", "uma")) words = words.drop(1)
        var s = words.joinToString(" ")
        for (tr in TRAILING) s = s.removeSuffix(" $tr")
        return s.trim()
    }
}
