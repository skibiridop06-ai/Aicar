package com.metralha.assistente.brain

import com.metralha.assistente.core.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * IA online OPCIONAL, via qualquer API compatível com o formato "OpenAI chat completions"
 * (Google Gemini tem camada gratuita; também funciona com Groq, OpenRouter etc.).
 *
 * Só recebe o TEXTO do comando dito depois de "Metralha" — nunca áudio, nunca a conversa toda.
 * A resposta é lida apenas como dados JSON e passa pelo CommandValidator.
 */
class LlmClient(private val settings: Settings) {

    fun isConfigured(): Boolean = settings.apiKey.isNotBlank()

    /** Chamada bloqueante: rode fora da thread principal. */
    fun interpret(userText: String, carState: String): Map<String, Any?> {
        val url = URL(settings.baseUrl.trim().trimEnd('/') + "/chat/completions")
        val body = JSONObject()
            .put("model", settings.model.trim())
            .put("temperature", 0.2)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT + "\n\nEstado atual do carro: " + carState))
                    .put(JSONObject().put("role", "user").put("content", userText.take(500)))
            )

        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Authorization", "Bearer " + settings.apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code ${text.take(160)}")

            val content = JSONObject(text)
                .getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            val obj = extractJson(content)
                ?: return mapOf("action" to "answer", "text" to content.trim().take(600))
            return toMap(obj)
        } finally {
            conn.disconnect()
        }
    }

    private fun extractJson(s: String): JSONObject? {
        val start = s.indexOf('{')
        val end = s.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try { JSONObject(s.substring(start, end + 1)) } catch (e: Exception) { null }
    }

    private fun toMap(o: JSONObject): Map<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val v = o.opt(k)
            // Só valores simples. Objetos/listas aninhados são descartados.
            m[k] = when (v) {
                JSONObject.NULL, is JSONObject, is JSONArray -> null
                else -> v
            }
        }
        return m
    }

    companion object {
        val SYSTEM_PROMPT = """
Você é o Metralha, assistente de voz de um carro, falando português do Brasil.
Converta o pedido do motorista em UM ÚNICO objeto JSON, sem markdown, sem texto fora do JSON, sem código.

Ações permitidas (use exatamente estes nomes):
{"action":"set_climate_temperature","temperature":19}        (16 a 30)
{"action":"adjust_climate_temperature","delta":1}            (-5 a 5, positivo = mais quente)
{"action":"set_climate_power","on":true}
{"action":"play_music","query":"nome da música ou artista"}
{"action":"pause_music"} {"action":"resume_music"} {"action":"next_track"} {"action":"previous_track"}
{"action":"volume_up"} {"action":"volume_down"} {"action":"set_volume","level":40}   (0 a 100)
{"action":"open_navigation"}
{"action":"start_route","destination":"endereço ou lugar"}
{"action":"answer","text":"resposta curta"}
{"action":"unsupported","reason":"explicação curta"}

Regras:
- Perguntas gerais: use "answer" com no máximo 2 frases curtas, sem listas, próprias para serem faladas a quem está dirigindo.
- NUNCA controle direção, volante, acelerador, freio, marcha, motor, portas, travas ou airbags: responda "unsupported".
- Não invente ações nem campos. Se não houver ação adequada, use "answer" ou "unsupported".
""".trimIndent()
    }
}
