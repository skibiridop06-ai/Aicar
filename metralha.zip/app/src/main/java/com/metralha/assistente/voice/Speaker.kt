package com.metralha.assistente.voice

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Voz do Metralha: vozes neurais do próprio Android (Google), grátis.
 * Escolhe automaticamente a voz pt-BR de maior qualidade instalada; dá para trocar nas configurações.
 */
class Speaker(ctx: Context, private val onSpeaking: (Boolean) -> Unit) : TextToSpeech.OnInitListener {

    data class VoiceOption(val name: String, val label: String)

    private val main = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(ctx.applicationContext, this)
    private var ready = false
    private var failed = false
    private val pending = mutableListOf<Pair<String, (() -> Unit)?>>()
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()

    private var wantedVoice = ""
    private var rate = 1.0f
    private var pitch = 1.0f
    var isSpeaking = false
        private set

    override fun onInit(status: Int) {
        main.post {
            if (status == TextToSpeech.SUCCESS) {
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { isSpeaking = true; onSpeaking(true) } }
                    override fun onDone(utteranceId: String?) { finish(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish(utteranceId) }
                    override fun onError(utteranceId: String?, errorCode: Int) { finish(utteranceId) }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(utteranceId) }
                })
                ready = true
                applyVoice()
            } else {
                failed = true
            }
            val list = pending.toList()
            pending.clear()
            list.forEach { speak(it.first, it.second) }
        }
    }

    fun configure(voiceName: String, rate: Float, pitch: Float) {
        wantedVoice = voiceName
        this.rate = rate
        this.pitch = pitch
        if (ready) applyVoice()
    }

    private fun ptVoices(): List<Voice> = try {
        tts.voices.orEmpty().filter { v ->
            v.locale.language == "pt" && (v.locale.country.isEmpty() || v.locale.country == "BR") &&
                !v.features.orEmpty().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
    } catch (e: Exception) { emptyList() }

    private fun applyVoice() {
        val voices = ptVoices()
        val chosen = voices.firstOrNull { it.name == wantedVoice }
            ?: voices.sortedWith(
                compareByDescending<Voice> { it.quality }
                    .thenBy { if (it.isNetworkConnectionRequired) 1 else 0 }
            ).firstOrNull()
        if (chosen != null) tts.voice = chosen else tts.language = Locale("pt", "BR")
        tts.setSpeechRate(rate)
        tts.setPitch(pitch)
    }

    fun voiceOptions(): List<VoiceOption> {
        val list = ptVoices().sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
        return list.mapIndexed { i, v ->
            val q = when {
                v.quality >= Voice.QUALITY_VERY_HIGH -> "qualidade máxima"
                v.quality >= Voice.QUALITY_HIGH -> "alta qualidade"
                else -> "normal"
            }
            val net = if (v.isNetworkConnectionRequired) "online" else "offline"
            VoiceOption(v.name, "Voz ${i + 1} · $q · $net")
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (failed) { onDone?.invoke(); return }
        if (!ready) { pending.add(text to onDone); return }
        val id = UUID.randomUUID().toString()
        callbacks[id] = onDone ?: {}
        val r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id)
        if (r != TextToSpeech.SUCCESS) finish(id)
    }

    fun stop() {
        try { tts.stop() } catch (_: Exception) {}
    }

    private fun finish(id: String?) {
        main.post {
            isSpeaking = false
            onSpeaking(false)
            id?.let { callbacks.remove(it)?.invoke() }
        }
    }

    fun shutdown() {
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
    }
}
