package com.metralha.assistente.voice

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Voz do Metralha: síntese de voz do próprio Android (grátis, funciona offline com voz pt-BR instalada). */
class Speaker(ctx: Context, private val onSpeaking: (Boolean) -> Unit) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(ctx.applicationContext, this)
    private var ready = false
    private var failed = false
    private val pending = mutableListOf<Pair<String, (() -> Unit)?>>()
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()

    override fun onInit(status: Int) {
        main.post {
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("pt", "BR")
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { onSpeaking(true) } }
                    override fun onDone(utteranceId: String?) { finish(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish(utteranceId) }
                    override fun onError(utteranceId: String?, errorCode: Int) { finish(utteranceId) }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { finish(utteranceId) }
                })
                ready = true
            } else {
                failed = true
            }
            val list = pending.toList()
            pending.clear()
            list.forEach { speak(it.first, it.second) }
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (failed) { onDone?.invoke(); return }
        if (!ready) { pending.add(text to onDone); return }
        val id = UUID.randomUUID().toString()
        callbacks[id] = onDone ?: {}
        val r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id)
        if (r != TextToSpeech.SUCCESS) finish(id)
    }

    private fun finish(id: String?) {
        main.post {
            onSpeaking(false)
            id?.let { callbacks.remove(it)?.invoke() }
        }
    }

    fun shutdown() {
        try { tts.stop(); tts.shutdown() } catch (_: Exception) {}
    }
}
