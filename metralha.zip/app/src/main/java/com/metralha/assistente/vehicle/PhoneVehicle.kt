package com.metralha.assistente.vehicle

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.view.KeyEvent
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.Launcher

/**
 * Carro real via CELULAR + BLUETOOTH comum.
 *
 * O que funciona de verdade: música e volume. O som sai pelo Bluetooth (A2DP) no rádio do
 * carro, e os comandos de mídia vão para o app que estiver tocando (Spotify, YouTube Music...).
 *
 * O que NÃO funciona: ar-condicionado. Bluetooth de áudio não tem nenhum canal para isso.
 * Por isso as funções de clima respondem honestamente "indisponível".
 */
class PhoneVehicle(private val ctx: Context) : VehicleAdapter {
    override val displayName = "Celular + Bluetooth"

    private val audio = ctx.getSystemService(AudioManager::class.java)

    private val noClimate = ActionResult(
        false,
        "Função de ar-condicionado ainda não disponível: este carro não oferece uma interface compatível com o app. " +
            "Use o Carro Virtual para testar."
    )

    override fun setClimateTemperature(celsius: Int) = noClimate
    override fun adjustClimateTemperature(delta: Int) = noClimate
    override fun setClimatePower(on: Boolean) = noClimate

    override fun playMusic(query: String): ActionResult {
        val search = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        val r = Launcher.launch(ctx, search, "Tocar $query")
        if (r != Launcher.Result.NO_APP) {
            AppState.musicTitle = query
            AppState.musicPlaying = true
            AppState.changed()
            return ActionResult(true, if (r == Launcher.Result.STARTED) "Procurando $query." else "Toque na notificação para tocar $query.")
        }
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(query)))
        val r2 = Launcher.launch(ctx, web, "Tocar $query")
        return when (r2) {
            Launcher.Result.STARTED -> ActionResult(true, "Abrindo a busca por $query.")
            Launcher.Result.NOTIFIED -> ActionResult(true, "Toque na notificação para tocar $query.")
            Launcher.Result.NO_APP -> ActionResult(false, "Não encontrei um app de música no celular.")
        }
    }

    override fun pauseMusic(): ActionResult {
        mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
        AppState.musicPlaying = false; AppState.changed()
        return ActionResult(true, "Pausado.")
    }

    override fun resumeMusic(): ActionResult {
        mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        AppState.musicPlaying = true; AppState.changed()
        return ActionResult(true, "Continuando.")
    }

    override fun nextTrack(): ActionResult {
        mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        return ActionResult(true, "Próxima.")
    }

    override fun previousTrack(): ActionResult {
        mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        return ActionResult(true, "Anterior.")
    }

    override fun volumeUp(): ActionResult {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
        return ActionResult(true, "Volume em ${refreshVolume()} por cento.")
    }

    override fun volumeDown(): ActionResult {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
        return ActionResult(true, "Volume em ${refreshVolume()} por cento.")
    }

    override fun setVolume(level: Int): ActionResult {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val idx = Math.round(level / 100f * max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, AudioManager.FLAG_SHOW_UI)
        return ActionResult(true, "Volume em ${refreshVolume()} por cento.")
    }

    fun refreshVolume(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        AppState.volume = Math.round(cur * 100f / max)
        AppState.changed()
        return AppState.volume
    }

    override fun describe(): String =
        "celular conectado ao carro por Bluetooth; ar-condicionado NÃO disponível; volume ${AppState.volume}%"

    private fun mediaKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
