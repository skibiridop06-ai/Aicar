package com.metralha.assistente.media

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.KeyEvent
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.Launcher
import com.metralha.assistente.core.Settings
import com.metralha.assistente.vehicle.ActionResult

/**
 * Música e volume REAIS do celular. Usa o SEU Spotify (ou o app escolhido nas configurações).
 * O som vai para o carro pelo Bluetooth, como qualquer música do celular.
 */
class MusicControl(private val ctx: Context, private val settings: Settings) {

    private val audio = ctx.getSystemService(AudioManager::class.java)

    private fun preferredPackage(): String? = when (settings.musicApp) {
        "spotify" -> Settings.SPOTIFY
        "ytmusic" -> Settings.YT_MUSIC
        else -> null
    }?.takeIf { isInstalled(it) }

    fun isInstalled(pkg: String) = ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    private fun appLabel(pkg: String?) = when (pkg) {
        Settings.SPOTIFY -> "no Spotify"
        Settings.YT_MUSIC -> "no YouTube Music"
        else -> ""
    }

    fun play(query: String): ActionResult {
        val pkg = preferredPackage()
        val where = appLabel(pkg)

        // 1) Com o Metralha na tela (ou com permissão de abrir apps): pede ao Spotify para buscar e tocar.
        val search = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        if (pkg != null) search.setPackage(pkg)

        if (Launcher.canStartDirectly(ctx)) {
            if (Launcher.launch(ctx, search, "Tocar $query") == Launcher.Result.STARTED) {
                optimistic(query, pkg)
                return ActionResult(true, "Tocando $query $where.".replace("  ", " "))
            }
        }

        // 2) Tela apagada / app em segundo plano: manda direto para a sessão do Spotify, sem abrir tela.
        val c = NowPlaying.controller(pkg)
        if (c != null) {
            c.transportControls.playFromSearch(query, Bundle())
            optimistic(query, pkg)
            return ActionResult(true, "Tocando $query $where.".replace("  ", " "))
        }

        // 3) Último recurso: notificação para tocar.
        return when (Launcher.launch(ctx, search, "Tocar $query")) {
            Launcher.Result.STARTED -> { optimistic(query, pkg); ActionResult(true, "Tocando $query $where.".replace("  ", " ")) }
            Launcher.Result.NOTIFIED -> ActionResult(true, "Toque na notificação para tocar $query.")
            Launcher.Result.NO_APP -> {
                val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(query)))
                if (Launcher.launch(ctx, web, "Tocar $query") != Launcher.Result.NO_APP) ActionResult(true, "Abrindo a busca por $query.")
                else ActionResult(false, "Não encontrei um app de música. Instale o Spotify.")
            }
        }
    }

    private fun optimistic(query: String, pkg: String?) {
        AppState.musicTitle = query.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        AppState.musicArtist = ""
        AppState.musicApp = if (pkg == Settings.SPOTIFY) "Spotify" else AppState.musicApp
        AppState.musicPlaying = true
        AppState.changed()
    }

    fun openApp(): ActionResult {
        val pkg = preferredPackage() ?: Settings.SPOTIFY
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "O Spotify não está instalado.")
        return when (Launcher.launch(ctx, i, "Abrir música")) {
            Launcher.Result.STARTED -> ActionResult(true, "Abrindo a música.")
            Launcher.Result.NOTIFIED -> ActionResult(true, "Toque na notificação para abrir.")
            Launcher.Result.NO_APP -> ActionResult(false, "Não consegui abrir o app de música.")
        }
    }

    fun pause(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.pause() else key(KeyEvent.KEYCODE_MEDIA_PAUSE)
        AppState.musicPlaying = false; AppState.changed()
        return ActionResult(true, "Pausado.")
    }

    fun resume(): ActionResult {
        val c = NowPlaying.controller(preferredPackage()) ?: NowPlaying.controller(null)
        if (c != null) c.transportControls.play() else key(KeyEvent.KEYCODE_MEDIA_PLAY)
        AppState.musicPlaying = true; AppState.changed()
        return ActionResult(true, "Tocando.")
    }

    fun next(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.skipToNext() else key(KeyEvent.KEYCODE_MEDIA_NEXT)
        return ActionResult(true, "Próxima.")
    }

    fun previous(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.skipToPrevious() else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        return ActionResult(true, "Voltando.")
    }

    fun toggle() = if (AppState.musicPlaying) pause() else resume()

    fun volumeUp(): ActionResult = setVolume((AppState.volume + 10).coerceAtMost(100))
    fun volumeDown(): ActionResult = setVolume((AppState.volume - 10).coerceAtLeast(0))

    fun setVolume(level: Int): ActionResult {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val idx = Math.round(level / 100f * max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
        return ActionResult(true, "Volume em ${refreshVolume()} por cento.")
    }

    fun refreshVolume(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        AppState.volume = Math.round(audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max)
        AppState.changed()
        return AppState.volume
    }

    private fun key(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
