package com.metralha.assistente.media

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.MediaStore
import android.view.KeyEvent
import com.metralha.assistente.core.AppState
import com.metralha.assistente.core.Launcher
import com.metralha.assistente.core.Settings
import com.metralha.assistente.vehicle.ActionResult

/**
 * Música e volume REAIS do celular. Usa o SEU Spotify (ou o app escolhido nas configurações).
 * O som vai para o carro pelo Bluetooth, como qualquer música do celular.
 */
class MusicControl(private val ctx: Context, private val settings: Settings) {

    private val audio = ctx.getSystemService(AudioManager::class.java)

    private fun preferredPackage(): String? = when (settings.musicApp) {
        "spotify" -> Settings.SPOTIFY
        "ytmusic" -> Settings.YT_MUSIC
        else -> null
    }?.takeIf { isInstalled(it) }

    fun isInstalled(pkg: String) = ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    private fun appLabel(pkg: String?) = when (pkg) {
        Settings.SPOTIFY -> "no Spotify"
        Settings.YT_MUSIC -> "no YouTube Music"
        else -> ""
    }

    private val main = Handler(Looper.getMainLooper())
    private var playToken = 0

    /**
     * Toca a música DIRETO, sem você precisar apertar play:
     *  1) Se o Spotify já está aberto (mesmo em segundo plano), manda a busca direto para o
     *     player dele (playFromSearch) — nada abre na tela, funciona com a tela apagada.
     *  2) Se o Spotify está fechado, acorda o Spotify, espera ele ficar pronto e então manda tocar.
     *     Depois volta para a tela do Metralha, se ela estava aberta.
     * Requer a permissão "Controlar o Spotify" (Acesso a notificações).
     */
    fun play(query: String): ActionResult {
        val pkg = preferredPackage()
        val where = appLabel(pkg)
        val ok = ActionResult(true, "Tocando $query $where.".replace("  ", " ").replace(" .", "."))
        val canControl = NowPlaying.isAllowed(ctx)
        if (canControl) NowPlaying.start(ctx)

        // 1) Player já ativo: toca direto.
        val c = if (canControl) NowPlaying.controller(pkg) else null
        if (c != null) {
            playOn(c, query)
            optimistic(query, pkg)
            return ok
        }

        // 2) Player fechado: abre o app pedindo a busca e, assim que a sessão dele aparecer, manda tocar.
        val search = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        if (pkg != null) search.setPackage(pkg)
        val wasVisible = AppState.activityVisible

        when (Launcher.launch(ctx, search, "Tocar $query")) {
            Launcher.Result.STARTED -> {
                if (canControl) waitForSessionThenPlay(pkg, query, wasVisible)
                optimistic(query, pkg)
                return if (canControl) ok
                else ActionResult(true, "Abri o Spotify. Para tocar direto, ative Controlar o Spotify nos ajustes do Metralha.")
            }
            Launcher.Result.NOTIFIED -> return ActionResult(true, "Toque na notificação para tocar $query.")
            Launcher.Result.NO_APP -> {
                val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(query)))
                return if (Launcher.launch(ctx, web, "Tocar $query") != Launcher.Result.NO_APP) ActionResult(true, "Abrindo a busca por $query.")
                else ActionResult(false, "Não encontrei um app de música. Instale o Spotify.")
            }
        }
    }

    private fun playOn(c: MediaController, query: String) {
        val token = ++playToken
        c.transportControls.playFromSearch(query, Bundle())
        // Garantia: se em 3 s ainda não estiver tocando, dá o play.
        main.postDelayed({
            if (token == playToken && c.playbackState?.state != PlaybackState.STATE_PLAYING) c.transportControls.play()
        }, 3000)
    }

    private fun waitForSessionThenPlay(pkg: String?, query: String, returnToMetralha: Boolean) {
        val token = ++playToken
        var tries = 0
        val tick = object : Runnable {
            override fun run() {
                if (token != playToken) return
                NowPlaying.start(ctx)
                val c = NowPlaying.controller(pkg)
                if (c != null) {
                    // pequena espera para o app terminar de carregar
                    main.postDelayed({
                        playOn(c, query)
                        if (returnToMetralha) main.postDelayed({ bringMetralhaBack() }, 1500)
                    }, 900)
                } else if (++tries < 20) {
                    main.postDelayed(this, 500)
                }
            }
        }
        main.postDelayed(tick, 800)
    }

    private fun bringMetralhaBack() {
        val i = Intent(ctx, com.metralha.assistente.MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        if (Launcher.hasOverlayPermission(ctx)) Launcher.launch(ctx, i, "Voltar ao Metralha")
    }

    private fun optimistic(query: String, pkg: String?) {
        AppState.musicTitle = query.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        AppState.musicArtist = ""
        AppState.musicApp = if (pkg == Settings.SPOTIFY) "Spotify" else AppState.musicApp
        AppState.musicPlaying = true
        AppState.changed()
    }

    fun openApp(): ActionResult {
        val pkg = preferredPackage() ?: Settings.SPOTIFY
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "O Spotify não está instalado.")
        return when (Launcher.launch(ctx, i, "Abrir música")) {
            Launcher.Result.STARTED -> ActionResult(true, "Abrindo a música.")
            Launcher.Result.NOTIFIED -> ActionResult(true, "Toque na notificação para abrir.")
            Launcher.Result.NO_APP -> ActionResult(false, "Não consegui abrir o app de música.")
        }
    }

    fun pause(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.pause() else key(KeyEvent.KEYCODE_MEDIA_PAUSE)
        AppState.musicPlaying = false; AppState.changed()
        return ActionResult(true, "Pausado.")
    }

    fun resume(): ActionResult {
        val c = NowPlaying.controller(preferredPackage()) ?: NowPlaying.controller(null)
        if (c != null) c.transportControls.play() else key(KeyEvent.KEYCODE_MEDIA_PLAY)
        AppState.musicPlaying = true; AppState.changed()
        return ActionResult(true, "Tocando.")
    }

    fun next(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.skipToNext() else key(KeyEvent.KEYCODE_MEDIA_NEXT)
        return ActionResult(true, "Próxima.")
    }

    fun previous(): ActionResult {
        val c = NowPlaying.controller(null)
        if (c != null) c.transportControls.skipToPrevious() else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        return ActionResult(true, "Voltando.")
    }

    fun toggle() = if (AppState.musicPlaying) pause() else resume()

    fun volumeUp(): ActionResult = setVolume((AppState.volume + 10).coerceAtMost(100))
    fun volumeDown(): ActionResult = setVolume((AppState.volume - 10).coerceAtLeast(0))

    fun setVolume(level: Int): ActionResult {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val idx = Math.round(level / 100f * max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
        return ActionResult(true, "Volume em ${refreshVolume()} por cento.")
    }

    fun refreshVolume(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        AppState.volume = Math.round(audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max)
        AppState.changed()
        return AppState.volume
    }

    private fun key(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
