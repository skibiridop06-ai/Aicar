package com.metralha.assistente.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Reconhecimento de alta precisão para o COMANDO (depois do "Metralha"):
 * usa o reconhecedor de voz do próprio Android (Google), pedindo o modo offline.
 * O Vosk continua cuidando só de esperar a palavra "Metralha".
 *
 * Se o reconhecedor do Android não estiver disponível ou falhar, o Metralha volta
 * automaticamente para o Vosk (nada quebra).
 */
class CommandRecognizer(private val ctx: Context, private val listener: Listener) {

    interface Listener {
        fun onCommandPartial(text: String)
        /** Alternativas da melhor para a pior. Lista vazia = não ouviu nada. */
        fun onCommandResult(alternatives: List<String>)
        /** Falha grave: usar o Vosk no lugar. */
        fun onCommandUnavailable(reason: String)
    }

    private var sr: SpeechRecognizer? = null
    var active = false
        private set

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start() {
        if (!isAvailable()) { listener.onCommandUnavailable("reconhecedor do Android indisponível"); return }
        val r = sr ?: SpeechRecognizer.createSpeechRecognizer(ctx).also { sr = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) listener.onCommandPartial(t)
            }

            override fun onResults(results: Bundle?) {
                active = false
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty().filter { it.isNotBlank() }
                listener.onCommandResult(list)
            }

            override fun onError(error: Int) {
                active = false
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> listener.onCommandResult(emptyList())
                    else -> {
                        try { sr?.destroy() } catch (_: Exception) {}
                        sr = null
                        listener.onCommandUnavailable("erro $error do reconhecedor")
                    }
                }
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        try {
            active = true
            r.startListening(intent)
        } catch (e: Exception) {
            active = false
            listener.onCommandUnavailable(e.message ?: "falha ao iniciar")
        }
    }

    fun cancel() {
        active = false
        try { sr?.cancel() } catch (_: Exception) {}
    }

    fun release() {
        cancel()
        try { sr?.destroy() } catch (_: Exception) {}
        sr = null
    }
}
