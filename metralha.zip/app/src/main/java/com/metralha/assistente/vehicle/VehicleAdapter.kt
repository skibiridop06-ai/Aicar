package com.metralha.assistente.vehicle

data class ActionResult(val ok: Boolean, val message: String)

/**
 * Interface ABSTRATA do veículo. Hoje existem 2 implementações:
 *  - VirtualCar  : carro simulado dentro do app (testa tudo sem hardware)
 *  - PhoneVehicle: celular + Bluetooth (mídia e volume reais; clima indisponível)
 *
 * Integrações reais futuras entram aqui como novas classes, por exemplo:
 *  - AndroidAutomotiveVehicle (carros com Android Automotive OS, via CarPropertyManager)
 *  - ManufacturerCloudVehicle (API oficial da montadora, quando existir)
 *  - CanGatewayVehicle (módulo de hardware dedicado, ver README)
 * Nenhuma delas é fingida: se a função não existe, a classe responde "indisponível".
 */
interface VehicleAdapter {
    val displayName: String

    fun setClimateTemperature(celsius: Int): ActionResult
    fun adjustClimateTemperature(delta: Int): ActionResult
    fun setClimatePower(on: Boolean): ActionResult

    fun playMusic(query: String): ActionResult
    fun pauseMusic(): ActionResult
    fun resumeMusic(): ActionResult
    fun nextTrack(): ActionResult
    fun previousTrack(): ActionResult

    fun volumeUp(): ActionResult
    fun volumeDown(): ActionResult
    fun setVolume(level: Int): ActionResult

    /** Resumo curto do estado, enviado como contexto para a IA. */
    fun describe(): String
}
