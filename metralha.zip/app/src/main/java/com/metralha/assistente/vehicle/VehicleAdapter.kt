package com.metralha.assistente.vehicle

import com.metralha.assistente.brain.CommandValidator
import com.metralha.assistente.core.AppState

data class ActionResult(val ok: Boolean, val message: String)

/**
 * Interface ABSTRATA das funções do veículo (hoje: climatização).
 * Música e volume NÃO passam por aqui: são sempre reais, pelo celular (Spotify + Bluetooth).
 *
 * Implementações:
 *  - VirtualCar  : clima simulado dentro do app (para testar sem hardware)
 *  - RealCar     : carro comum via Bluetooth -> clima indisponível (Bluetooth não controla ar)
 * Futuras: AndroidAutomotiveVehicle, API da montadora, módulo CAN dedicado (ver README).
 */
interface VehicleAdapter {
    val displayName: String
    val hasClimate: Boolean
    fun setClimateTemperature(celsius: Int): ActionResult
    fun adjustClimateTemperature(delta: Int): ActionResult
    fun setClimatePower(on: Boolean): ActionResult
}

class VirtualCar : VehicleAdapter {
    override val displayName = "Carro Virtual"
    override val hasClimate = true

    override fun setClimateTemperature(celsius: Int): ActionResult {
        AppState.temperature = celsius
        AppState.acOn = true
        AppState.changed()
        return ActionResult(true, "Ar-condicionado em $celsius graus.")
    }

    override fun adjustClimateTemperature(delta: Int): ActionResult {
        val target = (AppState.temperature + delta).coerceIn(CommandValidator.MIN_TEMP, CommandValidator.MAX_TEMP)
        if (target == AppState.temperature) return ActionResult(false, "Já está no limite: ${AppState.temperature} graus.")
        return setClimateTemperature(target)
    }

    override fun setClimatePower(on: Boolean): ActionResult {
        AppState.acOn = on
        AppState.changed()
        return ActionResult(true, if (on) "Ar ligado em ${AppState.temperature} graus." else "Ar-condicionado desligado.")
    }
}

class RealCar : VehicleAdapter {
    override val displayName = "Carro real"
    override val hasClimate = false
    private val no = ActionResult(
        false,
        "O ar-condicionado ainda não está disponível: este carro não oferece uma conexão compatível. Use o Carro Virtual para testar."
    )
    override fun setClimateTemperature(celsius: Int) = no
    override fun adjustClimateTemperature(delta: Int) = no
    override fun setClimatePower(on: Boolean) = no
}
