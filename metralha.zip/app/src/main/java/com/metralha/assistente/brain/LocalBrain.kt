package com.metralha.assistente.brain

import java.time.LocalDateTime
import kotlin.random.Random

/**
 * O CÉREBRO DO METRALHA — 100% offline, sem IA externa, sem API, sem internet.
 *
 * Ordem: respostas que você ensinou -> comandos do carro -> utilidades (hora, data, contas,
 * lembretes, sorteios) -> conversa (cumprimentos, piadas, curiosidades) -> resposta honesta.
 * Sempre devolve um comando no formato JSON da lista fechada; depois passa pelo validador.
 */
object LocalBrain {

    data class Context(
        val now: LocalDateTime = LocalDateTime.now(),
        val custom: List<Pair<String, String>> = emptyList(),
        val random: Random = Random.Default,
    )

    fun think(raw: String, ctx: Context = Context()): Map<String, Any> {
        val t = TextUtils.norm(raw)
        if (t.isBlank()) return answer("Não ouvi direito. Pode repetir?")

        CustomAnswers.match(t, ctx.custom)?.let { return answer(it) }
        if (TextUtils.has(t, "fahrenheit") || Calculator.answer(raw) != null) utilities(t, raw, ctx)?.let { return it }
        LocalParser.parse(raw)?.let { return it }
        utilities(t, raw, ctx)?.let { return it }
        conversation(t, ctx)?.let { return answer(it) }
        return answer(pick(ctx, UNKNOWN))
    }

    /** true se o cérebro entendeu a frase (não caiu na resposta "não sei"). */
    fun understands(raw: String, custom: List<Pair<String, String>> = emptyList()): Boolean {
        val r = think(raw, Context(custom = custom))
        return !(r["action"] == "answer" && r["text"] in UNKNOWN)
    }

    private fun answer(text: String): Map<String, Any> = mapOf("action" to "answer", "text" to text)

    // ------------------------------------------------------------------ utilidades
    private fun utilities(t: String, raw: String, ctx: Context): Map<String, Any>? {
        fun has(vararg k: String) = TextUtils.has(t, *k)
        val now = ctx.now

        if (has("que horas", "que hora e", "horas sao", "hora agora", "me diz a hora", "fala a hora", "qual a hora"))
            return answer(timeText(now))
        if (has("que dia e hoje", "que dia hoje", "qual a data", "qual e a data", "data de hoje", "dia da semana", "que dia e"))
            return answer(dateText(now))
        if (has("que mes", "qual o mes", "em que mes")) return answer("Estamos em ${MONTHS[now.monthValue - 1]} de ${now.year}.")
        if (has("que ano", "qual o ano", "em que ano")) return answer("Estamos em ${now.year}.")

        if (has("bateria", "carga do celular")) return mapOf("action" to "get_battery")

        // Lembretes e timers
        if (has("cancela o timer", "cancelar o timer", "cancela o lembrete", "cancelar o lembrete", "para o timer", "desliga o timer"))
            return mapOf("action" to "cancel_timer")
        if (has("timer", "temporizador", "cronometro", "me lembra", "me lembre", "me avisa", "me avise", "lembrete", "alarme")) {
            val secs = durationSeconds(t)
            if (secs != null) {
                val label = TextUtils.after(t, listOf("me lembra de", "me lembre de", "me avisa de", "me avise de", "me lembra para", "me lembra pra", "lembrete de", "lembrete para"))
                    ?.substringBefore(" em ")?.substringBefore(" daqui")?.trim()?.takeIf { it.isNotBlank() && TextUtils.numbers(it).isEmpty() }
                val m = mutableMapOf<String, Any>("action" to "set_timer", "seconds" to secs)
                if (label != null) m["label"] = label
                return m
            }
            return answer("Por quanto tempo? Diga, por exemplo: timer de cinco minutos.")
        }

        Calculator.answer(raw)?.let { return answer(it) }

        // Sorteios
        if (has("cara ou coroa")) return answer(if (ctx.random.nextBoolean()) "Deu cara!" else "Deu coroa!")
        if (has("joga um dado", "jogar um dado", "rola um dado", "rolar um dado", "joga o dado"))
            return answer("Deu ${ctx.random.nextInt(1, 7)}!")
        if (has("numero aleatorio", "sorteia um numero", "sortear um numero", "escolhe um numero", "pensa em um numero")) {
            val n = TextUtils.numbers(t)
            val (a, b) = if (n.size >= 2) minOf(n[0], n[1]) to maxOf(n[0], n[1]) else 1 to 100
            return answer("Saiu o ${ctx.random.nextInt(a, b + 1)}.")
        }

        // Conversão de temperatura
        if (has("fahrenheit")) {
            val n = TextUtils.numbers(t).firstOrNull()
            if (n != null) {
                return if (has("para celsius", "em celsius", "pra celsius") || t.indexOf("fahrenheit") < t.indexOf("celsius").let { if (it < 0) Int.MAX_VALUE else it })
                    answer("$n graus Fahrenheit são ${Calculator.format((n - 32) * 5.0 / 9.0)} graus Celsius.")
                else answer("$n graus Celsius são ${Calculator.format(n * 9.0 / 5.0 + 32)} graus Fahrenheit.")
            }
        }
        return null
    }

    fun durationSeconds(t: String): Int? {
        val tokens = t.split(" ").filter { it.isNotEmpty() }
        var total = 0
        var found = false
        var i = 0
        while (i < tokens.size) {
            val r = TextUtils.numberAt(tokens, i)
            if (r != null && r.second < tokens.size) {
                val unit = tokens[r.second]
                val mult = when {
                    unit.startsWith("segundo") -> 1
                    unit.startsWith("minuto") -> 60
                    unit.startsWith("hora") -> 3600
                    else -> 0
                }
                if (mult > 0) { total += (r.first * mult).toInt(); found = true; i = r.second + 1; continue }
            }
            if (tokens[i] == "meia" && i + 1 < tokens.size && tokens[i + 1] == "hora") { total += 1800; found = true; i += 2; continue }
            i++
        }
        return if (found) total else null
    }

    // ------------------------------------------------------------------ conversa
    private fun conversation(t: String, ctx: Context): String? {
        fun has(vararg k: String) = TextUtils.has(t, *k)
        val words = t.split(" ").size
        val h = ctx.now.hour
        val period = when (h) { in 5..11 -> "Bom dia"; in 12..17 -> "Boa tarde"; else -> "Boa noite" }

        if (has("bom dia", "boa tarde", "boa noite")) {
            val said = when { has("bom dia") -> "Bom dia"; has("boa tarde") -> "Boa tarde"; else -> "Boa noite" }
            val fix = if (said != period) " Mas olha, aqui já é ${period.lowercase()}." else ""
            return pick(ctx, listOf("$said! Pronto para a estrada?", "$said! Como posso ajudar?", "$said! Bora rodar?")) + fix
        }
        if (words <= 4 && has("oi", "ola", "e ai", "eai", "fala", "salve", "opa", "hey")) return pick(ctx, listOf("Oi! $period.", "E aí! Tô na escuta.", "Fala! Em que posso ajudar?"))
        if (has("tudo bem", "tudo bom", "como voce esta", "como vai", "beleza", "como voce ta", "tudo certo"))
            return pick(ctx, listOf("Tudo ótimo, motores ligados! E com você?", "Tô bem, obrigado por perguntar. E você?", "Tudo certo por aqui. Bora pra estrada?"))
        if (has("estou bem", "to bem", "tudo otimo", "tranquilo", "de boa")) return pick(ctx, listOf("Que bom! Se precisar, é só chamar.", "Boa! Tô por aqui."))
        if (has("obrigado", "obrigada", "valeu", "brigado", "agradeco")) return pick(ctx, listOf("De nada!", "Tamo junto!", "Por nada, é pra isso que eu tô aqui."))
        if (has("qual seu nome", "qual o seu nome", "como voce se chama", "quem e voce", "quem e tu"))
            return "Eu sou o Metralha, seu copiloto de voz. Funciono direto no celular, sem internet."
        if (has("o que voce faz", "o que voce sabe fazer", "o que voce pode fazer", "como voce funciona", "me ajuda", "ajuda", "comandos"))
            return "Eu controlo o ar, a música e o volume, abro rotas, digo as horas e a data, faço contas, crio lembretes, conto piadas e curiosidades. E você pode me ensinar respostas novas nas configurações."
        if (has("quem te criou", "quem te fez", "quem e seu criador", "seu criador")) return "Fui montado por você, direto do celular. Projeto Metralha, versão 0.2."
        if (has("piada", "me faz rir", "algo engracado")) return pick(ctx, JOKES)
        if (has("curiosidade", "me conta algo", "fato interessante", "voce sabia", "me ensina algo")) return pick(ctx, FACTS)
        if (has("motivacao", "me motiva", "frase motivacional", "to cansado", "estou cansado", "to triste", "estou triste", "desanimado"))
            return pick(ctx, MOTIVATION) + if (has("cansado")) " E se o cansaço apertar, pare num lugar seguro para descansar." else ""
        if (has("te amo", "eu te amo", "gosto de voce")) return pick(ctx, listOf("Também gosto de você! Mas meu coração é de lata.", "Que fofo! Vou fingir que não fiquei vermelho."))
        if (has("voce e inteligente", "voce e lindo", "voce e incrivel", "muito bom", "mandou bem", "boa metralha"))
            return pick(ctx, listOf("Valeu! Faço o meu melhor.", "Aprendi com o melhor: você."))
        if (has("burro", "idiota", "inutil", "lixo")) return pick(ctx, listOf("Poxa. Ainda tô aprendendo. Me ensina nas configurações?", "Vou fingir que não ouvi. Em que posso ajudar?"))
        if (has("tchau", "ate mais", "ate logo", "falou", "boa viagem")) return pick(ctx, listOf("Até mais! Dirija com cuidado.", "Falou! Tô aqui se precisar."))
        if (has("sim", "nao", "ok", "certo", "beleza") && words <= 2) return "Beleza."
        if (has("que dia lindo", "que calor", "que frio") ) return "Se quiser, posso ajustar o ar pra você."
        return null
    }

    // ------------------------------------------------------------------ textos
    fun timeText(now: LocalDateTime): String {
        val h = now.hour
        val m = now.minute
        val hs = if (h == 1) "uma hora" else if (h == 0) "zero hora" else "$h horas"
        return when (m) {
            0 -> "São $hs em ponto."
            else -> (if (h == 1) "É " else "São ") + "$hs e $m minuto" + (if (m == 1) "." else "s.")
        }
    }

    fun dateText(now: LocalDateTime): String =
        "Hoje é ${WEEKDAYS[now.dayOfWeek.value - 1]}, ${now.dayOfMonth} de ${MONTHS[now.monthValue - 1]} de ${now.year}."

    private fun pick(ctx: Context, list: List<String>) = list[ctx.random.nextInt(list.size)]

    private val WEEKDAYS = listOf("segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo")
    private val MONTHS = listOf("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")

    private val UNKNOWN = listOf(
        "Essa eu ainda não sei. Funciono sem internet, então não tenho todas as respostas. Você pode me ensinar nas configurações.",
        "Não sei responder isso ainda. Quer me ensinar? Vá em configurações, respostas personalizadas.",
        "Hmm, essa passou. Posso controlar o ar, a música, dizer as horas, fazer contas ou criar um lembrete."
    )

    private val JOKES = listOf(
        "Por que o carro foi ao psicólogo? Porque estava com muitos problemas de direção.",
        "O que o pneu falou para o outro? Vamos rodar por aí!",
        "Por que o GPS terminou o namoro? Porque ela vivia recalculando a rota.",
        "Qual é o carro preferido do vampiro? O Fusca, porque ele não sai do sangue frio... tá, essa foi ruim.",
        "O que o semáforo disse para o carro? Não olha, que eu estou me trocando!",
        "Por que o motorista levou um lápis pra viagem? Pra desenhar a rota.",
        "Sabe por que a estrada é triste? Porque vive passando por baixo.",
        "Qual é o cúmulo da paciência? Esperar o sinal verde num desenho animado.",
        "O que um volante disse para o outro? Gira comigo!",
        "Por que o carro elétrico é calmo? Porque nunca perde a carga emocional."
    )

    private val FACTS = listOf(
        "O primeiro carro movido a gasolina foi criado por Karl Benz em 1886.",
        "O cinto de segurança de três pontos foi inventado em 1959, e a patente foi liberada para todos de graça.",
        "A Ponte Rio-Niterói tem mais de 13 quilômetros de extensão.",
        "O Brasil tem uma das maiores redes rodoviárias do mundo, com mais de um milhão e meio de quilômetros.",
        "A luz do Sol leva cerca de 8 minutos para chegar à Terra.",
        "O coração humano bate cerca de cem mil vezes por dia.",
        "Os polvos têm três corações e sangue azul.",
        "O mel praticamente não estraga. Já acharam mel comestível em tumbas egípcias.",
        "O primeiro semáforo do mundo foi instalado em Londres, em 1868.",
        "A Lua se afasta da Terra cerca de quatro centímetros por ano."
    )

    private val MOTIVATION = listOf(
        "Devagar também se chega. O importante é não parar.",
        "Cada quilômetro conta. Você está mais perto do que imagina.",
        "Dias difíceis fazem motoristas melhores. Bora!",
        "Respira fundo. Uma coisa de cada vez, como numa boa estrada."
    )
}

/** Respostas que o próprio usuário ensina ("quando eu disser X, responda Y"). */
object CustomAnswers {
    fun match(norm: String, list: List<Pair<String, String>>): String? {
        if (list.isEmpty()) return null
        val words = norm.split(" ").filter { it.length > 1 }.toSet()
        var best: String? = null
        var bestScore = 0.0
        for ((q, a) in list) {
            val qn = TextUtils.norm(q)
            if (qn.isBlank()) continue
            if (norm == qn || " $norm ".contains(" $qn ")) return a
            val qw = qn.split(" ").filter { it.length > 1 }.toSet()
            if (qw.isEmpty() || words.isEmpty()) continue
            val score = (words intersect qw).size.toDouble() / (words union qw).size
            if (score > bestScore) { bestScore = score; best = a }
        }
        return if (bestScore >= 0.6) best else null
    }
}
