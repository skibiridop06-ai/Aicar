package com.metralha.assistente.brain

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * LISTA FECHADA de ações permitidas. Qualquer coisa fora daqui é rejeitada.
 * Nada que venha da IA é executado como código: só lemos estes campos.
 */
enum class Action(val id: String, val needsConfirmation: Boolean = false) {
    SET_CLIMATE_TEMPERATURE("set_climate_temperature"),
    ADJUST_CLIMATE_TEMPERATURE("adjust_climate_temperature"),
    SET_CLIMATE_POWER("set_climate_power"),
    PLAY_MUSIC("play_music"),
    PAUSE_MUSIC("pause_music"),
    RESUME_MUSIC("resume_music"),
    NEXT_TRACK("next_track"),
    PREVIOUS_TRACK("previous_track"),
    VOLUME_UP("volume_up"),
    VOLUME_DOWN("volume_down"),
    SET_VOLUME("set_volume"),
    OPEN_NAVIGATION("open_navigation"),
    START_ROUTE("start_route", needsConfirmation = true),
    OPEN_MUSIC_APP("open_music_app"),
    GET_BATTERY("get_battery"),
    SET_TIMER("set_timer"),
    CANCEL_TIMER("cancel_timer"),
    ANSWER("answer"),
    UNSUPPORTED("unsupported");

    companion object {
        fun fromId(id: Any?): Action? = entries.firstOrNull { it.id == id }
    }
}

data class Command(
    val action: Action,
    val temperature: Int? = null,
    val delta: Int? = null,
    val on: Boolean? = null,
    val level: Int? = null,
    val query: String? = null,
    val destination: String? = null,
    val text: String? = null,
    val seconds: Int? = null,
    val label: String? = null,
) {
    fun toJson(): String {
        val m = linkedMapOf<String, Any?>("action" to action.id)
        temperature?.let { m["temperature"] = it }
        delta?.let { m["delta"] = it }
        on?.let { m["on"] = it }
        level?.let { m["level"] = it }
        query?.let { m["query"] = it }
        destination?.let { m["destination"] = it }
        seconds?.let { m["seconds"] = it }
        label?.let { m["label"] = it }
        text?.let { m[if (action == Action.UNSUPPORTED) "reason" else "text"] = it }
        return Json.write(m)
    }
}

sealed class Validation {
    data class Ok(val command: Command) : Validation()
    data class Rejected(val reason: String) : Validation()
}

/** Valida TODOS os parâmetros antes de qualquer execução. */
object CommandValidator {
    const val MIN_TEMP = 16
    const val MAX_TEMP = 30

    fun validate(m: Map<String, Any?>): Validation {
        val action = Action.fromId(m["action"])
            ?: return Validation.Rejected("Essa ação não está na lista de ações permitidas.")

        return when (action) {
            Action.SET_CLIMATE_TEMPERATURE -> {
                val t = int(m["temperature"]) ?: return Validation.Rejected("Não entendi a temperatura.")
                if (t !in MIN_TEMP..MAX_TEMP) Validation.Rejected("A temperatura precisa ficar entre $MIN_TEMP e $MAX_TEMP graus.")
                else Validation.Ok(Command(action, temperature = t))
            }
            Action.ADJUST_CLIMATE_TEMPERATURE -> {
                val d = int(m["delta"]) ?: return Validation.Rejected("Não entendi quanto ajustar.")
                if (d == 0 || abs(d) > 5) Validation.Rejected("Só ajusto de 1 a 5 graus por vez.")
                else Validation.Ok(Command(action, delta = d))
            }
            Action.SET_CLIMATE_POWER -> {
                val on = bool(m["on"]) ?: return Validation.Rejected("Não entendi se é para ligar ou desligar.")
                Validation.Ok(Command(action, on = on))
            }
            Action.PLAY_MUSIC -> {
                val q = text(m["query"], 100) ?: return Validation.Rejected("Qual música?")
                Validation.Ok(Command(action, query = q))
            }
            Action.SET_VOLUME -> {
                val l = int(m["level"]) ?: return Validation.Rejected("Não entendi o volume.")
                if (l !in 0..100) Validation.Rejected("O volume vai de 0 a 100.")
                else Validation.Ok(Command(action, level = l))
            }
            Action.START_ROUTE -> {
                val d = text(m["destination"], 150) ?: return Validation.Rejected("Para onde?")
                if (d.length < 2) Validation.Rejected("Para onde?")
                else Validation.Ok(Command(action, destination = d))
            }
            Action.SET_TIMER -> {
                val s = int(m["seconds"]) ?: return Validation.Rejected("Por quanto tempo?")
                if (s !in 5..10800) Validation.Rejected("O lembrete pode ser de 5 segundos até 3 horas.")
                else Validation.Ok(Command(action, seconds = s, label = text(m["label"], 60)))
            }
            Action.ANSWER -> {
                val t = text(m["text"], 800) ?: return Validation.Rejected("Não sei o que responder.")
                Validation.Ok(Command(action, text = t))
            }
            Action.UNSUPPORTED -> {
                val r = text(m["reason"], 300) ?: "Não posso fazer isso."
                Validation.Ok(Command(action, text = r))
            }
            else -> Validation.Ok(Command(action))
        }
    }

    private fun int(v: Any?): Int? {
        val d: Double = when (v) {
            is Number -> v.toDouble()
            is String -> v.trim().replace(',', '.').toDoubleOrNull() ?: return null
            else -> return null
        }
        if (d.isNaN() || d.isInfinite() || abs(d) > 1_000_000) return null
        return d.roundToInt()
    }

    private fun bool(v: Any?): Boolean? = when (v) {
        is Boolean -> v
        is String -> when (v.trim().lowercase()) {
            "true", "on", "ligar", "ligado", "sim" -> true
            "false", "off", "desligar", "desligado", "nao", "não" -> false
            else -> null
        }
        else -> null
    }

    private fun text(v: Any?, max: Int): String? {
        val s = (v as? String) ?: return null
        val clean = s.replace(Regex("\\p{Cntrl}"), " ").replace(Regex("\\s+"), " ").trim()
        return if (clean.isEmpty()) null else clean.take(max)
    }
}

/** Escritor JSON mínimo (só para exibir/registrar comandos). */
object Json {
    fun write(v: Any?): String = when (v) {
        null -> "null"
        is String -> quote(v)
        is Number, is Boolean -> v.toString()
        is Map<*, *> -> v.entries.joinToString(", ", "{", "}") { quote(it.key.toString()) + ": " + write(it.value) }
        is List<*> -> v.joinToString(", ", "[", "]") { write(it) }
        else -> quote(v.toString())
    }

    private fun quote(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        return sb.append('"').toString()
    }
}
