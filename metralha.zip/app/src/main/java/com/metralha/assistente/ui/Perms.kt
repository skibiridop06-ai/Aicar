package com.metralha.assistente.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import com.metralha.assistente.media.NowPlaying

/** Permissões especiais para funcionar com a tela apagada e controlar o Spotify. */
object Perms {
    fun media(a: Activity) = NowPlaying.isAllowed(a)
    fun overlay(a: Activity) = Settings.canDrawOverlays(a)
    fun battery(a: Activity) = a.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(a.packageName)
    fun allOk(a: Activity) = media(a) && overlay(a) && battery(a)

    fun openMedia(a: Activity) {
        Toast.makeText(
            a,
            "Ative o Metralha. Se estiver cinza: Configurações > Apps > Metralha > ⋮ > Permitir configurações restritas.",
            Toast.LENGTH_LONG
        ).show()
        open(a, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    fun openOverlay(a: Activity) {
        Toast.makeText(a, "Ative “Sobrepor a outros apps” para o Metralha.", Toast.LENGTH_LONG).show()
        open(a, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName)))
    }

    @SuppressLint("BatteryLife")
    fun openBattery(a: Activity) {
        val ok = open(a, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + a.packageName)))
        if (!ok) open(a, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun open(a: Activity, i: Intent): Boolean = try { a.startActivity(i); true } catch (e: Exception) { false }
}
