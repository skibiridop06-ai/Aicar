package com.metralha.assistente.brain

/**
 * Detecção da palavra de ativação "Metralha" sobre o texto reconhecido LOCALMENTE.
 * Tolera pequenos erros do reconhecedor ("metralhar", "me tralha", "metralia"...).
 */
object WakeWord {
    const val WORD = "metralha"

    /** Gramática usada no modo econômico (o reconhecedor só "procura" estas palavras). */
    const val GRAMMAR_JSON = "[\"metralha\", \"metralhadora\", \"me tralha\", \"[unk]\"]"

    data class Match(val found: Boolean, val rest: String)

    fun find(norm: String): Match {
        val tokens = norm.split(" ").filter { it.isNotEmpty() }
        for (i in tokens.indices) {
            if (isWake(tokens[i])) {
                return Match(true, tokens.drop(i + 1).joinToString(" "))
            }
            if (i + 1 < tokens.size && isWake(tokens[i] + tokens[i + 1])) {
                return Match(true, tokens.drop(i + 2).joinToString(" "))
            }
        }
        return Match(false, "")
    }

    fun isWake(token: String): Boolean {
        if (token.startsWith("metralh")) return true
        if (token.length < 7) return false
        return levenshtein(token, WORD) <= 1
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
