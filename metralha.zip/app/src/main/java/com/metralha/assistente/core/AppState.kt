package com.metralha.assistente.core

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

enum class ListenStatus(val label: String) {
    INICIANDO("Carregando a voz…"),
    OUVINDO("Metralha está ouvindo"),
    ATIVADA("Metralha ativada"),
    PROCESSANDO("Pensando…"),
    FALANDO("Respondendo…"),
    CONFIRMANDO("Aguardando: sim ou não?"),
    PARADA("Escuta desligada"),
    ERRO("Erro")
}

data class HistoryItem(val time: String, val heard: String, val json: String, val reply: String)

/** Estado único do app (tela + carro virtual). Alterado só na thread principal. */
object AppState {
    var status = ListenStatus.PARADA
    var detail = ""
    var partial = ""

    // Carro virtual
    var temperature = 22
    var acOn = false
    var volume = 40
    var musicTitle = "Nenhuma"
    var musicPlaying = false

    var bluetooth = "Verificando…"
    var aiStatus = "Local (offline)"
    var activityVisible = false

    val history = ArrayDeque<HistoryItem>()

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    fun changed() {
        main.post { listeners.forEach { it() } }
    }

    fun addHistory(item: HistoryItem) {
        history.addFirst(item)
        while (history.size > 12) history.removeLast()
        changed()
    }
}
