package com.metralha.assistente.core

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

enum class ListenStatus(val label: String) {
    INICIANDO("Carregando a voz…"),
    OUVINDO("Pronto. Diga “Metralha”"),
    ATIVADA("Estou ouvindo…"),
    PROCESSANDO("Pensando…"),
    FALANDO("Falando…"),
    CONFIRMANDO("Sim ou não?"),
    PARADA("Escuta pausada"),
    ERRO("Erro")
}

data class HistoryItem(val time: String, val heard: String, val json: String, val reply: String)

/** Estado único do app (tela + carro virtual + música). Alterado só na thread principal. */
object AppState {
    var status = ListenStatus.PARADA
    var detail = ""
    var partial = ""

    // Clima (Carro Virtual)
    var temperature = 22
    var acOn = false

    // Mídia real do celular
    var volume = 40
    var musicTitle = "Nada tocando"
    var musicArtist = ""
    var musicApp = ""
    var musicPlaying = false

    var bluetooth = "Sem Bluetooth"
    var bluetoothConnected = false
    var activityVisible = false

    // Navegação (lida do Google Maps)
    var navActive = false
    var navInstruction = ""
    var navEta = ""

    // Lembrete
    var timerEndAt = 0L
    var timerLabel = ""

    val history = ArrayDeque<HistoryItem>()

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var posted = false

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Avisa a tela (agrupando várias mudanças seguidas num único redesenho). */
    fun changed() {
        if (posted) return
        posted = true
        main.post {
            posted = false
            listeners.forEach { it() }
        }
    }

    fun addHistory(item: HistoryItem) {
        history.addFirst(item)
        while (history.size > 20) history.removeLast()
        changed()
    }
}
