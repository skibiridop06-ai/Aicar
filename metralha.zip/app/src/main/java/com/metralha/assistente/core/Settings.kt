package com.metralha.assistente.core

import android.content.Context

/** Configurações salvas no próprio celular. */
class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("metralha", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("apiKey", "") ?: ""
        set(v) = p.edit().putString("apiKey", v.trim()).apply()

    var baseUrl: String
        get() = p.getString("baseUrl", DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(v) = p.edit().putString("baseUrl", v.trim().ifEmpty { DEFAULT_BASE_URL }).apply()

    var model: String
        get() = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = p.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    /** Modo econômico: o reconhecedor só procura a palavra "Metralha" enquanto espera. */
    var economyMode: Boolean
        get() = p.getBoolean("economy", false)
        set(v) = p.edit().putBoolean("economy", v).apply()

    /** true = Carro Virtual (teste). false = Celular + Bluetooth (carro real). */
    var virtualCar: Boolean
        get() = p.getBoolean("virtualCar", true)
        set(v) = p.edit().putBoolean("virtualCar", v).apply()

    companion object {
        // Google Gemini (camada gratuita) pela interface compatível com OpenAI
        const val DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
        const val DEFAULT_MODEL = "gemini-flash-latest"
    }
}
