package com.metralha.assistente.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Configurações salvas só no próprio celular. Nenhuma chave, nenhuma conta, nenhuma API. */
class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("metralha", Context.MODE_PRIVATE)

    /** true = ar-condicionado simulado (Carro Virtual). false = carro real (clima indisponível). */
    var virtualCar: Boolean
        get() = p.getBoolean("virtualCar", true)
        set(v) = p.edit().putBoolean("virtualCar", v).apply()

    /** Modo econômico: enquanto espera, o reconhecedor só procura a palavra "Metralha". */
    var economyMode: Boolean
        get() = p.getBoolean("economy", false)
        set(v) = p.edit().putBoolean("economy", v).apply()

    /** Conversa contínua: depois de responder, ouve mais alguns segundos sem precisar dizer "Metralha". */
    var followUp: Boolean
        get() = p.getBoolean("followUp", true)
        set(v) = p.edit().putBoolean("followUp", v).apply()

    /** Usa o reconhecedor de voz do Android (Google, offline quando possível) para os comandos. */
    var betterRecognition: Boolean
        get() = p.getBoolean("betterRecognition", true)
        set(v) = p.edit().putBoolean("betterRecognition", v).apply()

    /** O Metralha fala em voz alta cada instrução do GPS (Google Maps). */
    var navVoice: Boolean
        get() = p.getBoolean("navVoice", true)
        set(v) = p.edit().putBoolean("navVoice", v).apply()

    var keepScreenOn: Boolean
        get() = p.getBoolean("keepScreenOn", false)
        set(v) = p.edit().putBoolean("keepScreenOn", v).apply()

    /** "spotify", "ytmusic" ou "any" */
    var musicApp: String
        get() = p.getString("musicApp", "spotify") ?: "spotify"
        set(v) = p.edit().putString("musicApp", v).apply()

    /** Nome da voz do Android ("" = escolher a melhor automaticamente). */
    var voiceName: String
        get() = p.getString("voiceName", "") ?: ""
        set(v) = p.edit().putString("voiceName", v).apply()

    var speechRate: Float
        get() = p.getFloat("speechRate", 1.05f)
        set(v) = p.edit().putFloat("speechRate", v).apply()

    var pitch: Float
        get() = p.getFloat("pitch", 0.95f)
        set(v) = p.edit().putFloat("pitch", v).apply()

    /** Respostas ensinadas pelo usuário: pergunta -> resposta. */
    var customAnswers: List<Pair<String, String>>
        get() = try {
            val arr = JSONArray(p.getString("custom", "[]"))
            (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.optString("q") to o.optString("a") } }
                .filter { it.first.isNotBlank() && it.second.isNotBlank() }
        } catch (e: Exception) { emptyList() }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(JSONObject().put("q", it.first).put("a", it.second)) }
            p.edit().putString("custom", arr.toString()).apply()
        }

    companion object {
        const val SPOTIFY = "com.spotify.music"
        const val YT_MUSIC = "com.google.android.apps.youtube.music"
    }
}
