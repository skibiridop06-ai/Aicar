package com.metralha.assistente.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Holograma 3D do Metralha, desenhado em tempo real:
 *  - esfera de partículas em 3D (projeção em perspectiva), que gira e "respira" com a voz
 *  - anel orbital inclinado
 *  - estrada em perspectiva correndo no horizonte
 * Cor e energia mudam conforme o estado (ouvindo, ativado, pensando, falando).
 */
class HoloView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class Mode { OFF, IDLE, ACTIVE, THINK, SPEAK, CONFIRM, ERROR }

    private val n = 320
    private val sphere = FloatArray(n * 3)
    private val ringPts = 140

    private var curColor = Color.parseColor("#0A6F80")
    private var targetColor = curColor
    private var energy = 0.2f
    private var targetEnergy = 0.2f
    private var speed = 0.25f
    private var targetSpeed = 0.25f
    private var mode = Mode.IDLE

    private var t = 0f
    private var rot = 0f
    private var last = 0L

    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowKey = 0L
    private val density = resources.displayMetrics.density

    init {
        val golden = PI * (3 - sqrt(5.0))
        for (i in 0 until n) {
            val y = 1 - (i / (n - 1f)) * 2
            val r = sqrt(1 - y * y)
            val th = golden * i
            sphere[i * 3] = (cos(th) * r).toFloat()
            sphere[i * 3 + 1] = y
            sphere[i * 3 + 2] = (sin(th) * r).toFloat()
        }
    }

    fun setMode(m: Mode) {
        mode = m
        val (c, e, s) = when (m) {
            Mode.OFF -> Triple("#3A4A60", 0.05f, 0.08f)
            Mode.IDLE -> Triple("#00B8D4", 0.18f, 0.25f)
            Mode.ACTIVE -> Triple("#00E5FF", 0.85f, 0.9f)
            Mode.THINK -> Triple("#B388FF", 0.6f, 1.8f)
            Mode.SPEAK -> Triple("#2EE59D", 1.0f, 0.6f)
            Mode.CONFIRM -> Triple("#FFB020", 0.7f, 0.7f)
            Mode.ERROR -> Triple("#FF4D6D", 0.3f, 0.15f)
        }
        targetColor = Color.parseColor(c)
        targetEnergy = e
        targetSpeed = s
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        t += dt
        val k = (dt * 4f).coerceAtMost(1f)
        energy += (targetEnergy - energy) * k
        speed += (targetSpeed - speed) * k
        curColor = lerpColor(curColor, targetColor, k)
        rot += dt * speed

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.40f
        val r = min(w, h) * 0.24f

        drawRoad(canvas, w, h, cx)
        drawGlow(canvas, cx, cy, r)
        drawRing(canvas, cx, cy, r, back = true)
        drawSphere(canvas, cx, cy, r)
        drawRing(canvas, cx, cy, r, back = false)
        drawCore(canvas, cx, cy, r)
        if (mode == Mode.SPEAK || mode == Mode.ACTIVE) drawWaves(canvas, cx, cy, r)

        if (isShown) postInvalidateOnAnimation()
    }

    // Estrada / grade em perspectiva
    private fun drawRoad(c: Canvas, w: Float, h: Float, cx: Float) {
        val horizon = h * 0.76f
        line.strokeWidth = 1f * density
        val roadSpeed = 0.35f + speed * 0.4f
        // linhas verticais convergindo para o ponto de fuga
        for (i in -9..9) {
            val xb = cx + i * w * 0.16f
            val xt = cx + i * w * 0.012f
            line.color = withAlpha(curColor, (70 - kotlin.math.abs(i) * 6).coerceAtLeast(12))
            c.drawLine(xt, horizon, xb, h, line)
        }
        // linhas horizontais vindo em direção à tela
        val phase = (t * roadSpeed) % 1f
        for (i in 0 until 10) {
            val f = ((i + phase) / 10f)
            val y = horizon + (h - horizon) * f.pow(2.2f)
            line.color = withAlpha(curColor, (f * 110).toInt().coerceIn(0, 110))
            c.drawLine(0f, y, w, y, line)
        }
        // brilho do horizonte
        line.strokeWidth = 2f * density
        line.color = withAlpha(curColor, 140)
        c.drawLine(cx - w * 0.45f, horizon, cx + w * 0.45f, horizon, line)
    }

    private fun drawGlow(c: Canvas, cx: Float, cy: Float, r: Float) {
        val key = (curColor.toLong() shl 16) xor (r.toLong())
        if (key != glowKey) {
            glow.shader = RadialGradient(
                cx, cy, r * 2.1f,
                intArrayOf(withAlpha(curColor, 90), withAlpha(curColor, 30), Color.TRANSPARENT),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            glowKey = key
        }
        c.drawCircle(cx, cy, r * 2.1f, glow)
    }

    private fun drawSphere(c: Canvas, cx: Float, cy: Float, r: Float) {
        val tilt = 0.38f
        val cosT = cos(tilt); val sinT = sin(tilt)
        val cosR = cos(rot); val sinR = sin(rot)
        val e = energy
        for (i in 0 until n) {
            var x = sphere[i * 3]; var y = sphere[i * 3 + 1]; var z = sphere[i * 3 + 2]
            // deformação "voz": ondas na superfície
            val d = 1f + e * (0.13f * sin(6f * y + t * 5f) + 0.07f * sin(5f * x - t * 3.7f) + 0.05f * sin(9f * z + t * 7f))
            x *= d; y *= d; z *= d
            // rotação Y
            val x1 = x * cosR + z * sinR
            val z1 = -x * sinR + z * cosR
            // rotação X (inclinação)
            val y2 = y * cosT - z1 * sinT
            val z2 = y * sinT + z1 * cosT
            // perspectiva
            val p = 3.2f / (3.2f + z2)
            val sx = cx + x1 * r * p
            val sy = cy + y2 * r * p
            val depth = ((1f - z2) / 2f).coerceIn(0f, 1f) // 1 = frente
            dot.color = withAlpha(lerpColor(curColor, Color.WHITE, depth * 0.35f), (40 + depth * 215).toInt())
            c.drawCircle(sx, sy, (0.6f + depth * 1.9f + e * 0.6f) * density, dot)
        }
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, r: Float, back: Boolean) {
        val tilt = 1.18f
        val cosT = cos(tilt); val sinT = sin(tilt)
        val spin = -rot * 1.6f
        val rr = 1.42f
        for (i in 0 until ringPts) {
            val a = (i / ringPts.toFloat()) * 2f * PI.toFloat() + spin
            val x = cos(a) * rr
            val z = sin(a) * rr
            val y2 = -z * sinT
            val z2 = z * cosT
            if ((z2 > 0) != back) continue
            val p = 3.2f / (3.2f + z2)
            val depth = ((1.42f - z2) / 2.84f).coerceIn(0f, 1f)
            val seg = (i % 10) < 7
            if (!seg) continue
            dot.color = withAlpha(curColor, (30 + depth * 170).toInt())
            c.drawCircle(cx + x * r * p, cy + y2 * r * p + r * 0.05f, (0.8f + depth * 1.3f) * density, dot)
        }
    }

    private fun drawCore(c: Canvas, cx: Float, cy: Float, r: Float) {
        val pulse = 1f + 0.08f * sin(t * (2f + energy * 6f)) * (0.3f + energy)
        val cr = r * 0.32f * pulse
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            cx, cy, cr,
            intArrayOf(Color.WHITE, withAlpha(curColor, 230), withAlpha(curColor, 0)),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, cr, p)
    }

    private fun drawWaves(c: Canvas, cx: Float, cy: Float, r: Float) {
        line.strokeWidth = 1.5f * density
        for (k in 0 until 3) {
            val f = ((t * 0.7f + k / 3f) % 1f)
            line.color = withAlpha(curColor, ((1f - f) * 120).toInt())
            c.drawCircle(cx, cy, r * (1.05f + f * 0.9f), line)
        }
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun lerpColor(a: Int, b: Int, f: Float): Int {
        val ff = f.coerceIn(0f, 1f)
        return Color.argb(
            255,
            (Color.red(a) + (Color.red(b) - Color.red(a)) * ff).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * ff).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * ff).toInt()
        )
    }
}
