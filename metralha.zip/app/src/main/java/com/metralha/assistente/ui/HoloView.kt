package com.metralha.assistente.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Holograma 3D do Metralha (desenhado em tempo real, 60 fps):
 *  - globo de partículas com malha (plexus) em perspectiva 3D, girando e ondulando com a voz
 *  - brilho aditivo (bloom), núcleo de energia pulsante
 *  - dois anéis orbitais inclinados
 *  - equalizador radial quando o Metralha fala ou escuta
 *  - campo de estrelas e estrada neon em perspectiva com faixa central em movimento
 */
class HoloView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class Mode { OFF, IDLE, ACTIVE, THINK, SPEAK, CONFIRM, ERROR }

    private val n = 380
    private val base = FloatArray(n * 3)
    private val proj = FloatArray(n * 3) // sx, sy, depth
    private val neighbors = IntArray(n * 3)

    private val starCount = 90
    private val stars = FloatArray(starCount * 4) // x, y, phase, size

    private var curColor = Color.parseColor("#00B8D4")
    private var targetColor = curColor
    private var energy = 0.2f
    private var targetEnergy = 0.2f
    private var speed = 0.25f
    private var targetSpeed = 0.25f
    private var mode = Mode.IDLE

    private var t = 0f
    private var rot = 0f
    private var last = 0L
    private val density = resources.displayMetrics.density

    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
    private val mesh = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; xfermode = add }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; xfermode = add }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val band = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shaderColor = 0
    private var shaderW = 0f

    init {
        // Pontos distribuídos uniformemente na esfera (espiral de Fibonacci)
        val golden = PI * (3 - sqrt(5.0))
        for (i in 0 until n) {
            val y = 1 - (i / (n - 1f)) * 2
            val r = sqrt(1 - y * y)
            val th = golden * i
            base[i * 3] = (cos(th) * r).toFloat()
            base[i * 3 + 1] = y
            base[i * 3 + 2] = (sin(th) * r).toFloat()
        }
        // 3 vizinhos mais próximos de cada ponto (malha)
        for (i in 0 until n) {
            val best = FloatArray(3) { Float.MAX_VALUE }
            val idx = IntArray(3) { i }
            for (j in 0 until n) {
                if (j == i) continue
                val dx = base[i * 3] - base[j * 3]; val dy = base[i * 3 + 1] - base[j * 3 + 1]; val dz = base[i * 3 + 2] - base[j * 3 + 2]
                val d = dx * dx + dy * dy + dz * dz
                var k = 2
                if (d < best[2]) {
                    while (k > 0 && d < best[k - 1]) { best[k] = best[k - 1]; idx[k] = idx[k - 1]; k-- }
                    best[k] = d; idx[k] = j
                }
            }
            neighbors[i * 3] = idx[0]; neighbors[i * 3 + 1] = idx[1]; neighbors[i * 3 + 2] = idx[2]
        }
        val rnd = Random(7)
        for (i in 0 until starCount) {
            stars[i * 4] = rnd.nextFloat()
            stars[i * 4 + 1] = rnd.nextFloat() * 0.72f
            stars[i * 4 + 2] = rnd.nextFloat() * 6.28f
            stars[i * 4 + 3] = 0.5f + rnd.nextFloat() * 1.2f
        }
    }

    fun setMode(m: Mode) {
        mode = m
        val (c, e, s) = when (m) {
            Mode.OFF -> Triple("#3A4A60", 0.05f, 0.08f)
            Mode.IDLE -> Triple("#00B8D4", 0.16f, 0.22f)
            Mode.ACTIVE -> Triple("#00E5FF", 0.85f, 0.9f)
            Mode.THINK -> Triple("#B388FF", 0.55f, 2.2f)
            Mode.SPEAK -> Triple("#2EE59D", 1.0f, 0.55f)
            Mode.CONFIRM -> Triple("#FFB020", 0.7f, 0.7f)
            Mode.ERROR -> Triple("#FF4D6D", 0.3f, 0.12f)
        }
        targetColor = Color.parseColor(c)
        targetEnergy = e
        targetSpeed = s
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        t += dt
        val k = (dt * 4f).coerceAtMost(1f)
        energy += (targetEnergy - energy) * k
        speed += (targetSpeed - speed) * k
        curColor = lerpColor(curColor, targetColor, (k * 1.5f).coerceAtMost(1f))
        rot += dt * speed

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.40f
        val r = min(w, h) * 0.24f

        drawStars(canvas, w, h)
        drawRoad(canvas, w, h, cx)
        drawGlow(canvas, w, cx, cy, r)
        drawRing(canvas, cx, cy, r, back = true, tilt = 1.18f, radius = 1.45f, spin = -rot * 1.6f)
        drawRing(canvas, cx, cy, r, back = true, tilt = -0.9f, radius = 1.25f, spin = rot * 2.3f)
        drawSphere(canvas, cx, cy, r)
        drawCore(canvas, cx, cy, r)
        drawRing(canvas, cx, cy, r, back = false, tilt = 1.18f, radius = 1.45f, spin = -rot * 1.6f)
        drawRing(canvas, cx, cy, r, back = false, tilt = -0.9f, radius = 1.25f, spin = rot * 2.3f)
        if (energy > 0.45f) drawEqualizer(canvas, cx, cy, r)

        if (isShown) postInvalidateOnAnimation()
    }

    private fun drawStars(c: Canvas, w: Float, h: Float) {
        for (i in 0 until starCount) {
            val x = ((stars[i * 4] + t * 0.004f * stars[i * 4 + 3]) % 1f) * w
            val y = stars[i * 4 + 1] * h
            val a = (0.35f + 0.65f * (0.5f + 0.5f * sin(t * 1.3f + stars[i * 4 + 2]))) * 110
            dot.color = withAlpha(lerpColor(Color.WHITE, curColor, 0.4f), a.toInt())
            c.drawCircle(x, y, stars[i * 4 + 3] * density * 0.7f, dot)
        }
    }

    private fun drawRoad(c: Canvas, w: Float, h: Float, cx: Float) {
        val horizon = h * 0.76f
        // faixa de brilho no horizonte
        if (shaderColor != curColor || shaderW != w) {
            band.shader = LinearGradient(0f, horizon - 40 * density, 0f, horizon + 4 * density,
                intArrayOf(Color.TRANSPARENT, withAlpha(curColor, 70), withAlpha(curColor, 0)), floatArrayOf(0f, 0.85f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, horizon - 40 * density, w, horizon + 4 * density, band)

        line.strokeWidth = 1f * density
        val roadSpeed = 0.35f + speed * 0.5f
        for (i in -9..9) {
            val xb = cx + i * w * 0.16f
            val xt = cx + i * w * 0.012f
            line.color = withAlpha(curColor, (60 - abs(i) * 5).coerceAtLeast(10))
            c.drawLine(xt, horizon, xb, h, line)
        }
        val phase = (t * roadSpeed) % 1f
        for (i in 0 until 10) {
            val f = (i + phase) / 10f
            val y = horizon + (h - horizon) * f.pow(2.2f)
            line.color = withAlpha(curColor, (f * 100).toInt().coerceIn(0, 100))
            c.drawLine(0f, y, w, y, line)
        }
        // bordas da pista e faixa central tracejada em movimento
        line.strokeWidth = 2.2f * density
        line.color = withAlpha(curColor, 170)
        c.drawLine(cx - w * 0.03f, horizon, cx - w * 0.42f, h, line)
        c.drawLine(cx + w * 0.03f, horizon, cx + w * 0.42f, h, line)
        line.color = withAlpha(Color.WHITE, 190)
        for (i in 0 until 6) {
            val f1 = ((i + phase * 2f) / 6f) % 1f
            val f2 = (f1 + 0.07f).coerceAtMost(1f)
            val y1 = horizon + (h - horizon) * f1.pow(2.2f)
            val y2 = horizon + (h - horizon) * f2.pow(2.2f)
            line.strokeWidth = (1f + f1 * 3f) * density
            c.drawLine(cx, y1, cx, y2, line)
        }
        line.strokeWidth = 2f * density
        line.color = withAlpha(curColor, 150)
        c.drawLine(0f, horizon, w, horizon, line)
    }

    private fun drawGlow(c: Canvas, w: Float, cx: Float, cy: Float, r: Float) {
        if (shaderColor != curColor || shaderW != w) {
            glow.shader = RadialGradient(cx, cy, r * 2.2f,
                intArrayOf(withAlpha(curColor, 95), withAlpha(curColor, 28), Color.TRANSPARENT),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            core.shader = RadialGradient(0f, 0f, 1f,
                intArrayOf(Color.WHITE, withAlpha(curColor, 235), withAlpha(curColor, 0)),
                floatArrayOf(0f, 0.32f, 1f), Shader.TileMode.CLAMP)
            shaderColor = curColor
            shaderW = w
        }
        c.drawCircle(cx, cy, r * 2.2f, glow)
    }

    private fun drawSphere(c: Canvas, cx: Float, cy: Float, r: Float) {
        val tilt = 0.38f
        val cosT = cos(tilt); val sinT = sin(tilt)
        val cosR = cos(rot); val sinR = sin(rot)
        val e = energy
        for (i in 0 until n) {
            var x = base[i * 3]; var y = base[i * 3 + 1]; var z = base[i * 3 + 2]
            val d = 1f + e * (0.09f * sin(6f * y + t * 5f) + 0.05f * sin(5f * x - t * 3.7f) + 0.035f * sin(9f * z + t * 7f))
            x *= d; y *= d; z *= d
            val x1 = x * cosR + z * sinR
            val z1 = -x * sinR + z * cosR
            val y2 = y * cosT - z1 * sinT
            val z2 = y * sinT + z1 * cosT
            val p = 3.2f / (3.2f + z2)
            proj[i * 3] = cx + x1 * r * p
            proj[i * 3 + 1] = cy + y2 * r * p
            proj[i * 3 + 2] = ((1f - z2) / 2f).coerceIn(0f, 1f)
        }
        // malha
        mesh.strokeWidth = 0.7f * density
        for (i in 0 until n) {
            for (kk in 0 until 3) {
                val j = neighbors[i * 3 + kk]
                if (j < i) continue
                val dep = (proj[i * 3 + 2] + proj[j * 3 + 2]) * 0.5f
                mesh.color = withAlpha(curColor, (8 + dep * 70).toInt())
                c.drawLine(proj[i * 3], proj[i * 3 + 1], proj[j * 3], proj[j * 3 + 1], mesh)
            }
        }
        // partículas com brilho
        for (i in 0 until n) {
            val dep = proj[i * 3 + 2]
            val sx = proj[i * 3]; val sy = proj[i * 3 + 1]
            val size = (0.6f + dep * 1.7f + e * 0.6f) * density
            if (dep > 0.55f) {
                halo.color = withAlpha(curColor, (dep * 45).toInt())
                c.drawCircle(sx, sy, size * 3.2f, halo)
            }
            dot.color = withAlpha(lerpColor(curColor, Color.WHITE, dep * 0.45f), (40 + dep * 215).toInt())
            c.drawCircle(sx, sy, size, dot)
        }
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, r: Float, back: Boolean, tilt: Float, radius: Float, spin: Float) {
        val cosT = cos(tilt); val sinT = sin(tilt)
        val pts = 150
        for (i in 0 until pts) {
            if (i % 12 >= 9) continue
            val a = (i / pts.toFloat()) * 2f * PI.toFloat() + spin
            val x = cos(a) * radius
            val z = sin(a) * radius
            val y2 = -z * sinT
            val z2 = z * cosT
            if ((z2 > 0) != back) continue
            val p = 3.2f / (3.2f + z2)
            val dep = ((radius - z2) / (2 * radius)).coerceIn(0f, 1f)
            dot.color = withAlpha(curColor, (25 + dep * 175).toInt())
            c.drawCircle(cx + x * r * p, cy + y2 * r * p, (0.7f + dep * 1.4f) * density, dot)
        }
    }

    private fun drawCore(c: Canvas, cx: Float, cy: Float, r: Float) {
        val pulse = 1f + 0.1f * sin(t * (2f + energy * 7f)) * (0.3f + energy)
        val cr = r * 0.34f * pulse
        c.save()
        c.translate(cx, cy)
        c.scale(cr, cr)
        c.drawCircle(0f, 0f, 1f, core)
        c.restore()
    }

    private fun drawEqualizer(c: Canvas, cx: Float, cy: Float, r: Float) {
        val count = 56
        val strength = ((energy - 0.45f) / 0.55f).coerceIn(0f, 1f)
        bar.strokeWidth = 2.2f * density
        for (i in 0 until count) {
            val a = i / count.toFloat() * 2f * PI.toFloat() + rot * 0.3f
            val noise = 0.5f + 0.5f * sin(i * 1.7f + t * 9f) * sin(i * 0.63f - t * 5.3f)
            val len = r * (0.05f + 0.22f * noise) * strength
            val r1 = r * 1.22f
            bar.color = withAlpha(lerpColor(curColor, Color.WHITE, noise * 0.3f), (90 + 120 * noise * strength).toInt())
            c.drawLine(cx + cos(a) * r1, cy + sin(a) * r1, cx + cos(a) * (r1 + len), cy + sin(a) * (r1 + len), bar)
        }
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun lerpColor(a: Int, b: Int, f: Float): Int {
        val ff = f.coerceIn(0f, 1f)
        fun ch(x: Int, y: Int): Int {
            val v = x + (y - x) * ff
            return (if (y > x) kotlin.math.ceil(v) else kotlin.math.floor(v)).toInt()
        }
        return Color.argb(255, ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }
}
