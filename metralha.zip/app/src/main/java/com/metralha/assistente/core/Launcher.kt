package com.metralha.assistente.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.view.View
import android.view.WindowManager
import com.metralha.assistente.R

/**
 * Abre outros apps (Spotify, Mapas).
 * O Android bloqueia apps em segundo plano (ou com a tela apagada) de abrir telas.
 * A exceção oficial é a permissão "Sobrepor a outros apps": com ela liberada, o Metralha
 * consegue abrir o Spotify/Mapas mesmo com a tela desligada. Sem ela, mostra uma notificação.
 */
object Launcher {
    enum class Result { STARTED, NOTIFIED, NO_APP }

    private const val CHANNEL = "metralha_acoes"
    private var nextId = 100
    private val main = Handler(Looper.getMainLooper())

    fun hasOverlayPermission(ctx: Context) = AndroidSettings.canDrawOverlays(ctx)

    fun canStartDirectly(ctx: Context) = AppState.activityVisible || hasOverlayPermission(ctx)

    fun launch(ctx: Context, intent: Intent, title: String): Result {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(ctx.packageManager) == null) return Result.NO_APP

        if (AppState.activityVisible) {
            if (start(ctx, intent)) return Result.STARTED
        } else if (hasOverlayPermission(ctx)) {
            // Android 15+ exige uma janela de sobreposição visível: criamos uma invisível de 1px por 1 segundo.
            val v = showTinyOverlay(ctx)
            val ok = start(ctx, intent)
            main.postDelayed({ removeOverlay(ctx, v) }, 1500)
            if (ok) return Result.STARTED
        }
        return notify(ctx, intent, title)
    }

    private fun start(ctx: Context, intent: Intent) = try {
        ctx.startActivity(intent); true
    } catch (e: Exception) { false }

    private fun showTinyOverlay(ctx: Context): View? = try {
        val wm = ctx.getSystemService(WindowManager::class.java)
        val v = View(ctx)
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        v
    } catch (e: Exception) { null }

    private fun removeOverlay(ctx: Context, v: View?) {
        if (v == null) return
        try { ctx.getSystemService(WindowManager::class.java).removeView(v) } catch (_: Exception) {}
    }

    fun notify(ctx: Context, intent: Intent, title: String): Result {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ações do Metralha", NotificationManager.IMPORTANCE_HIGH))
        val id = nextId++
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("Metralha")
            .setContentText("$title — toque para abrir")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        return try { nm.notify(id, n); Result.NOTIFIED } catch (e: SecurityException) { Result.NO_APP }
    }

    /** Notificação simples (ex.: lembrete). */
    fun alert(ctx: Context, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ações do Metralha", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, com.metralha.assistente.MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("Metralha")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(nextId++, n) } catch (_: SecurityException) {}
    }
}
