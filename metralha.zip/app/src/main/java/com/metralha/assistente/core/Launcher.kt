package com.metralha.assistente.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.metralha.assistente.R

/**
 * Abre outros apps (Mapas, música).
 * Limitação do Android 10+: um app em segundo plano não pode abrir telas sozinho.
 * Se o Metralha não estiver na tela, mostramos uma notificação para você tocar.
 */
object Launcher {
    enum class Result { STARTED, NOTIFIED, NO_APP }

    private const val CHANNEL = "metralha_acoes"
    private var nextId = 100

    fun launch(ctx: Context, intent: Intent, title: String): Result {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(ctx.packageManager) == null) return Result.NO_APP
        if (AppState.activityVisible) {
            return try {
                ctx.startActivity(intent)
                Result.STARTED
            } catch (e: Exception) {
                notify(ctx, intent, title)
            }
        }
        return notify(ctx, intent, title)
    }

    private fun notify(ctx: Context, intent: Intent, title: String): Result {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ações do Metralha", NotificationManager.IMPORTANCE_HIGH))
        val id = nextId++
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("Metralha")
            .setContentText("$title — toque para abrir")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        return try {
            nm.notify(id, n)
            Result.NOTIFIED
        } catch (e: SecurityException) {
            Result.NO_APP
        }
    }
}
