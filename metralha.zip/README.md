# Metralha v0.2 — copiloto de voz para carro, 100% offline

Custo: **R$ 0**. Sem IA externa, sem API, sem conta, sem internet. Tudo roda dentro do celular.

## O que ele faz

| Área | Exemplos ("Metralha, …") |
|---|---|
| Música no **seu Spotify** | "toca Blinding Lights", "pausa", "próxima", "volta a música", "abre o Spotify" |
| Volume | "aumenta o volume", "volume em 30" |
| Ar-condicionado (Carro Virtual) | "coloca o ar em 19", "tô com frio", "desliga o ar" |
| Navegação | "me leva para o shopping" (pede confirmação) |
| Utilidades | "que horas são", "que dia é hoje", "bateria", "quanto é 25 vezes 4", "15 por cento de 200" |
| Lembretes | "me lembra de abastecer em 10 minutos", "timer de meia hora", "cancela o timer" |
| Conversa | "bom dia", "tudo bem?", "conta uma piada", "me conta uma curiosidade", "cara ou coroa" |
| Respostas que você ensina | Ajustes → Ensine o Metralha |

Depois de uma resposta, ele continua ouvindo por 6 s (conversa contínua): dá para responder sem repetir "Metralha".
Tocar no holograma também ativa o Metralha (ou interrompe a fala).

**Honestidade:** sem internet e sem IA, ele não sabe "tudo" (ex.: "quem descobriu o Brasil?"). Ele responde o que está programado e o que você ensinar.

## Tela apagada + Spotify (faça uma vez)

Na tela inicial aparece o cartão **"Ative para funcionar com a tela apagada"**:
1. **Controlar o Spotify** → ative o Metralha em "Acesso a notificações".
   Se estiver cinza: Configurações do Android → Apps → Metralha → ⋮ (canto) → **Permitir configurações restritas**, e tente de novo.
2. **Abrir apps com a tela apagada** → ative "Sobrepor a outros apps".
3. **Não deixar o Android fechar o Metralha** → escolha "Permitir" / "Sem restrições".
   Em Xiaomi/Redmi/POCO: também ative **Início automático** do Metralha.

Com isso: pode apagar a tela, guardar o celular, e dizer "Metralha, toca …". A notificação fixa "Metralha está ouvindo" mostra que ele está ativo.

## Voz mais humana

Ajustes → Voz: escolha uma voz de **qualidade máxima** e ajuste velocidade e tom. Para mais vozes: "Baixar vozes melhores" → Português (Brasil) do Google. É grátis e fica no celular.

## Atualizar o app (pelo celular)

1. github.com/SEU_USUARIO/SEU_REPOSITORIO → **Add file → Upload files** → envie o novo `metralha.zip` (substitui o antigo) → **Commit changes**.
2. Aba **Actions** → espere o ✅ → **Releases** → baixe o `app-debug.apk` → instale por cima (não precisa desinstalar).

## Segurança

- Lista fechada de ações + validação de todos os valores (temperatura 16–30 °C, volume 0–100, lembrete até 3 h).
- Nunca controla direção, acelerador, freio, marcha, motor ou portas.
- Rotas pedem confirmação por voz.
- O app **não tem permissão de internet**: nada do que você fala sai do celular.

## Bluetooth e ar-condicionado

Bluetooth comum leva o som (música e voz do Metralha) para o carro e recebe play/pausa/próxima. Ele **não** controla ar-condicionado em nenhum carro. Por isso o ar fica no Carro Virtual. Caminhos futuros para clima real: carros com Android Automotive, API oficial da montadora ou um módulo de hardware específico — a arquitetura (`vehicle/VehicleAdapter.kt`) já está pronta para isso.

## Se der erro

- Compilação ❌ no GitHub: abra a etapa com ❌ e mande print das linhas vermelhas.
- Não ouve com a tela apagada: confira os 3 itens acima e se a notificação "Metralha está ouvindo" aparece.
- "Tocando…" mas o Spotify não toca: abra o Spotify uma vez, toque qualquer música e tente de novo (o Spotify precisa estar logado).
- Voz robótica: Ajustes → Voz → escolha outra / baixe vozes melhores.
