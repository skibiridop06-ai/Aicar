# Metralha — assistente de voz para carro (protótipo v0.1)

Custo: **R$ 0**. Tudo feito pelo celular Android.

---

## 1. Tecnologia escolhida (e por quê)

| Parte | Escolha | Custo | Por quê |
|---|---|---|---|
| App | Android nativo em **Kotlin** | grátis | Único jeito confiável de ter microfone contínuo, serviço em segundo plano, Bluetooth e voz |
| Ouvir "Metralha" + entender a fala | **Vosk** (open source, offline) | grátis | Reconhece português **dentro do celular**. O áudio nunca sai do aparelho |
| Entender comandos do carro | **Intérprete local** (regras em português) | grátis | Funciona sem internet, sem chave, instantâneo |
| Perguntas livres ("quem ganhou a Copa de 2002?") | **IA online opcional** (Google Gemini, camada gratuita) | grátis | Só é usada se você colar uma chave; só recebe o texto do comando |
| Voz do Metralha | Síntese de voz do próprio Android | grátis | Já vem no celular |
| Compilar o app | **GitHub Actions** (nuvem do GitHub) | grátis | Ver limitação abaixo |

**Limitação honesta:** não dá para compilar um app Android de forma confiável *dentro* do celular (as ferramentas oficiais do Google não rodam bem em Android). A alternativa gratuita: você envia o projeto pelo navegador do celular para o GitHub, e um computador do GitHub compila e te devolve o arquivo `.apk` para instalar. Você não precisa de computador.

---

## 2. Estrutura de pastas

```
metralha/
├── .github/workflows/build.yml      ← receita que o GitHub usa para compilar
├── settings.gradle, build.gradle, gradle.properties
└── app/
    ├── build.gradle, debug.keystore  ← configuração e assinatura do app
    └── src/main/
        ├── AndroidManifest.xml       ← permissões (microfone, notificação…)
        ├── res/                      ← tela, cores, ícones
        └── java/com/metralha/assistente/
            ├── MainActivity.kt       ← a tela (central futurista)
            ├── service/ListeningService.kt  ← continua ouvindo com outro app aberto
            ├── voice/VoiceEngine.kt  ← microfone + Vosk (local)
            ├── voice/Speaker.kt      ← voz do Metralha
            ├── brain/WakeWord.kt     ← detecta "Metralha"
            ├── brain/LocalParser.kt  ← entende comandos sem internet
            ├── brain/LlmClient.kt    ← IA online opcional
            ├── brain/Commands.kt     ← LISTA FECHADA de ações + validador
            ├── core/MetralhaCore.kt  ← liga tudo
            ├── core/ActionExecutor.kt← executa só comandos validados
            └── vehicle/              ← "carro" abstrato: Virtual e Celular+Bluetooth
```

O modelo de voz em português (~30 MB) não fica no projeto: o GitHub baixa na hora de compilar.

---

## 3. Passo a passo pelo celular

### 3.1 Criar a conta e o repositório (uma vez só)
1. No Chrome do celular, entre em **github.com** e crie uma conta grátis.
2. Toque no **+** (canto superior) → **New repository**.
3. Nome: `metralha`. Pode deixar **Private**. Toque em **Create repository**.

> Se algum botão não aparecer, abra o menu do Chrome (⋮) e marque **"Versão para computador"**.

### 3.2 Enviar o projeto
1. Baixe o arquivo **metralha.zip** que eu te mandei (fica em Downloads). **Não precisa descompactar.**
2. No repositório, toque em **Add file → Upload files** (ou no link "uploading an existing file").
3. Escolha o `metralha.zip` → role para baixo → **Commit changes**.

### 3.3 Criar a receita de compilação
O GitHub só reconhece a receita se ela estiver numa pasta específica, por isso ela é criada à mão:
1. **Add file → Create new file**.
2. No nome do arquivo digite exatamente: `.github/workflows/build.yml`
   (ao digitar as barras `/`, o GitHub cria as pastas sozinho).
3. Cole todo o conteúdo do arquivo **build.yml** que eu te mandei.
4. **Commit changes**.

### 3.4 Compilar (executar)
1. Toque na aba **Actions**. Vai aparecer "Construir APK do Metralha" rodando (bolinha amarela).
2. Espere de 5 a 10 minutos. ✅ verde = deu certo. ❌ vermelho = ver seção 7.
3. Para compilar de novo sem mudar nada: Actions → "Construir APK do Metralha" → **Run workflow**.

### 3.5 Instalar no Android
1. Na página principal do repositório, toque em **Releases** (ou abra `github.com/SEU_USUARIO/metralha/releases`).
2. Na versão mais nova, toque em **app-debug.apk** para baixar.
3. Abra o arquivo baixado. O Android vai pedir para **permitir instalar apps desta fonte** (Chrome) → permita.
4. Se o Play Protect avisar "app desconhecido", toque em **Mais detalhes → Instalar mesmo assim**. (É normal para apps que você mesmo compila.)
5. Abra o **Metralha** e permita **microfone** e **notificações**.

Na primeira abertura, ele leva alguns segundos copiando o modelo de voz ("Carregando a voz…"). Depois aparece **"Metralha está ouvindo"**.

---

## 4. Como testar (com o Carro Virtual)

Fale perto do celular, em ambiente silencioso, de forma natural:

| Você diz | O que deve acontecer |
|---|---|
| "Metralha" | Responde "Sim?" e o círculo fica forte → fale o comando em até 8 s |
| "Metralha, coloca o ar em dezenove" | Clima → **19°C**, A/C ligado |
| "Metralha, aumenta o volume" | Volume 40% → 50% |
| "Metralha, abaixa dois graus" | Temperatura −2 |
| "Metralha, desliga o ar" | A/C desligado |
| "Metralha, toca Blinding Lights" | Música: **Blinding Lights** ▶ |
| "Metralha, próxima música" / "pausa" | Muda a faixa / pausa |
| "Metralha, me leva para o shopping" | Pergunta "Iniciar rota…? Diga sim ou não" → "sim" abre o mapa |
| "Metralha, acelera o carro" | **Recusa** por segurança |
| "Metralha, coloca o ar em 35" | **Recusa**: fora de 16–30 °C |

Cada comando aparece em **Últimos comandos** com o que foi ouvido, o JSON gerado (ex.: `{"action": "set_climate_temperature", "temperature": 19}`) e a resposta.

Sem conseguir falar? Use **Teste por texto** no fim da tela (ex.: digite `coloca o ar em 19`).

**Modo real:** desligue "Carro Virtual". Aí música e volume passam a controlar o celular de verdade (e o rádio do carro, se estiver conectado por Bluetooth), e o ar-condicionado responde que **ainda não está disponível**.

---

## 5. IA online gratuita (opcional)

Sem chave, todos os comandos do carro já funcionam offline. A chave só serve para perguntas livres e frases que o intérprete local não entender.

1. Entre em **aistudio.google.com** (conta Google) → **Get API key** → **Create API key** → copie.
2. No Metralha, em Configurações → cole em **Chave da API** → **Salvar** → **Testar IA**.
3. Endereço e modelo já vêm preenchidos (`gemini-flash-latest`). Se der erro 404 de modelo, troque pelo nome de um modelo "Flash" que aparece no AI Studio.

Diferença: **local** = grátis, offline, privado, só entende comandos previstos. **Online** = entende qualquer frase e responde perguntas, precisa de internet, tem limite diário gratuito e o texto do comando vai para o Google (no plano gratuito, o Google pode usar esses textos para melhorar os produtos dele — não diga dados sensíveis). Funciona também com qualquer serviço compatível com o formato OpenAI (Groq, OpenRouter…), trocando endereço e modelo.

---

## 6. Bluetooth: o que dá e o que não dá

**Bluetooth comum consegue:**
- Mandar o som do celular (música e a voz do Metralha) para o rádio do carro (perfil A2DP).
- Receber comandos de mídia (play, pausa, próxima) entre carro e celular (AVRCP).
- Ligações e microfone do carro (HFP).

**Bluetooth comum NÃO consegue:** controlar ar-condicionado, vidros, travas, ou qualquer função do carro. Esses perfis simplesmente não existem no Bluetooth de áudio.

O pareamento é feito nas configurações do Android (botão **Bluetooth do celular** no app). O app mostra quando o áudio está saindo pelo carro.

**Para controlar o ar de verdade, no futuro, existem estes caminhos (nenhum fingido no app):**
- **Carros com Android Automotive OS** (Google built-in): têm API de clima, mas exige permissões que só montadoras/apps de sistema recebem.
- **API oficial da montadora** (alguns carros conectados têm app/nuvem com controle de clima).
- **Módulo de hardware dedicado no barramento do carro** (CAN): específico por modelo, exige conhecimento técnico e pode ser perigoso/afetar garantia. Só com equipamento profissional.
- **OBD-II (ELM327)**: serve basicamente para **ler** diagnóstico (velocidade, rotação); quase nunca controla o ar.

A arquitetura já está pronta para isso: basta criar uma nova classe em `vehicle/` que implemente `VehicleAdapter` (ex.: `setClimateTemperature(19)`).

---

## 7. Segurança implementada

- A IA **nunca** executa código: a resposta dela é lida só como dados (JSON).
- **Lista fechada** de 15 ações (`brain/Commands.kt`). Qualquer outra é bloqueada.
- **Todos os parâmetros validados**: temperatura 16–30 °C, ajuste ±1 a 5, volume 0–100, textos com tamanho máximo e sem caracteres de controle.
- Direção, acelerador, freio, marcha, motor, portas e travas são **recusados** — tanto pelo intérprete local quanto pela IA.
- Iniciar rota exige **confirmação por voz** ("sim"/"não").
- Enquanto espera "Metralha", **nada é enviado** para a internet: frases sem a palavra são descartadas no próprio celular.

---

## 8. Limitações honestas desta versão

- **Bateria:** o Vosk é mais pesado que um detector de palavra dedicado. Com o celular no carregador do carro, sem problema. O **modo econômico** reduz o processamento (só procura "Metralha"), mas é experimental: se o modelo de voz não conhecer a palavra, ele pode não ativar — aí volte ao modo normal. Upgrade futuro: um detector dedicado (ex.: Porcupine, grátis para uso pessoal com cadastro).
- **Precisão:** o modelo de voz pequeno erra às vezes. O app tolera variações ("metralhar", "me tralha").
- **Abrir Mapas/Spotify com o Metralha em segundo plano:** o Android bloqueia; o app mostra uma notificação para você tocar. Com o Metralha na tela, abre direto.
- **"Metralha, toca X" de uma vez** funciona no modo normal; no modo econômico diga "Metralha", espere o "Sim?" e depois o comando.
- Em alguns celulares (Xiaomi, Samsung), o sistema pode matar o app para economizar bateria: em Configurações > Apps > Metralha > Bateria, escolha **Sem restrições**.

---

## 9. Como corrigir erros

**A compilação ficou vermelha (❌) no GitHub:**
1. Actions → toque na execução vermelha → toque em **build** → abra o passo com ❌.
2. Copie as últimas linhas em vermelho e cole aqui na conversa comigo. Eu corrijo e te mando o arquivo novo.
- "Não achei settings.gradle" → o `metralha.zip` não está na raiz do repositório. Envie de novo pela página principal.
- Erro no passo "Baixar modelo de voz" → o site do modelo oscilou. Toque em **Re-run jobs**.

**O app instala mas:**
- Fica em "Erro" → leia a mensagem embaixo do status. Sem microfone: libere a permissão em Configurações > Apps > Metralha.
- Não fala → instale/ative a voz em português: Configurações > Acessibilidade > Saída de texto para voz > Google > Português (Brasil).
- Não ativa com a voz → use "Teste por texto" para confirmar que o resto funciona; fale mais perto e devagar; tente sem o modo econômico.
- Fecha sozinho → me mande o que estava fazendo quando fechou.

**"App não instalado" ao atualizar:** desinstale a versão antiga e instale a nova.

**Para atualizar o app:** eu te mando um novo `metralha.zip` → no GitHub, **Add file → Upload files** → envie (ele substitui o antigo) → a compilação começa sozinha → baixe o novo APK em Releases.
